//
//  AppDelegate.h
//  iOSCodeStructure
//
//  Created by Nishant on 27/12/12.
//  Copyright (c) 2012 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITabBarCustom.h"

#import "ClsInternetChecking.h"
#import "LocationManager.h"
#import "DBAdapter.h"

#import "PickerView.h"

// Global Function
#import "FunctionManager.h"
#import "DBFunctionManager.h"

// App Funcations
#import "AppFunctionManager.h"

@class ViewController;
@class DashboardViewController;

@class GTMOAuth2Authentication;

@interface AppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate> {
    IBOutlet UINavigationController *navController;
    IBOutlet UITabBarCustom *objCustomTabBar;
    BOOL isPopToAllView;
}

@property (strong, nonatomic) IBOutlet UIWindow *window;

@property (nonatomic, retain) UINavigationController *navController;
@property (nonatomic, retain) UITabBarCustom *objCustomTabBar;
@property (nonatomic) BOOL isPopToAllView;

//@property (strong, nonatomic) ViewController *viewController;
@property (strong, nonatomic) DashboardViewController *viewController;

// Show/Hide Loading
@property (nonatomic,retain) IBOutlet UIView *viewLoading;
@property (nonatomic,retain) IBOutlet UILabel *lblLoadingMessage;
// Internet Checking
@property (nonatomic,retain) ClsInternetChecking *objInternetAvailable;
@property (nonatomic,retain) IBOutlet UIView *viewNoInternet;
// GPS Location
@property (nonatomic, retain) LocationManager *objLocationManager;
@property (nonatomic,retain) IBOutlet UIView *viewAllowGPSLocation;
@property (nonatomic,retain) IBOutlet UILabel *lblAllowGPSMessage;
@property (nonatomic) BOOL isGPSLocationActive;
// Database
@property (nonatomic, retain) DBAdapter *objDBAdapter;

// Picker View
@property (nonatomic, retain) PickerView *objPickerView;

// Social Network Login
@property (nonatomic) int intSNID;

// Selected Settings
@property (nonatomic) int intSelectedBody;
@property (nonatomic) int intSelectedStyle;
@property (nonatomic) int intSelectedGender;


-(void)initializeAppData;
-(void)setDefaultSettings;
-(void)checkDeviceCompatibility;

-(void)setTabBar;
-(void)gotoDetailApp:(int)pintTabId;
-(void)gotoHomePage;

// Show/Hide Internet Connection View
-(void)showNoInterntConnection;
-(void)removeNoInternetView;

// GPS Location
-(void)showAllowGPSLocationView;
-(IBAction)closeApp:(id)sender;
-(void)closeAppForceFully;

// Localization
-(void)checkForLocalization:(int)pintLanguageID;

// Load Date Picker
-(void)loadDatePicker;

@end
