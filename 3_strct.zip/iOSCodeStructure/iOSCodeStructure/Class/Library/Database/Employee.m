//
//  Employee.m
//  iOSCodeStructure
//
//  Created by Nishant on 10/01/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import "Employee.h"

@implementation Employee

@synthesize intEmployeeID;
@synthesize strEmployeeName, strEmployeeCode;
@synthesize intIsActive, intIsDeleted;

-(void)dealloc{
	[self.strEmployeeName release];
	[self.strEmployeeCode release];
	
	[super dealloc];
}

@end
