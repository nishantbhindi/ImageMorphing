//
//  objJSONParser.m
//  
//
//  Created by Nishan B
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "JSONParser.h"
#import "JSON.h"

/*
#import "LoginViewController.h"
#import "LandingViewController.h"
#import "MemberRegistrationS3VC.h"
*/

@implementation JSONParser

#pragma mark - JSON Data Format
-(NSString *)getFormattedJSON:(NSString *)pstrJSON
{
    //'   ====> &#039;
	//&   ====> &amp;
    //>   ====> &gt;
	//<   ====> &lt;
	//"   ====> &quot;
	
	pstrJSON = [pstrJSON stringByReplacingOccurrencesOfString:@"'" withString:@"&#039;"];
	pstrJSON = [pstrJSON stringByReplacingOccurrencesOfString:@"&" withString:@"&amp;"];
	pstrJSON = [pstrJSON stringByReplacingOccurrencesOfString:@">" withString:@"&gt;"];
	pstrJSON = [pstrJSON stringByReplacingOccurrencesOfString:@"<" withString:@"&lt;"];
	pstrJSON = [pstrJSON stringByReplacingOccurrencesOfString:@"\"" withString:@"&quot;"];
	
	return pstrJSON;
}
-(NSString *)getFormattedNodeValue:(NSString *)pstrNodeValue
{	
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&#039;" withString:@"'"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&gt;" withString:@">"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&lt;" withString:@"<"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&quot;" withString:@"\""];
	
	return pstrNodeValue;
}

/*
#pragma mark - Login
-(void)checkLoginResponse:(NSString *)pstrJSONData withUser:(Connections *)pobjConnections withParent:(id)pParent
{
	objLandingViewController = pParent;
	
	SBJSON *objJSONParser = [[SBJSON alloc] init];
	NSDictionary *dictData = [objJSONParser objectWithString:pstrJSONData error:nil];
	objLandingViewController.intSuccess = [[dictData objectForKey: @"Success"] intValue];
    objLandingViewController.strCode = [dictData objectForKey: @"ErrorCode"];
    objLandingViewController.strMessage = [dictData objectForKey: @"ErrorMessage"];
    
    NSDictionary *dictDataUser = [dictData objectForKey: @"dataResponse"];
	
    if(!((NSNull *)dictDataUser == [NSNull null])){
        if([dictDataUser count]>0){
            pobjConnections.intConnectionsId = [[dictDataUser objectForKey: @"Id"] intValue];
            pobjConnections.strEmail = [dictDataUser objectForKey: @"UserName"];
            pobjConnections.strPassword = [dictDataUser objectForKey: @"Password"];
        }
    }
 
	[objJSONParser release];
}
#pragma mark - Member Signup
-(void)checkMemberSignupResponse:(NSString *)pstrJSONData withUser:(Connections *)pobjConnections withParent:(id)pParent
{
    objMemberRegistrationS3VC = pParent;
	
	SBJSON *objJSONParser = [[SBJSON alloc] init];
	NSDictionary *dictData = [objJSONParser objectWithString:pstrJSONData error:nil];
	objMemberRegistrationS3VC.intSuccess = [[dictData objectForKey: @"Success"] intValue];
    objMemberRegistrationS3VC.strCode = [dictData objectForKey: @"ErrorCode"];
    objMemberRegistrationS3VC.strMessage = [dictData objectForKey: @"ErrorMessage"];
    
    NSDictionary *dictDataUser = [dictData objectForKey: @"dataResponse"];
	
    if(!((NSNull *)dictDataUser == [NSNull null])){
        if([dictDataUser count]>0){
            pobjConnections.intConnectionsId = [[dictDataUser objectForKey: @"Id"] intValue];
        }
    }
    
	[objJSONParser release];
}

#pragma mark - Common Result
-(void)getCommonResult:(NSString *)pstrJSONData withParent:(id)pParent withPageId:(int)pintPageId
{
	int intID;
	int intSuc;
	NSString *strMsg;
	intID = 0;
	intSuc = 0;
	strMsg = @"";
	
	SBJSON *objJSONParser = [[SBJSON alloc] init];
	NSDictionary *dictData = [objJSONParser objectWithString:pstrJSONData error:nil];
	NSDictionary *dictDataResult = [dictData objectForKey: @"result"];
	
	//NSString *strEmail = [dictDataResult objectForKey: @"email"];
	intSuc = [[dictDataResult objectForKey: @"success"] intValue];
	strMsg = [dictDataResult objectForKey: @"message"];
	
	switch (pintPageId) {
		case 1:	//Forgot Password
			objLoginViewController = pParent;
			objLoginViewController.intSuccess = intSuc;
			objLoginViewController.strMessage = strMsg;
			break;
		case 2: //Logout
			objLandingViewController = pParent;
			//objLandingViewController.intSuccess = intSuc;
			//objLandingViewController.strMessage = strMsg;
			break;
		default:
			break;
	}
	[objJSONParser release];
}
*/

@end
