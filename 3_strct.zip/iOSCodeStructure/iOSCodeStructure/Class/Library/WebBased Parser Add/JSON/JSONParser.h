//
//  JSONParser.h
//  
//
//  Created by Nishan B
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SBJSON.h"

/*
#import "User.h"
#import "Connections.h"

@class LoginViewController;
@class LandingViewController;
@class MemberRegistrationS3VC;
*/

@interface JSONParser : NSObject
{
    /*
	LoginViewController *objLoginViewController;
	LandingViewController *objLandingViewController;
	MemberRegistrationS3VC *objMemberRegistrationS3VC;
    
	User *objUser;
    Connections *objConnections;
     */
}

//JSON Data Format
-(NSString *)getFormattedJSON:(NSString *)pstrJSON;
-(NSString *)getFormattedNodeValue:(NSString *)pstrNodeValue;

/*
//Login
-(void)checkLoginResponse:(NSString *)pstrJSONData withUser:(Connections *)pobjConnections withParent:(id)pParent;

//Member Signup
-(void)checkMemberSignupResponse:(NSString *)pstrJSONData withUser:(Connections *)pobjConnections withParent:(id)pParent;

//Commmon
-(void)getCommonResult:(NSString *)pstrJSONData withParent:(id)pParent withPageId:(int)pintPageId;
*/

@end
