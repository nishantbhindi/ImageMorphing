//
//  UIView+Screenshot.h
//  BestBetting
//
//  Created by WebInfoways on 24/04/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface UIView (Screenshot)

- (UIImage *)screenshot;
//- (UIImage *)invertedScreenshot;

@end
