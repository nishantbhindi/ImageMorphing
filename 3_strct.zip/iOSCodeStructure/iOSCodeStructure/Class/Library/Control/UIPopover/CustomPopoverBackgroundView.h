//
//  CustomPopoverBackgroundView.h
//  popoverDemo
//
//  Created by WebInfoways on 29/04/13.
//  Copyright (c) 2013 WebInfoways. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIPopoverBackgroundView.h>

@interface CustomPopoverBackgroundView : UIPopoverBackgroundView {
    UIImageView *_borderImageView;
    UIImageView *_arrowView;
    CGFloat _arrowOffset;
    UIPopoverArrowDirection _arrowDirection;
}

@end
