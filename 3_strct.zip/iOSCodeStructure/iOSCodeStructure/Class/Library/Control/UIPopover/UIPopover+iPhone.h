//
//  UIPopover+iPhone.h
//  popoverDemo
//
//  Created by WebInfoways on 29/04/13.
//  Copyright (c) 2013 WebInfoways. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIPopoverController (overrides)
+ (BOOL)_popoversDisabled;
@end
