//
//  UIPopover+iPhone.m
//  popoverDemo
//
//  Created by WebInfoways on 29/04/13.
//  Copyright (c) 2013 WebInfoways. All rights reserved.
//

#import "UIPopover+iPhone.h"

@implementation UIPopoverController (overrides)

+ (BOOL)_popoversDisabled
{
    return NO;
}

@end
