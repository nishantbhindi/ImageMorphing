//
//  UIImage+RoundedCorner.h
//  iOSCodeStructure
//
//  Created by Nishant on 02/01/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (RoundedCorner)

- (UIImage *)roundedCornerImage:(NSInteger)pintCornerSize borderSize:(NSInteger)pintBorderSize;

@end
