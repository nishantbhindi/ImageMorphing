//
//  UIImage+Resize.h
//  iOSCodeStructure
//
//  Created by Nishant on 02/01/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Resize)

// Resize
- (UIImage *)resizedImage:(CGSize)psizNewSize interpolationQuality:(CGInterpolationQuality)pQuality;
- (UIImage *)resizedImageWithContentMode:(UIViewContentMode)pContentMode bounds:(CGSize)psizBounds interpolationQuality:(CGInterpolationQuality)pQuality;

// Cropped
- (UIImage *)croppedImage:(CGRect)psizBounds;

// Thumbnail
- (UIImage *)thumbnailImage:(NSInteger)pintThumbnailSize transparentBorder:(NSUInteger)pintBorderSize cornerRadius:(NSUInteger)pintCornerRadius interpolationQuality:(CGInterpolationQuality)pQuality;


@end
