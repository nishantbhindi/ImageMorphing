//
//  UIImage+Extras.h
//  iOSCodeStructure
//
//  Created by Nishant on 02/01/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Extras)

// Scale and Resize
-(UIImage *)imageScaleAspectToMaxSize:(CGFloat)pfltNewSize;
-(UIImage *)imageScaleAndCropToMaxSize:(CGSize)psizNewSize;
-(UIImage *)resizeImage:(CGSize)psizNewSize;


typedef enum {
    MGImageResizeCrop, // analogous to UIViewContentModeScaleAspectFill, i.e. "best fit" with no space around.
    MGImageResizeCropStart,
    MGImageResizeCropEnd,
    MGImageResizeScale // analogous to UIViewContentModeScaleAspectFit, i.e. scale down to fit, leaving space around if necessary.
} MGImageResizingMethod;

// Scale and Resize 2
-(UIImage *)imageScaledToFitSize:(CGSize)psizNewSize; // uses MGImageResizeScale
-(UIImage *)imageToFitSize:(CGSize)psizNewSize method:(MGImageResizingMethod)resizeMethod;
-(UIImage *)imageCroppedToFitSize:(CGSize)psizNewSize; // uses MGImageResizeCrop

// Orientation
-(UIImage *)fixOrientation;

// Save Image
-(void)saveJPGInFolder:(NSString*)pstrFolderName withFileName:(NSString*)pstrFileName withCompressionQuality:(CGFloat)pfltCompressionQuality;
-(void)savePNGInFolder:(NSString*)pstrFolderName withFileName:(NSString*)pstrFileName;

@end
