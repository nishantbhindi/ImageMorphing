//
//  UITabBarCustom.h
//  iOSCodeStructure
//
//  Created by Nishant on 09/01/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <Foundation/Foundation.h>

@class AppDelegate;

@interface UITabBarCustom : UITabBarController <UITabBarControllerDelegate> {
	AppDelegate *appDelegate;
    
	// Following buttons are taken to behave like TabItems
	UIButton *btnTab1;
	UIButton *btnTab2;
	UIButton *btnTab3;
	UIButton *btnTab4;
	
    UIImageView *imgTabBg;
}
@property (nonatomic, retain) UIButton *btnTab1;
@property (nonatomic, retain) UIButton *btnTab2;
@property (nonatomic, retain) UIButton *btnTab3;
@property (nonatomic, retain) UIButton *btnTab4;

@property (nonatomic, retain) UIImageView *imgTabBg;

-(void)hideOriginalTabBar;
-(void)addCustomElements;
-(void)addAllElements;
-(UIButton *)getGeneralTabButton:(int)pintTag isSelected:(BOOL)pbolIsSelected;

-(void)selectTab:(int)tabID;

-(void)showTabBar;
-(void)hideTabBar;

@end
