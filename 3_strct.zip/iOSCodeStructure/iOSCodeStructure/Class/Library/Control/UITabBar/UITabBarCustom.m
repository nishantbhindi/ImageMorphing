//
//  UITabBarCustom.m
//  iOSCodeStructure
//
//  Created by Nishant on 09/01/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import "UITabBarCustom.h"

@implementation UITabBarCustom

@synthesize btnTab1, btnTab2, btnTab3, btnTab4;
@synthesize imgTabBg;

#pragma mark - View Life Cycle
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
	appDelegate= (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [self hideOriginalTabBar];
    [self addCustomElements];
}

- (void)dealloc
{
	[btnTab1 release];
	[btnTab2 release];
	[btnTab3 release];
	[btnTab4 release];
	
    [super dealloc];
}

#pragma mark - Hide Original TabBar - Add Custom TabBar
- (void)hideOriginalTabBar
{
	for(UIView *view in self.view.subviews)
	{
		if([view isKindOfClass:[UITabBar class]])
		{
			view.hidden = YES;
            break;
		}
	}
}
-(void)addCustomElements
{
	//Add Bg Image
    if(imgTabBg != nil)
    {
        [imgTabBg removeFromSuperview];
    }
    imgTabBg = [[UIImageView alloc]initWithFrame:CGRectMake(0, 431, 320.0, 49)];
    imgTabBg.image=[UIImage imageNamed:@"bg_tabbar.png"];
    [self.view addSubview:imgTabBg];
    [imgTabBg release];
	
	[self addAllElements];
}
-(void)addAllElements
{
	//Add Tab Buttons
	if(btnTab1 != nil)
        [btnTab1 removeFromSuperview];
	
	if (btnTab2 != nil)
        [btnTab2 removeFromSuperview];
	
	if(btnTab3 != nil)
        [btnTab3 removeFromSuperview];
	
	if (btnTab4 != nil)
        [btnTab4 removeFromSuperview];
	
	
	btnTab1 = [self getGeneralTabButton:g_TabID_Tab1 isSelected:true];
	btnTab2 = [self getGeneralTabButton:g_TabID_Tab2 isSelected:false];
	btnTab3 = [self getGeneralTabButton:g_TabID_Tab3 isSelected:false];
	btnTab4 = [self getGeneralTabButton:g_TabID_Tab4 isSelected:false];
	
	[self.view addSubview:btnTab1];
	[self.view addSubview:btnTab2];
	[self.view addSubview:btnTab3];
	[self.view addSubview:btnTab4];
	
	// Setup event handlers so that the buttonClicked method will respond to the touch up inside event.
	[btnTab1 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchDown];
	[btnTab2 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchDown];
	[btnTab3 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchDown];
	[btnTab4 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchDown];
}
-(UIButton *)getGeneralTabButton:(int)pintTag isSelected:(BOOL)pbolIsSelected
{
	UIImage *btnImage;
    UIImage *btnImageSelected;
	
	UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
	//[btn setBackgroundColor:[UIColor greenColor]];
    //[btn setTitle:@"TabTitle" forState:UIControlStateNormal];
	[btn setTitleColor:[UIColor colorWithRed:145.0/255.0 green:152.0/255.0 blue:162.0/255.0 alpha:1.0] forState:UIControlStateNormal];
	[btn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
	[btn.titleLabel setFont:[UIFont boldSystemFontOfSize:12.0]];
	[btn setTag:pintTag];
	[btn setSelected:pbolIsSelected];
	
	switch (pintTag) {
		case 0:	//Tab-1
			btnImage = [UIImage imageNamed:@"ico_tab1.png"];
			btnImageSelected = [UIImage imageNamed:@"ico_tab1_selected.png"];
			btn.frame = CGRectMake(1, 425, 80, 55);
			break;
		case 1:	//Tab-2
			btnImage = [UIImage imageNamed:@"ico_tab2.png"];
			btnImageSelected = [UIImage imageNamed:@"ico_tab2_selected.png"];
			btn.frame = CGRectMake(81, 425, 80, 55);
			break;
		case 2:	//Tab-3
			btnImage = [UIImage imageNamed:@"ico_tab3.png"];
			btnImageSelected = [UIImage imageNamed:@"ico_tab3_selected.png"];
			btn.frame = CGRectMake(161, 425, 80, 55);
			break;
		case 3:	//Tab-4
			btnImage = [UIImage imageNamed:@"ico_tab4.png"];
			btnImageSelected = [UIImage imageNamed:@"ico_tab4_selected.png"];
			btn.frame = CGRectMake(241, 425, 80, 55);
			break;
		default://Tab-1
			btnImage = [UIImage imageNamed:@"ico_tab1.png"];
			btnImageSelected = [UIImage imageNamed:@"ico_tab1_selected.png"];
			btn.frame = CGRectMake(0, 425, 80, 55);
			break;
	}
	[btn setImage:btnImage forState:UIControlStateNormal];
	[btn setImage:btnImageSelected forState:UIControlStateSelected];
	
	return btn;
}

#pragma mark - Select Tab
- (void)buttonClicked:(id)sender
{
	int tagNum = [sender tag];
	[self selectTab:tagNum];
}
- (void)selectTab:(int)tabID
{
	switch(tabID)
	{
        case 0:
			[btnTab1 setSelected:true];
			[btnTab2 setSelected:false];
			[btnTab3 setSelected:false];
			[btnTab4 setSelected:false];
			break;
		case 1:
			[btnTab1 setSelected:false];
			[btnTab2 setSelected:true];
			[btnTab3 setSelected:false];
			[btnTab4 setSelected:false];
			break;
		case 2:
			[btnTab1 setSelected:false];
			[btnTab2 setSelected:false];
			[btnTab3 setSelected:true];
			[btnTab4 setSelected:false];
			break;
		case 3:
			[btnTab1 setSelected:false];
			[btnTab2 setSelected:false];
			[btnTab3 setSelected:false];
			[btnTab4 setSelected:true];
			break;
    }
    
    //For click tabbar icon to go to main view controller
    /*NSArray *arrNavigationController=[self viewControllers];
    UINavigationController *navController = (UINavigationController *)[self selectedViewController];
     
    if (self.selectedIndex == tabID) {
        if([[arrNavigationController objectAtIndex:self.selectedIndex] isKindOfClass:[navController class]])
        {
            [navController popToRootViewControllerAnimated:YES];
        }
    }*/
    //For click tabbar icon to go to main view controller end
    
	self.selectedIndex = tabID;
	if (self.selectedIndex == tabID)
	{
        if (appDelegate.isPopToAllView==FALSE) {
            /*if (self.selectedIndex==1 || self.selectedIndex==2 || self.selectedIndex==3) {
                //self.selectedIndex==1 = Tab-2
                //self.selectedIndex==2 = Tab-3
                //self.selectedIndex==3 = Tab-4
            }
            else
            {
                UINavigationController *navController = (UINavigationController *)[self selectedViewController];
                [navController popToRootViewControllerAnimated:NO];
            }*/
        }
        else
        {
            UINavigationController *navController = (UINavigationController *)[self selectedViewController];
            [navController popToRootViewControllerAnimated:YES];
        }
	}
	else
	{
		self.selectedIndex = tabID;
	}
}

#pragma mark - Show/Hide TabBar
- (void)showTabBar
{
	self.imgTabBg.hidden = NO;
	
	self.btnTab1.hidden = NO;
	self.btnTab2.hidden = NO;
	self.btnTab3.hidden = NO;
	self.btnTab4.hidden = NO;
	
	self.btnTab1.userInteractionEnabled=YES;
	self.btnTab2.userInteractionEnabled=YES;
    self.btnTab3.userInteractionEnabled=YES;
    self.btnTab4.userInteractionEnabled=YES;
}
- (void)hideTabBar
{
	self.imgTabBg.hidden = YES;
	
	self.btnTab1.hidden = YES;
	self.btnTab2.hidden = YES;
	self.btnTab3.hidden = YES;
	self.btnTab4.hidden = YES;
	
	self.btnTab1.userInteractionEnabled=NO;
	self.btnTab2.userInteractionEnabled=NO;
    self.btnTab3.userInteractionEnabled=NO;
    self.btnTab4.userInteractionEnabled=NO;
}

@end
