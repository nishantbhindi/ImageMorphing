//
//  UILabel+Extras.h
//  iOSCodeStructure
//
//  Created by Nishant on 09/01/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (Extras)

// Alignment
- (void)alignTop;
- (void)alignBottom;

@end
