//
//  NBPageControl.m
//  BestBetting
//
//  Created by WebInfoways on 12/04/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import "NBPageControl.h"

@interface NBPageControl (Private)
- (void) updateDots;
@end

@implementation NBPageControl

@synthesize imageNormal = imgNormal;
@synthesize imageCurrent = imgCurrent;

- (void) dealloc
{
    [imgNormal release], imgNormal = nil;
    [imgCurrent release], imgCurrent = nil;
    
	[super dealloc];
}

/** override to update dots */
- (void) setCurrentPage:(NSInteger)currentPage
{
    [super setCurrentPage:currentPage];
    
    // update dot views
    [self updateDots];
}

/** override to update dots */
- (void) setNumberOfPages:(NSInteger)number
{
    [super setNumberOfPages:number];
    
    // update dot views
    [self updateDots];
}

/** override to update dots */
- (void) updateCurrentPageDisplay
{
    [super updateCurrentPageDisplay];
    
    // update dot views
    [self updateDots];
}

/** Override setImageNormal */
- (void) setImageNormal:(UIImage*)image
{
    [imgNormal release];
    imgNormal = [image retain];
    
    // update dot views
    [self updateDots];
}

/** Override setImageCurrent */
- (void) setImageCurrent:(UIImage*)image
{
    [imgCurrent release];
    imgCurrent = [image retain];
    
    // update dot views
    [self updateDots];
}

/** Override to fix when dots are directly clicked */
- (void) endTrackingWithTouch:(UITouch*)touch withEvent:(UIEvent*)event
{
    [super endTrackingWithTouch:touch withEvent:event];
    
    [self updateDots];
}

#pragma mark - (Private)
- (void) updateDots
{
    if(imgCurrent || imgNormal)
    {
        // Get subviews
        NSArray* dotViews = self.subviews;
        for(int i = 0; i < dotViews.count; ++i)
        {
            UIImageView* dot = [dotViews objectAtIndex:i];
            // Set image
            dot.image = (i == self.currentPage) ? imgCurrent : imgNormal;
        }
    }
}

@end
