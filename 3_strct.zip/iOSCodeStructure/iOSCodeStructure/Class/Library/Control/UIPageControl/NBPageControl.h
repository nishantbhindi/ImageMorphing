//
//  NBPageControl.h
//  BestBetting
//
//  Created by WebInfoways on 12/04/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NBPageControl : UIPageControl {
    UIImage *imgNormal;
    UIImage *imgCurrent;
}

@property (nonatomic, readwrite, retain) UIImage *imageNormal;
@property (nonatomic, readwrite, retain) UIImage *imageCurrent;

@end
