//
//  UIColor+Extras.h
//  iOSCodeStructure
//
//  Created by Nishant on 08/02/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Extras)

+ (UIColor *)colorWithHex:(NSUInteger) rgb;
+ (UIColor *)colorWithHex2:(UInt32)col;
+ (UIColor *)colorWithHexString:(NSString *)str;

//+ (UIColor *)colorWithHexString:(NSString *)hexString;
+ (CGFloat)colorComponentFrom:(NSString *)string start:(NSUInteger)start length:(NSUInteger) length;

@end
