//
//  XMLParser.h
//  
//
//  Created by Nishant.Bhindi on 17/04/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

/*
#import "User.h"

@class LandingViewController;
@class LoginViewController;
*/

@interface XMLParser : NSObject 
{
    /*
	LoginViewController *objLoginViewController;
	
	LandingViewController *objLandingViewController;
	
	User *objUser;
     */
}

/*
//XML Data Format
-(NSString *)getFormattedXML:(NSString *)pstrXML;
-(NSString *)getFormattedNodeValue:(NSString *)pstrNodeValue;

//Login
-(void)checkLoginResponse:(NSString *)xmlData withUser:(User *)pobjUser withParent:(id)pParent;

//Commmon
-(void)getCommonResult:(NSString *)xmlData withParent:(id)pParent withPageId:(int)pintPageId;
*/

@end
