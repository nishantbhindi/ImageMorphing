//
//  XMLParser.m
//  
//
//  Created by Nishant.Bhindi on 17/04/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "XMLParser.h"
#import "TouchXML.h"

/*
#import "LandingViewController.h"
#import "LoginViewController.h"
*/
@implementation XMLParser

/*
#pragma mark -
#pragma mark XML Data Format
-(NSString *)getFormattedXML:(NSString *)pstrXML
{
	//'   ====> &#039;
	//&   ====> &amp;
	//>   ====> &gt;
	//<   ====> &lt;
	//"   ====> &quot;
	
	pstrXML = [pstrXML stringByReplacingOccurrencesOfString:@"'" withString:@"&#039;"];
	pstrXML = [pstrXML stringByReplacingOccurrencesOfString:@"&" withString:@"&amp;"];
	//pstrXML = [pstrXML stringByReplacingOccurrencesOfString:@">" withString:@"&gt;"];
	//pstrXML = [pstrXML stringByReplacingOccurrencesOfString:@"<" withString:@"&lt;"];
	pstrXML = [pstrXML stringByReplacingOccurrencesOfString:@"\"" withString:@"&quot;"];
	
	return pstrXML;
}
-(NSString *)getFormattedNodeValue:(NSString *)pstrNodeValue
{	
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&#039;" withString:@"'"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&gt;" withString:@">"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&lt;" withString:@"<"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&quot;" withString:@"\""];
	
	return pstrNodeValue;
}
 
 */

/*
#pragma mark -
#pragma mark Login
-(void)checkLoginResponse:(NSString *)xmlData withUser:(User *)pobjUser withParent:(id)pParent
{	
	objLoginViewController = pParent;
	
	xmlData = [self getFormattedXML:xmlData];
	
	NSError *theError = NULL;
	CXMLDocument *theXMLDocument = [[[CXMLDocument alloc] initWithXMLString:xmlData options:0 error:&theError] autorelease];
	CXMLElement *rootElement = [theXMLDocument rootElement];	
	NSArray *arrUserData = [rootElement children];
	if (arrUserData.count > 0)
	{
		for(CXMLElement *firstChild in arrUserData)
		{
			NSString *nodeName = [firstChild name];                
			NSString *nodeValue = [[firstChild stringValue]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
			
			nodeValue = [self getFormattedNodeValue:nodeValue];
			
			if([nodeName isEqualToString:@"status"])
				objLoginViewController.intSuccess = [nodeValue intValue];
			else if([nodeName isEqualToString:@"message"])
				objLoginViewController.strMessage = nodeValue;
			
			else if([nodeName isEqualToString:@"userid"])
				pobjUser.intUserId = [nodeValue intValue];
			else if([nodeName isEqualToString:@"username"])
				pobjUser.strUsername = nodeValue;
			else if([nodeName isEqualToString:@"firstname"])
				pobjUser.strFirstname = nodeValue;
			else if([nodeName isEqualToString:@"lastname"])
				pobjUser.strLastname = nodeValue;
			else if([nodeName isEqualToString:@"email"])
				pobjUser.strEmail = nodeValue;
		}
	}
}

#pragma mark -
#pragma mark Common Result
-(void)getCommonResult:(NSString *)xmlData withParent:(id)pParent withPageId:(int)pintPageId
{
	int intID;
	int intSuc;
	NSString *strMsg;
	intID = 0;
	intSuc = 0;
	strMsg = @"";
	
	xmlData = [self getFormattedXML:xmlData];
	
	NSError *theError = NULL;
	CXMLDocument *theXMLDocument = [[[CXMLDocument alloc] initWithXMLString:xmlData options:0 error:&theError] autorelease];
	CXMLElement *rootElement = [theXMLDocument rootElement];	
	NSArray *arrResultData = [rootElement children];
	if (arrResultData.count > 0)
	{
		for(CXMLElement *firstChild in arrResultData)
		{
			NSString *nodeName = [firstChild name];                
			NSString *nodeValue = [[firstChild stringValue]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
			
			if([nodeName isEqualToString:@"status"])
				intSuc = [nodeValue intValue];
			else if([nodeName isEqualToString:@"message"])
				strMsg = nodeValue;
			else if([nodeName isEqualToString:@"intid"])
				intID = [nodeValue intValue];
		}
	}
	
	switch (pintPageId) {
		case 1:	//Forgot Password
			objLoginViewController = pParent;
			objLoginViewController.intSuccess = intSuc;
			objLoginViewController.strMessage = strMsg;
			break;
		case 2: //Logout
			objLandingViewController = pParent;
			objLandingViewController.intSuccess = intSuc;
			objLandingViewController.strMessage = strMsg;
			break;
		default:
			break;
	}
}
*/

@end
