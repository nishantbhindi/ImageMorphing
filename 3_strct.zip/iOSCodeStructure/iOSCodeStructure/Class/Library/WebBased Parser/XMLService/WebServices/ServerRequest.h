//
//  ServerRequest.h
//  ElectionPoll
//
//  Created by Nishant.Bhindi on 25/03/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ServerRequestResult

-(void) XMLDataServerResponse:(NSString*) response;


@optional

-(void) geocodingServerError:(NSString*) error; 

@end



@interface ServerRequest : NSObject
{
	NSMutableData* receivedData;	

	id<ServerRequestResult> delegate; 
	
	NSString *requestUrl;
	
	BOOL _isNetworkNotAvailable;
}

-(id)initWithURL:(NSString *)url;

-(void)sendRequest;

@property(nonatomic,retain)	id<ServerRequestResult> delegate; 

@end
