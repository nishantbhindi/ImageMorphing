//
//  ServerRequest.m
//  ElectionPoll
//
//  Created by Nishant.Bhindi on 25/03/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "ServerRequest.h"
//#import "LocationListViewController.h"

@implementation ServerRequest

@synthesize delegate;

-(id)initWithURL:(NSString *)url
{
 	requestUrl = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	//requestUrl = url;
	
	[super init];
	
	return self;
	
}
-(void)sendRequest
{
	//requestUrl = [requestUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	NSLog(@"url = %@\n",requestUrl);
	/*NSURLRequest *theRequest=[NSURLRequest requestWithURL:[NSURL URLWithString:requestUrl]
											  cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
										  timeoutInterval:20.0];*/
	NSURLRequest *theRequest=[NSURLRequest requestWithURL:[NSURL URLWithString:requestUrl]
											  cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
										  timeoutInterval:120.0];
	
	/*NSURLRequest *theRequest=[NSURLRequest requestWithURL:requestUrl
											  cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
										  timeoutInterval:120.0];*/
	
	// create the connection with the request
	// and start loading the data
	NSURLConnection *theConnection=[[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
	if (theConnection) {
		// Create the NSMutableData that will hold
		// the received data
		// receivedData is declared as a method instance elsewhere
		receivedData=[[NSMutableData data] retain];
	} else {
		// inform the user that the download could not be made
	}	
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	// this method is called when the server has determined that it 
    // has enough information to create the NSURLResponse
	
    // it can be called multiple times, for example in the case of a
    // redirect, so each time we reset the data.
    // receivedData is declared as a method instance elsewhere
	
    NSHTTPURLResponse * httpResponse = (NSHTTPURLResponse *) response;	
	//NSLog(@"Server response %d\n",[httpResponse statusCode]);
	
	switch ([httpResponse statusCode])
	{
		case 400:case 401:case 403:case 404:case 500:
		{
			//geocodingServerError
			if([(id)delegate respondsToSelector:@selector(geocodingServerError:)])
				[delegate geocodingServerError:[NSHTTPURLResponse localizedStringForStatusCode:[httpResponse statusCode]]];
			//@throw [NSException exceptionWithName: @"Server response" reason:@"Wrong parameters!!!" userInfo:nil];
		}
			break; 
		default:
			break;
	}
    [receivedData setLength:0];
	
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	// append the new data to the receivedData
    // receivedData is declared as a method instance elsewhere
	
	unsigned char* pData = malloc([data length]);
    //NSLog(@"Succeeded! Received %d bytes of data",[data length]);
	[data getBytes:pData];
    //NSLog(@"didReceiveData:\n %s\n\n", (char *)pData);	
	free(pData);
    [receivedData appendData:data];
}
- (void)connection:(NSURLConnection *)connection
  didFailWithError:(NSError *)error
{
	// release the connection, and the data object
    [connection release];
    // receivedData is declared as a method instance elsewhere
    [receivedData release];
	
    // inform the user
    NSLog(@"Connection failed! Error - %@ %@",
		 [error localizedDescription],
		 [[error userInfo] objectForKey:NSErrorFailingURLStringKey]);
	
	//NSString * message = [NSString stringWithFormat:@"Connection failed! Error - %@\n Please try again later.",[error localizedDescription]];
	
	/*UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Information" message:message delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
	[alert show];	
	[alert release];*/	
	
	
	/*if([[delegate class] isEqual:[LocationListViewController class]])
	{
		//[delegate hideLoading];
		//[delegate connectionFailed:error];
	}*/
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	// do something with the data
    // receivedData is declared as a method instance elsewhere
	unsigned char* pData = malloc([receivedData length]);
    NSLog(@"Succeeded! Received %d bytes of data",[receivedData length]);
	[receivedData getBytes:pData];
	//pData[[receivedData length]] = '\0';
	
    //NSLog(@"connectionDidFinishLoading \n\ndata %s", (char *)pData);
	
	/*if([[delegate class] isEqual:[FirstViewController class]])
	{
		NSLog(@"Enter.....");
	}*/
	
	[delegate XMLDataServerResponse:[[NSString alloc] initWithData:receivedData encoding:NSUTF8StringEncoding]];
	
	free(pData);
    [connection release];
    [receivedData release];
}
@end
