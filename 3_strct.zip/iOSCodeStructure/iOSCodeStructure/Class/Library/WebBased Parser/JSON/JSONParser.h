//
//  JSONParser.h
//  
//
//  Created by Nishan B
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SBJSON.h"

#import "User.h"

@class LoginViewController;
@class LandingViewController;


@interface JSONParser : NSObject
{
	LoginViewController *objLoginViewController;
	LandingViewController *objLandingViewController;
	
	User *objUser;
}

//JSON Data Format
-(NSString *)getFormattedJSON:(NSString *)pstrJSON;
-(NSString *)getFormattedNodeValue:(NSString *)pstrNodeValue;

//Login
-(void)checkLoginResponse:(NSString *)pstrJSONData withUser:(User *)pobjUser withParent:(id)pParent;

//Commmon
-(void)getCommonResult:(NSString *)pstrJSONData withParent:(id)pParent withPageId:(int)pintPageId;

@end
