//
//  NBJSONParser.m
//  
//
//  Created by nishan on 9/24/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "NBJSONParser.h"
#import "JSON.h"

/*
#import "LoginViewController.h"
#import "HomeViewController.h"
*/

@implementation NBJSONParser

/*
#pragma mark -
#pragma mark JSON Data Format
-(NSString *)getFormattedJSON:(NSString *)pstrJSON
{
	 //'   ====> &#039;
	 //&   ====> &amp;
	 //>   ====> &gt;
	 //<   ====> &lt;
	 //"   ====> &quot;
	
	pstrXML = [pstrXML stringByReplacingOccurrencesOfString:@"'" withString:@"&#039;"];
	pstrXML = [pstrXML stringByReplacingOccurrencesOfString:@"&" withString:@"&amp;"];
	pstrXML = [pstrXML stringByReplacingOccurrencesOfString:@">" withString:@"&gt;"];
	pstrXML = [pstrXML stringByReplacingOccurrencesOfString:@"<" withString:@"&lt;"];
	pstrXML = [pstrXML stringByReplacingOccurrencesOfString:@"\"" withString:@"&quot;"];
	
	return pstrXML;
}
-(NSString *)getFormattedNodeValue:(NSString *)pstrNodeValue
{	
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&#039;" withString:@"'"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&gt;" withString:@">"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&lt;" withString:@"<"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&quot;" withString:@"\""];
	
	return pstrNodeValue;
}

//Get Location Details
-(void)getLocationDetails:(NSString *)pStrResponse withDetailsArray:(NSMutableArray *)pArrLocationList
{
	[pArrLocationList removeAllObjects];
	SBJSON *jsonParser = [[SBJSON alloc] init];
	NSDictionary *dictVenues = [jsonParser objectWithString:pStrResponse error: nil];
	NSDictionary *items = [[dictVenues objectForKey: @"response"] objectForKey:@"venues"];	
	for(NSDictionary *venues in items)
	{
		/*ClsLocationDetails *objLocationDetails = [[ClsLocationDetails alloc] init];
		 objLocationDetails.strPlaceID = [venues objectForKey:@"id"];
		 objLocationDetails.strName = [venues objectForKey: @"name"];
		 objLocationDetails.strAddress = [[venues objectForKey: @"location"] objectForKey: @"address"];
		 
		 if(objLocationDetails.strAddress == nil || [objLocationDetails.strAddress isEmptyString])
		 objLocationDetails.strAddress = @"Address not available";
		 
		 objLocationDetails.dblLatitude = [[[venues objectForKey: @"location"] objectForKey: @"lat"] floatValue];
		 objLocationDetails.dblLongitude = [[[venues objectForKey: @"location"] objectForKey: @"lng"] floatValue];
		 objLocationDetails.dblDistance = [[[venues objectForKey: @"location"] objectForKey: @"distance"] floatValue] * kMeterToFeet;
		 objLocationDetails.strCity = [[venues objectForKey: @"location"] objectForKey: @"city"];
		 objLocationDetails.strState = [[venues objectForKey: @"location"] objectForKey: @"state"];
		 objLocationDetails.strCountry = [[venues objectForKey: @"location"] objectForKey: @"country"];
		 [pArrLocationList addObject:objLocationDetails];
		 [objLocationDetails release];*/

    /*}
	[jsonParser release];
}

*/

/*
#pragma mark -
#pragma mark Common Result
-(void)getCommonResult:(NSString *)xmlData withParent:(id)pParent withPageId:(int)pintPageId
{
	int intID;
	int intSuc;
	NSString *strMsg;
	intID = 0;
	intSuc = 0;
	strMsg = @"";
	
	xmlData = [self getFormattedXML:xmlData];
	
	NSError *theError = NULL;
	CXMLDocument *theXMLDocument = [[[CXMLDocument alloc] initWithXMLString:xmlData options:0 error:&theError] autorelease];
	CXMLElement *rootElement = [theXMLDocument rootElement];	
	NSArray *arrResultData = [rootElement children];
	if (arrResultData.count > 0)
	{
		for(CXMLElement *firstChild in arrResultData)
		{
			NSString *nodeName = [firstChild name];                
			NSString *nodeValue = [[firstChild stringValue]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
			
			if([nodeName isEqualToString:@"status"])
				intSuc = [nodeValue intValue];
			else if([nodeName isEqualToString:@"message"])
				strMsg = nodeValue;
			else if([nodeName isEqualToString:@"intid"])
				intID = [nodeValue intValue];
		}
	}
	
	switch (pintPageId) {
		case 1:	//Forgot Password
			objLoginViewController = pParent;
			objLoginViewController.intSuccess = intSuc;
			objLoginViewController.strMessage = strMsg;
			break;
		case 2: //Logout
			objHomeViewController = pParent;
			objHomeViewController.intSuccess = intSuc;
			objHomeViewController.strMessage = strMsg;
			break;
		default:
			break;
	}
}
*/

@end
