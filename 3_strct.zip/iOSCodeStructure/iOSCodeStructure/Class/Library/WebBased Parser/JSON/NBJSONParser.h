//
//  NBJSONParser.h
//  
//
//  Created by nishan on 9/24/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SBJSON.h"

/*
#import "User.h"

@class LoginViewController;
@class HomeViewController;
*/

@interface NBJSONParser : NSObject {
    
    /*
	LoginViewController *objLoginViewController;
	
	HomeViewController *objHomeViewController;
	
	User *objUser;
     */
}

/*
//JSON Data Format
-(NSString *)getFormattedJSON:(NSString *)pstrJSON;
-(NSString *)getFormattedNodeValue:(NSString *)pstrNodeValue;

//Get Location Details
-(void)getLocationDetails:(NSString *)pStrResponse withDetailsArray:(NSMutableArray *)pArrLocationList;

//Commmon
-(void)getCommonResult:(NSString *)xmlData withParent:(id)pParent withPageId:(int)pintPageId;
*/

@end
