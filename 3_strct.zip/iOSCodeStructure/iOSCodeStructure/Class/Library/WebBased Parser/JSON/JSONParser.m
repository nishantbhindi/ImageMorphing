//
//  objJSONParser.m
//  
//
//  Created by Nishan B
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "JSONParser.h"
#import "JSON.h"

#import "LoginViewController.h"
#import "LandingViewController.h"


@implementation JSONParser

#pragma mark - JSON Data Format
-(NSString *)getFormattedJSON:(NSString *)pstrJSON
{
    //'   ====> &#039;
	//&   ====> &amp;
    //>   ====> &gt;
	//<   ====> &lt;
	//"   ====> &quot;
	
	pstrJSON = [pstrJSON stringByReplacingOccurrencesOfString:@"'" withString:@"&#039;"];
	pstrJSON = [pstrJSON stringByReplacingOccurrencesOfString:@"&" withString:@"&amp;"];
	pstrJSON = [pstrJSON stringByReplacingOccurrencesOfString:@">" withString:@"&gt;"];
	pstrJSON = [pstrJSON stringByReplacingOccurrencesOfString:@"<" withString:@"&lt;"];
	pstrJSON = [pstrJSON stringByReplacingOccurrencesOfString:@"\"" withString:@"&quot;"];
	
	return pstrJSON;
}
-(NSString *)getFormattedNodeValue:(NSString *)pstrNodeValue
{	
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&#039;" withString:@"'"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&gt;" withString:@">"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&lt;" withString:@"<"];
	pstrNodeValue = [pstrNodeValue stringByReplacingOccurrencesOfString:@"&quot;" withString:@"\""];
	
	return pstrNodeValue;
}

#pragma mark - Login
-(void)checkLoginResponse:(NSString *)pstrJSONData withUser:(User *)pobjUser withParent:(id)pParent
{
	objLoginViewController = pParent;
	
	SBJSON *objJSONParser = [[SBJSON alloc] init];
	NSDictionary *dictData = [objJSONParser objectWithString:pstrJSONData error:nil];
	NSDictionary *dictDataResult = [dictData objectForKey: @"result"];
	
	objLoginViewController.intSuccess = [[dictDataResult objectForKey: @"status"] intValue];
	objLoginViewController.strMessage = [dictDataResult objectForKey: @"message"];
	
	NSDictionary *dictDataUser = [dictDataResult objectForKey: @"data"];
	 
	pobjUser.intUserId = [[dictDataUser objectForKey: @"intid"] intValue];
	pobjUser.intOrganizationId = [[dictDataUser objectForKey: @"organization_id"] intValue];
    
    pobjUser.strFirstname = [dictDataUser objectForKey: @"firstname"];
    pobjUser.strLastname = [dictDataUser objectForKey: @"lastname"];
	pobjUser.strEmail = [dictDataUser objectForKey: @"email"];
	pobjUser.strPassword = [dictDataUser objectForKey: @"password"];
	
	pobjUser.strUserType = [dictDataUser objectForKey: @"usertype"];
	pobjUser.intUserType = [[dictDataUser objectForKey: @"usertype_id"] intValue];
	
	//[pArrLocationList removeAllObjects];
	/*NSDictionary *items = [[dictDataResult objectForKey: @"response"] objectForKey:@"venues"];
	for(NSDictionary *venues in items)
	{
        ClsLocationDetails *objLocationDetails = [[ClsLocationDetails alloc] init];
		 objLocationDetails.strPlaceID = [venues objectForKey:@"id"];
		 objLocationDetails.strName = [venues objectForKey: @"name"];
		 objLocationDetails.strAddress = [[venues objectForKey: @"location"] objectForKey: @"address"];
		 
		 if(objLocationDetails.strAddress == nil || [objLocationDetails.strAddress isEmptyString])
		 objLocationDetails.strAddress = @"Address not available";
		 
		 objLocationDetails.dblLatitude = [[[venues objectForKey: @"location"] objectForKey: @"lat"] floatValue];
		 objLocationDetails.dblLongitude = [[[venues objectForKey: @"location"] objectForKey: @"lng"] floatValue];
		 objLocationDetails.dblDistance = [[[venues objectForKey: @"location"] objectForKey: @"distance"] floatValue] * kMeterToFeet;
		 objLocationDetails.strCity = [[venues objectForKey: @"location"] objectForKey: @"city"];
		 objLocationDetails.strState = [[venues objectForKey: @"location"] objectForKey: @"state"];
		 objLocationDetails.strCountry = [[venues objectForKey: @"location"] objectForKey: @"country"];
		 [pArrLocationList addObject:objLocationDetails];
		 [objLocationDetails release];
	}*/

	[objJSONParser release];
}

#pragma mark - Common Result
-(void)getCommonResult:(NSString *)pstrJSONData withParent:(id)pParent withPageId:(int)pintPageId
{
	int intID;
	int intSuc;
	NSString *strMsg;
	intID = 0;
	intSuc = 0;
	strMsg = @"";
	
	SBJSON *objJSONParser = [[SBJSON alloc] init];
	NSDictionary *dictData = [objJSONParser objectWithString:pstrJSONData error:nil];
	NSDictionary *dictDataResult = [dictData objectForKey: @"result"];
	
	//NSString *strEmail = [dictDataResult objectForKey: @"email"];
	intSuc = [[dictDataResult objectForKey: @"success"] intValue];
	strMsg = [dictDataResult objectForKey: @"message"];
	
	switch (pintPageId) {
		case 1:	//Forgot Password
			objLoginViewController = pParent;
			objLoginViewController.intSuccess = intSuc;
			objLoginViewController.strMessage = strMsg;
			break;
		case 2: //Logout
			objLandingViewController = pParent;
			//objLandingViewController.intSuccess = intSuc;
			//objLandingViewController.strMessage = strMsg;
			break;
		default:
			break;
	}
	[objJSONParser release];
}


@end
