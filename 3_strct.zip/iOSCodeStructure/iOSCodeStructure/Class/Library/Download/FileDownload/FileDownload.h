//
//  FileDownload.h
//  iOSCodeStructure
//
//  Created by Nishant on 08/02/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ASIHTTPRequest.h"
#import "ASINetworkQueue.h"
#import "FileDownload_Debug.h"

@protocol HappyDownloadProgress <ASIProgressDelegate>

@optional

-(void)setProgress:(NSNumber*)newProgress forWorker:(ASIHTTPRequest*)request;

@end

@interface FileDownload : ASIHTTPRequest <ASIProgressDelegate, ASIHTTPRequestDelegate>{
    
    float progress;
    int totalBytes;
    
	//changed
    //__block ASIHTTPRequest * sentinelRequest;
	ASIHTTPRequest * sentinelRequest;
	//changed
    NSMutableArray * requests;
    NSMutableArray * parts;
    NSMutableArray * partsAvailable;
    NSMutableArray * paths;
    
    int totalChunk;
    int numberOfWorkers;
    
    NSTimeInterval startTime;
}

@property(nonatomic, assign) int totalChunk;
@property(nonatomic, assign) int numberOfWorkers;

@end
