//
//  FileDownload_Debug.h
//  iOSCodeStructure
//
//  Created by Nishant on 08/02/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#if defined (DISTRIBUTION)

#define _ASSERT(STATEMENT) do { (void) sizeof(STATEMENT); } while(0)
#define _NSLog(format, ...)


#else

#define _ASSERT(STATEMENT) do { assert(STATEMENT); } while(0)
#define _NSLog(format, ...) NSLog(format, ## __VA_ARGS__);		// always needs NSString as the first parameters

#endif
