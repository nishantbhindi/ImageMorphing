//
//  IconDownloader.m
//  LazyLoadTableImages
//
//  Created by Kshitiz Ghimire on 2/28/11.
//  Copyright 2011 Javra Software. All rights reserved.
//

#import "ImageDownloader.h"

//#define kAppIconHeight 60
#define kAppIconHeight 54
#define kAppIconWidth 54

#define kAppIconHeightDeal 88
#define kAppIconWidthDeal 283

@implementation ImageDownloader

@synthesize cellDataUser;
@synthesize indexPathInTableView;
@synthesize delegate;
@synthesize activeDownload;
@synthesize imageConnection;

#pragma mark

- (void)dealloc
{
    [cellDataUser release];
    [indexPathInTableView release];
    [activeDownload release];
    [imageConnection cancel];
    [imageConnection release];
    [super dealloc];
}

- (void)startDownload
{	
	if(cellDataUser)
	{
		self.activeDownload = [NSMutableData data];
		// alloc+init and start an NSURLConnection; release on completion/failure
		NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:
								 [NSURLRequest requestWithURL:
								  [NSURL URLWithString:cellDataUser.strPicture]] delegate:self];
		self.imageConnection = conn;
		
		[conn release];
	}
}

- (void)cancelDownload
{
    [self.imageConnection cancel];
    self.imageConnection = nil;
    self.activeDownload = nil;
}

#pragma mark -
#pragma mark Download support (NSURLConnectionDelegate)

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.activeDownload appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	// Clear the activeDownload property to allow later attempts
    self.activeDownload = nil;
    // Release the connection now that it's finished
    self.imageConnection = nil;
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // Set appIcon and clear temporary data/image
	if(cellDataUser)
	{
		UIImage *image = [[UIImage alloc] initWithData:self.activeDownload];
		
		//if (image.size.width != kAppIconHeight && image.size.height != kAppIconHeight)
		if (image.size.width != kAppIconWidth && image.size.height != kAppIconHeight)
		{
			//CGSize itemSize = CGSizeMake(kAppIconHeight, kAppIconHeight);
			CGSize itemSize = CGSizeMake(kAppIconWidth, kAppIconHeight);
			UIGraphicsBeginImageContext(itemSize);
			CGRect imageRect = CGRectMake(0.0, 0.0, itemSize.width, itemSize.height);
			[image drawInRect:imageRect];
			
			self.cellDataUser.icon = UIGraphicsGetImageFromCurrentImageContext();
			
			UIGraphicsEndImageContext();
		}
		else
		{
			self.cellDataUser.icon = image;
		}
		self.activeDownload = nil;
		[image release];
		// Release the connection now that it's finished
		self.imageConnection = nil;
		
		// call our delegate and tell it that our icon is ready for display
		[delegate imageDidLoad:self.indexPathInTableView];
	}
}

@end
