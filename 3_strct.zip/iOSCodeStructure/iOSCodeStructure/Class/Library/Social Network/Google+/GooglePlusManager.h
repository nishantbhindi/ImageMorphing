//
//  GooglePlusManager.h
//  BestBetting
//
//  Created by WebInfoways on 10/04/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol GooglePlusApiCallDelegate;

typedef enum GooglePlusApiCallType
{
	GPApiCallNone = 0,
	GPApiCallGetUserInfo = 1,
	GPApiCallGetUserFriend = 2,
	GPApiCallPostMessage = 3,
	GPApiCallPostPicture = 4,
	GPApiCallShareLink = 5,
	GPApiCallPostAll = 6,
	GPApiCallPostMessageFriendWall = 7
	
} GooglePlusApiCallType;

@class GPPSignInButton;

@interface GooglePlusManager : NSObject <GPPSignInDelegate> {
    GPPSignIn *signIn;
    
    id<GooglePlusApiCallDelegate> apiCallDelegate;
	GooglePlusApiCallType currentApiCallType;
	
	NSString *strMessage;
	NSString *strUrl;
	NSString *strPictureUrl;
    NSString *strUrlTitle;
    NSString *strCaption;
	UIImage *image;
    
    //Google+ User Data
    NSString *strGPUserID;
    NSString *strGPClientID;
    NSString *strGPUserEmail;
    NSString *strGPUserAgent;
    NSString *strGPUserDesc;
    NSString *strGPUserCode;
    NSString *strGPUserLanguage;
    NSString *strGPUserKeychain;
}
@property (nonatomic, assign) id<GooglePlusApiCallDelegate> apiCallDelegate;
@property (nonatomic, assign) GooglePlusApiCallType currentApiCallType;

@property (nonatomic, retain) NSString *strMessage;
@property (nonatomic, retain) NSString *strUrl;
@property (nonatomic, retain) NSString *strPictureUrl;
@property (nonatomic, retain) NSString *strUrlTitle;
@property (nonatomic, retain) NSString *strCaption;
@property (nonatomic, retain) UIImage *image;

@property (nonatomic, retain) NSString *strGPUserID;
@property (nonatomic, retain) NSString *strGPClientID;
@property (nonatomic, retain) NSString *strGPUserEmail;
@property (nonatomic, retain) NSString *strGPUserAgent;
@property (nonatomic, retain) NSString *strGPUserDesc;
@property (nonatomic, retain) NSString *strGPUserCode;
@property (nonatomic, retain) NSString *strGPUserLanguage;
@property (nonatomic, retain) NSString *strGPUserKeychain;

+(GooglePlusManager *) sharedInstance;
-(void)releaseObjects;

//Public Methods
-(BOOL)isLoggedIn;
-(void)loginToGooglePlus;
-(void)logoutFromGooglePlus;

//GooglePlus Methods
-(void)getUserInfo;					//Get User Info
-(void)reportAuthStatus;
-(void)retrieveUserInfo;

@end

@protocol GooglePlusApiCallDelegate <NSObject>

@optional

//User LogIn/Logout
-(void)userLoginToGooglePlus;
-(void)userLogoutFromGooglePlus;

//Get User Info Delegate
-(void)successUserInfoResponseGP;

@end
