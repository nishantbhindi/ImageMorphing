//
//  LinkedInGlobal.h
//  BestBetting
//
//  Created by Nishant
//  Copyright (c) 2013 Nishant. All rights reserved.
//

//Client ID
#define kClientID                                 @"1089099572928.apps.googleusercontent.com"

//Remember Key
#define kGooglePlusAccessToken                    @"GooglePlusAccessTokenKey"
#define kGooglePlusExpirationDate                 @"GooglePlusExpirationDateKey"

//Message
//ClientID Missing
#define msgGooglePlusIDMissing                    @"Missing GooglePlus ClientID."

//Test Data
#define msgGooglePlusPostStatus                   @"This is custom GooglePlus message."
