//
//  GooglePlusManager.m
//  BestBetting
//
//  Created by WebInfoways on 10/04/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import "GooglePlusManager.h"

#import "GTLPlusConstants.h"
#import "GPPSignInButton.h"
#import "GTLPlus.h"
#import "GTMLogger.h"
#import "GTMOAuth2Authentication.h"

@implementation GooglePlusManager

@synthesize apiCallDelegate, currentApiCallType;
@synthesize strMessage, strUrl, strPictureUrl, strUrlTitle, strCaption, image;
@synthesize strGPUserID, strGPClientID, strGPUserEmail;
@synthesize strGPUserAgent, strGPUserDesc, strGPUserCode, strGPUserLanguage, strGPUserKeychain;

#pragma mark -
#pragma mark Singleton Variables
static GooglePlusManager *singletonManager = nil;

#pragma mark -
#pragma mark Singleton Methods
+ (GooglePlusManager *)sharedInstance {
    @synchronized(self) {
        if(singletonManager == nil)
            singletonManager = [[super allocWithZone:NULL] init];
    }
    return singletonManager;
}
+ (id)allocWithZone:(NSZone *)zone {
    return [[self sharedInstance] retain];
}
- (id)copyWithZone:(NSZone *)zone {
    return self;
}
- (id)retain {
    return self;
}
- (unsigned)retainCount {
    return UINT_MAX; //denotes an object that cannot be released
}
- (oneway void)release {
    // never release
}
- (id)autorelease {
    return self;
}
- (id)init {
    if ((self = [super init])) {
        //Add One Time Data
        //https://www.googleapis.com/auth/userinfo.email
        //https://www.googleapis.com/auth/userinfo.profile
        
        //GPPSignIn *signIn = [GPPSignIn sharedInstance];
        signIn = [GPPSignIn sharedInstance];
        signIn.clientID = kClientID;
        signIn.shouldFetchGoogleUserEmail = TRUE;
        signIn.shouldFetchGoogleUserID = TRUE;
        signIn.shouldGroupAccessibilityChildren = TRUE;
        signIn.scopes = [NSArray arrayWithObjects:
                         kGTLAuthScopePlusLogin, // defined in GTLPlusConstants.h
                         kGTLAuthScopePlusMe,
                         //@"https://www.googleapis.com/auth/userinfo.email",
                         //@"https://www.googleapis.com/auth/userinfo.profile",
                         nil];
        signIn.delegate = self;
        //[signIn authenticate];
    }
    
    return self;
}
- (void)dealloc {
    // Should never be called, but just here for clarity really.
    [self releaseObjects];
	
	[super dealloc];
}
- (void)releaseObjects {
	[self.strMessage release];
    [self.strUrl release];
    [self.strPictureUrl release];
	[self.strUrlTitle release];
	[self.strCaption release];
	[self.image release];
    
    [self.strGPUserID release];
    [self.strGPClientID release];
    [self.strGPUserEmail release];
    
    [self.strGPUserAgent release];
    [self.strGPUserDesc release];
    [self.strGPUserCode release];
    [self.strGPUserLanguage release];
    [self.strGPUserKeychain release];
}

#pragma mark - Public Methods
-(BOOL)isLoggedIn
{
    if ([GPPSignIn sharedInstance].authentication)
        return YES;
    else
        return NO;
    
	return NO;
}
-(void)loginToGooglePlus
{
	if(![self isLoggedIn])
    {
        [signIn authenticate];
    }
}
-(void)logoutFromGooglePlus {
    [[GPPSignIn sharedInstance] signOut];
    [[GPPSignIn sharedInstance] disconnect];
}

#pragma mark - GooglePlus Methods
#pragma mark Get UserInfo
-(void)getUserInfo
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	currentApiCallType = GPApiCallGetUserInfo;
    
	if([self isLoggedIn]){
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        
        //[self retrieveUserInfo];
        if ([self.apiCallDelegate respondsToSelector:@selector(successUserInfoResponseGP)])
            [self.apiCallDelegate successUserInfoResponseGP];
    }
	else
		[self loginToGooglePlus];
}
#pragma mark Get UserInfo delegate
- (void)finishedWithAuth:(GTMOAuth2Authentication *)auth
                   error:(NSError *)error {
    //NSLog(@"Received error %@ and auth object %@",error, auth);
    
    if (error) {
        //NSLog(@"%@", [NSString stringWithFormat:@"Status: Authentication error: %@", error]);
        [FunctionManager showMessage:@"" withMessage:[NSString stringWithFormat:@"Status: Authentication error: %@", error] withDelegage:nil];
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        return;
    }
    [self reportAuthStatus];
}
-(void)reportAuthStatus{
    if ([GPPSignIn sharedInstance].authentication) {
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        
        //NSLog(@"Status: Authenticated");
        [self retrieveUserInfo];
        if ([self.apiCallDelegate respondsToSelector:@selector(successUserInfoResponseGP)])
            [self.apiCallDelegate successUserInfoResponseGP];
        
    } else {
        // To authenticate, use Google+ sign-in button.
        //NSLog(@"Status: Not authenticated");
        [FunctionManager showMessage:@"" withMessage:@"Status: Not authenticated" withDelegage:nil];
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    }
}
-(void)retrieveUserInfo{
    self.strGPUserID = [GPPSignIn sharedInstance].userID;
    self.strGPClientID = [GPPSignIn sharedInstance].authentication.clientID; //[GPPSignIn sharedInstance].clientID
    self.strGPUserEmail = [GPPSignIn sharedInstance].authentication.userEmail;
    
    self.strGPUserAgent = [GPPSignIn sharedInstance].authentication.userAgent;
    self.strGPUserDesc = [GPPSignIn sharedInstance].authentication.description;
    self.strGPUserCode = [GPPSignIn sharedInstance].authentication.code;
    self.strGPUserLanguage = [GPPSignIn sharedInstance].language;
    self.strGPUserKeychain = [GPPSignIn sharedInstance].keychainName;
    //NSLog(@"Scope = %@", [GPPSignIn sharedInstance].scopes);
    
}

@end
