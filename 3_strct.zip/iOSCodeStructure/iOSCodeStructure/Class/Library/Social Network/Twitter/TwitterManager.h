//
//  TwitterManager.h
//  TwitterDemo
//
//  Created by Nishant
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SA_OAuthTwitterController.h"
#import "MGTwitterEngine.h"
#import "GSTwitPicEngine.h"

@class SA_OAuthTwitterEngine;

@protocol TwitterApiCallDelegate;

typedef enum TwitterApiCallType
{
	TwitterApiCallNone = 0,
	TwitterApiCallPostMessage = 1,
	TwitterApiCallPostPicture = 2
	
} TwitterApiCallType;

@interface TwitterManager : NSObject<SA_OAuthTwitterControllerDelegate> {
	MGTwitterEngine *objMGTEngine;
	SA_OAuthTwitterEngine *objSAOAuthEngine;
	GSTwitPicEngine *objTwitPicEngine;
	
	id<TwitterApiCallDelegate> apiCallDelegate;
	TwitterApiCallType currentApiCallType;
	
	NSString *strTwitterPostMessage;
	UIImage *imgTwitterPostImage;
}
@property(nonatomic,retain) SA_OAuthTwitterEngine *objSAOAuthEngine;
@property(nonatomic,retain) GSTwitPicEngine *objTwitPicEngine;

@property (nonatomic, assign) id<TwitterApiCallDelegate> apiCallDelegate;
@property (nonatomic, assign) TwitterApiCallType currentApiCallType;

@property (nonatomic, retain) NSString *strTwitterPostMessage;
@property (nonatomic, retain) UIImage *imgTwitterPostImage;


+ (TwitterManager *) sharedInstance;
- (void)releaseObjects;

//Store Authentication
- (void)storeAuthData:(NSString *)data;
- (void)removeAuthData;

//Public Methods
-(BOOL)isAuthorized;
-(void)loginToTwitter;
-(void)logoutFromTwitter;

//Twitter Methods
-(void)postMessageToTwitterWall;			//Post Message to Twitter Wall
-(void)postPictureToTwitterWall;			//Post Picture to Twitter Wall

//String Methods
- (BOOL)isEmptyString:(NSString *)strValue;
- (NSString *) trimWhiteSpace:(NSString *)strValue;

// Default AlertView
-(void)showAlertView:(NSString *)pstrTitle withMessage:(NSString *)pstrMessage delegate:(id)pDelegate;

@end

@protocol TwitterApiCallDelegate <NSObject>

@optional

//Post Message to Twitter Wall Delegate
-(void)finishTwitterPostMessageResponse:(NSString *)requestIdentifier;
-(void)failedTwitterPostMessageResponse:(NSString *)requestIdentifier;

//Post Picture to Twitter Wall
-(void)finishTwitterPostPictureResponse:(NSDictionary *)result;
-(void)failedTwitterPostPictureResponse:(NSDictionary *)error;


//User LogInLogout
-(void)userLoginToTwitter:(NSString *)pstrUsername;

@end
