//
//  TwitterManager.m
//  TwitterDemo
//
//  Created by Nishant
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "TwitterManager.h"
#import "SA_OAuthTwitterEngine.h"

@implementation TwitterManager;

@synthesize objSAOAuthEngine,objTwitPicEngine;
@synthesize apiCallDelegate, currentApiCallType;
@synthesize strTwitterPostMessage, imgTwitterPostImage;

#pragma mark -
#pragma mark Singleton Variables
static TwitterManager *singletonHelper = nil;

#pragma mark -
#pragma mark Singleton Methods
- (id)init {
    if (!kTwitterConsumerKey) {
        //NSLog(@"%@", msgTwitterAppIDMissing);
        exit(1);
        return nil;
    }
    
    if ((self = [super init])) {
    }
    
    return self;
}

+ (TwitterManager *)sharedInstance {
	@synchronized(self) {
		if (singletonHelper == nil) {
			[[self alloc] init]; // assignment not done here
		}
	}
	return singletonHelper;
}

+ (id)allocWithZone:(NSZone *)zone {
	@synchronized(self) {
		if (singletonHelper == nil) {
			singletonHelper = [super allocWithZone:zone];
			return singletonHelper;
		}
	}
	// on subsequent allocation attempts return nil
	return nil;
}

- (id)copyWithZone:(NSZone *)zone {
	return self;
}

- (id)retain {
	return self;
}

- (unsigned)retainCount {
	return UINT_MAX;  // denotes an object that cannot be released
}

//- (void)release {
- (void)dealloc {	
	[self releaseObjects];
	
	[super dealloc];
}

- (id)autorelease {
	return self;
}

- (void)releaseObjects {
	[self.strTwitterPostMessage release];
	[self.imgTwitterPostImage release];
	self.imgTwitterPostImage = nil;
	
	[self.objSAOAuthEngine release];
	self.objSAOAuthEngine = nil;
	
	[self.objTwitPicEngine release];
	self.objTwitPicEngine=nil;
}

#pragma mark -
#pragma mark Store/Remove Authentication 
- (void)storeAuthData:(NSString *)data{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:data forKey:kTwitterAuthData];
    [defaults synchronize];
}
- (void)removeAuthData{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:kTwitterAuthData];
    [defaults synchronize];
}

#pragma mark -
#pragma mark Public Methods
-(BOOL)isAuthorized
{
	if([self.objSAOAuthEngine isAuthorized])
		return YES;
	else
		return NO;
	
	return NO;
}
-(void)loginToTwitter
{
	if(![self isAuthorized])
	{
		self.objSAOAuthEngine = [[SA_OAuthTwitterEngine alloc] initOAuthWithDelegate:self];
        self.objSAOAuthEngine.consumerKey    = kTwitterConsumerKey;
        self.objSAOAuthEngine.consumerSecret = kTwitterConsumerSecret;
		
		UIViewController *controller = [SA_OAuthTwitterController controllerToEnterCredentialsWithTwitterEngine:self.objSAOAuthEngine delegate:self];  
        
        if (controller){  
            //[rootView presentModalViewController:controller animated:YES];
			[(UIViewController *)self.apiCallDelegate presentModalViewController:controller animated:YES];
        }
	}
}
-(void)logoutFromTwitter 
{
	[self removeAuthData];
	
    [self.objSAOAuthEngine clearAccessToken];
	[self.objSAOAuthEngine clearsCookies];
	
	[self.objSAOAuthEngine release];
	self.objSAOAuthEngine=nil;
}

#pragma mark -
#pragma mark Twitter Methods
-(void)postMessageToTwitterWall
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	
	currentApiCallType = TwitterApiCallPostMessage;
	if([self isAuthorized])
		[self.objSAOAuthEngine sendUpdate:self.strTwitterPostMessage];
	else
		[self loginToTwitter];
}
-(void)postPictureToTwitterWall
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	
	currentApiCallType = TwitterApiCallPostPicture;
	if([self isAuthorized])
	{	
		if(!self.objTwitPicEngine)
			self.objTwitPicEngine = (GSTwitPicEngine *)[GSTwitPicEngine twitpicEngineWithDelegate:self];
		
		//self.objTwitPicEngine = (GSTwitPicEngine *)[GSTwitPicEngine twitpicEngineWithDelegate:self];
		[self.objTwitPicEngine setAccessToken:self.objSAOAuthEngine.tokenAccess];
		[self.objTwitPicEngine uploadPicture:self.imgTwitterPostImage  withMessage:self.strTwitterPostMessage];
	}
	else
		[self loginToTwitter];
}

#pragma mark -
#pragma mark Twitter Methods - SA_OAuthTwitterEngineDelegate
#pragma mark =================================================
- (void) storeCachedTwitterOAuthData: (NSString *) data forUsername: (NSString *) username {
	//NSLog(@"LoggedIn User= %@", username);
	[self storeAuthData:data];
}
- (NSString *) cachedTwitterOAuthDataForUsername: (NSString *) username {
	//NSLog(@"LoggedIn User As= %@", username);
	return [[NSUserDefaults standardUserDefaults] objectForKey: @"authData"];
}
//=============================================================================================================================
#pragma mark TwitterEngineDelegate
- (void) requestSucceeded: (NSString *) requestIdentifier {
	//NSLog(@"Request %@ succeeded", requestIdentifier);
	[self showAlertView:msgPostTitle withMessage:msgPostStatusSuccess delegate:nil];
	
	switch((int)currentApiCallType)
	{
		case TwitterApiCallPostMessage:
			if ([self.apiCallDelegate respondsToSelector:@selector(finishTwitterPostMessageResponse:)])
				[self.apiCallDelegate finishTwitterPostMessageResponse:requestIdentifier];
			break;
	}
	currentApiCallType = TwitterApiCallNone;
	
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
- (void) requestFailed: (NSString *) requestIdentifier withError: (NSError *) error {
	//NSLog(@"Request %@ failed with error: %@", requestIdentifier, error);
	[self showAlertView:msgPostTitle withMessage:[NSString stringWithFormat:@"Request %@ failed with error: %@", requestIdentifier, error] delegate:nil];
	
	switch((int)currentApiCallType)
	{
		case TwitterApiCallPostMessage:
			if ([self.apiCallDelegate respondsToSelector:@selector(failedTwitterPostMessageResponse:)])
				[self.apiCallDelegate failedTwitterPostMessageResponse:requestIdentifier];
			break;
	}
	currentApiCallType = TwitterApiCallNone;
	
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
#pragma mark Twitter Actions
- (void) OAuthTwitterController: (SA_OAuthTwitterController *) controller authenticatedWithUsername: (NSString *) username 
{
	//NSLog(@"LoggedIn With User= %@", username);
	
	if([self.apiCallDelegate respondsToSelector:@selector(userLoginToTwitter:)])
		[self.apiCallDelegate userLoginToTwitter:username];
	
	switch((int)currentApiCallType)
	{
		case TwitterApiCallPostMessage:
			[self postMessageToTwitterWall];
			break;
		case TwitterApiCallPostPicture:
			[self postPictureToTwitterWall];
			break;
		default:
			break;
	}
}
- (void) OAuthTwitterControllerFailed: (SA_OAuthTwitterController *) controller
{	
	//NSLog(@"Authentication Failure");
}
- (void) OAuthTwitterControllerCanceled: (SA_OAuthTwitterController *) controller 
{	
	//NSLog(@"Authentication Canceled");
}
#pragma mark TwitPic delegate
- (void)twitpicDidFinishUpload:(NSDictionary *)response {
	[self showAlertView:msgPostPictureTitle withMessage:msgPostPictureSuccess delegate:nil];
	
	//NSLog(@"Post Picture Success: %@", response);
	
	switch((int)currentApiCallType)
	{
		case TwitterApiCallPostPicture:
			if ([self.apiCallDelegate respondsToSelector:@selector(finishTwitterPostPictureResponse:)])
				[self.apiCallDelegate finishTwitterPostPictureResponse:response];
			break;
	}
	currentApiCallType = TwitterApiCallNone;
	
	NSDictionary *dic = [response objectForKey:@"parsedResponse"];
	NSLog(@"%@",[dic valueForKey:@"url"]);
	
	/*
	[self.objSAOAuthEngine sendUpdate:[dic valueForKey:@"url"]];
	if ([[[response objectForKey:@"request"] userInfo] objectForKey:@"message"] > 0 && [[response objectForKey:@"parsedResponse"] count] > 0) {
		// Uncomment to update status upon successful upload, using MGTwitterEngine's instance.
		// [twitterEngine sendUpdate:[NSString stringWithFormat:@"%@ %@", [[[response objectForKey:@"request"] userInfo] objectForKey:@"message"], [[response objectForKey:@"parsedResponse"] objectForKey:@"url"]]];
	}*/
	
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
- (void)twitpicDidFailUpload:(NSDictionary *)error {
	[self showAlertView:msgPostPictureTitle withMessage:msgPostPictureFail delegate:nil];
	
	//NSLog(@"Post Picture Fail: %@", error);
	
	if ([[error objectForKey:@"request"] responseStatusCode] == 401) {
		//UIAlertViewQuick(@"Authentication failed", [error objectForKey:@"errorDescription"], @"OK");
	}
	
	switch((int)currentApiCallType)
	{
		case TwitterApiCallPostPicture:
			if ([self.apiCallDelegate respondsToSelector:@selector(failedTwitterPostPictureResponse:)])
				[self.apiCallDelegate failedTwitterPostPictureResponse:error];
			break;
	}
	currentApiCallType = TwitterApiCallNone;
	
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}


#pragma mark -
#pragma mark String Methods
- (BOOL)isEmptyString:(NSString *)strValue
{	
	NSString *copy;
	
	if (strValue == nil)
		return (YES);
	
	if ([strValue isEqualToString:@""])
		return (YES);
	
	if ([strValue isEqualToString:@"(null)"])
		return (YES);
	
	copy = [[strValue copy] autorelease];
	
	//if ([[copy trimWhiteSpace] isEqualToString: @""])
	if ([[self trimWhiteSpace:copy] isEqualToString: @""])
		return (YES);
	
	return (NO);
} /*stringIsEmpty*/
- (NSString *) trimWhiteSpace:(NSString *)strValue 
{
	NSMutableString *s = [[strValue mutableCopy] autorelease];
	CFStringTrimWhitespace ((CFMutableStringRef) s);
	return (NSString *) [[s copy] autorelease];
} /*trimWhiteSpace*/

#pragma mark -
#pragma mark Default AlertView
-(void)showAlertView:(NSString *)pstrTitle withMessage:(NSString *)pstrMessage delegate:(id)pDelegate
{
	UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:pstrTitle message:pstrMessage delegate:pDelegate cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alertView show];
	[alertView release];	
}

@end
