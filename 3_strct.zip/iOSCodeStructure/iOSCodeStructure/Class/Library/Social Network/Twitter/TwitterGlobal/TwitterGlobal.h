//
//  TwitterGlobal.h
//  TwitterComponent
//
//  Created by Nishant
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#define kTwitterConsumerKey			@"szicbVWn0kVCoSu2cvw"
#define kTwitterConsumerSecret		@"MujzvjbVqgWgl0ZrTsJhAWpjVuvN0KkVIOrTGWMq7s"
#define kTwitterPicAPIKey           @"ca41665e4a5caba5ca5ee3c16b74946c"

#define kTwitterConsumerApiUrl      @"http://api.twitter.com/"
