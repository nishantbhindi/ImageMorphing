//AppID Missing
#define msgTwitterAppIDMissing              @"Missing Twitter Application ID."

//Session Invalidated
#define msgTwitterSessionInvalidateTitle    @"Auth Exception"
#define msgTwitterSessionInvalidateMessage  @"Your session has expired."

//Test Data
#define msgPostTitle                @"Message Post"
#define msgPostStatusSuccess        @"Message has been post successfully."
#define msgPostStatusFail           @"Failed to post message."

#define msgPostPictureTitle         @"Picture Post"
#define msgPostPictureSuccess       @"Picture has been post successfully."
#define msgPostPictureFail          @"Failed to post picture."

#define msgTwitterPostMessage		@"This is custom twitter message"
