//
//  FacebookManager.m
//  FacebookComponent
//
//  Created by Nishant
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import "FacebookManager.h"

@implementation FacebookManager

@synthesize apiCallDelegate, currentApiCallType;
@synthesize strMessage, strUrl, strPictureUrl, strUrlTitle, strCaption, image;

#pragma mark -
#pragma mark Singleton Variables
static FacebookManager *singletonManager = nil;

#pragma mark -
#pragma mark Singleton Methods
+ (FacebookManager *)sharedInstance {
    @synchronized(self) {
        if(singletonManager == nil)
            singletonManager = [[super allocWithZone:NULL] init];
    }
    return singletonManager;
}
+ (id)allocWithZone:(NSZone *)zone {
    return [[self sharedInstance] retain];
}
- (id)copyWithZone:(NSZone *)zone {
    return self;
}
- (id)retain {
    return self;
}
- (unsigned)retainCount {
    return UINT_MAX; //denotes an object that cannot be released
}
- (oneway void)release {
    // never release
}
- (id)autorelease {
    return self;
}
- (id)init {
    if ((self = [super init])) {
        arrFBPermission = [[NSArray arrayWithObjects:
                            @"email",
                            @"user_birthday",
                            @"user_likes",
                            @"user_location",
                            @"user_photos",
                            @"read_stream",
                            //@"publish_stream",
                            //@"publish_actions",
                            @"status_update",
                            @"user_about_me",
                            @"read_friendlists",
                            @"friends_about_me",
                            @"friends_birthday",
                            @"friends_photos",
                            nil] retain];
    }
    
    return self;
}
- (void)dealloc {
    // Should never be called, but just here for clarity really.
    [self releaseObjects];
	
	[super dealloc];
}
- (void)releaseObjects {
	[self.strMessage release];
    [self.strUrl release];
    [self.strPictureUrl release];
	[self.strUrlTitle release];
	[self.strCaption release];
	[self.image release];
}

#pragma mark - Store/Remove Facebook Authentication
-(void)storeFBAuthData:(NSString *)accessToken expiresAt:(NSDate *)expiresAt{
    //NSLog(@"Access Token: %@", accessToken);
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:accessToken forKey:kFacebookAccessToken];
    [defaults setObject:expiresAt forKey:kFacebookExpirationDate];
    [defaults synchronize];
}
-(void)removeFBAuthData{
	// Remove saved authorization information if it exists and it is
    // ok to clear it (logout, session invalid, app unauthorized)
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:kFacebookAccessToken];
    [defaults removeObjectForKey:kFacebookExpirationDate];
    [defaults synchronize];
}

#pragma mark - String Methods
-(BOOL)isEmptyString:(NSString *)strValue
{
	NSString *copy;
	
	if (strValue == nil)
		return (YES);
	
	if ([strValue isEqualToString:@""])
		return (YES);
	
	if ([strValue isEqualToString:@"(null)"])
		return (YES);
	
	copy = [[strValue copy] autorelease];
	
	//if ([[copy trimWhiteSpace] isEqualToString: @""])
	if ([[self trimWhiteSpace:copy] isEqualToString: @""])
		return (YES);
	
	return (NO);
} /*stringIsEmpty*/
-(NSString *)trimWhiteSpace:(NSString *)strValue
{
	NSMutableString *s = [[strValue mutableCopy] autorelease];
	CFStringTrimWhitespace ((CFMutableStringRef) s);
	return (NSString *) [[s copy] autorelease];
} /*trimWhiteSpace*/

#pragma mark - Show Message
-(void)showMessage:(NSString *)pstrTitle withMessage:(NSString *)pstrMsg withDelegage:(id)pIDDelegate
{
    UIAlertView *objAlertMsg = [[UIAlertView alloc] initWithTitle:pstrTitle
                                                          message:pstrMsg
                                                         delegate:pIDDelegate
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
    [objAlertMsg show];
    [objAlertMsg release];
}

#pragma mark - Facebook Session State Change delegate
- (void)sessionStateChanged:(FBSession *)session
                      state:(FBSessionState) state
                      error:(NSError *)error
{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    
    switch (state) {
        case FBSessionStateOpen: {
            NSLog(@"FBSessionStateOpen");
            
            if([self.apiCallDelegate respondsToSelector:@selector(userLoginToFacebook)])
                [self.apiCallDelegate userLoginToFacebook];
            
            [self storeFBAuthData:session.accessToken expiresAt:session.expirationDate];
            
            switch((int)currentApiCallType)
            {
                case FBApiCallGetUserInfo:
                    [self getUserInfo];
                    break;
                case FBApiCallGetUserFriend:
                    [self getUserFriends];
                    break;
                case FBApiCallPostMessage:
                    [self postStatusUpdateToWall];
                    break;
                case FBApiCallPostPicture:
                    [self postPictureToWall];
                    break;
                case FBApiCallShareLink:
                    [self shareLinkOnWall];
                    break;
                case FBApiCallPostAll:
                    [self postAllToWall];
                    break;
                default:
                    [self getUserInfo];
                    break;
            }
        }
            break;
        case FBSessionStateClosed: {
            NSLog(@"FBSessionStateClosed");
            
            if([self.apiCallDelegate respondsToSelector:@selector(userLogoutFromFacebook)])
                [self.apiCallDelegate userLogoutFromFacebook];
            
            [FBSession.activeSession closeAndClearTokenInformation];
            [self removeFBAuthData];
        }
            break;
        case FBSessionStateClosedLoginFailed: {
            NSLog(@"FBSessionStateClosedLoginFailed");
            
            if([self.apiCallDelegate respondsToSelector:@selector(userLogoutFromFacebook)])
                [self.apiCallDelegate userLogoutFromFacebook];
            
            [FBSession.activeSession closeAndClearTokenInformation];
            [self removeFBAuthData];
        }
            break;
        case FBSessionStateOpenTokenExtended: {
            NSLog(@"FBSessionStateOpenTokenExtended");
            
            [self storeFBAuthData:session.accessToken expiresAt:session.expirationDate];
            
            switch((int)currentApiCallType)
            {
                case FBApiCallGetUserInfo:
                    [self getUserInfo];
                    break;
                case FBApiCallGetUserFriend:
                    [self getUserFriends];
                    break;
                case FBApiCallPostMessage:
                    [self postStatusUpdateToWall];
                    break;
                case FBApiCallPostPicture:
                    [self postPictureToWall];
                    break;
                case FBApiCallShareLink:
                    [self shareLinkOnWall];
                    break;
                case FBApiCallPostAll:
                    [self postAllToWall];
                    break;
                default:
                    break;
            }
        }
            break;
        default:
            break;
    }
    
    if (error)
        [self showMessage:@"Error" withMessage:error.localizedDescription withDelegage:nil];
}

#pragma mark - Public Methods
-(BOOL)isLoggedIn
{
    //if (FBSession.activeSession.state == FBSessionStateCreatedTokenLoaded)
    if (FBSession.activeSession.isOpen)
        return YES;
    else
        return NO;
    
	return NO;
}
-(void)loginToFacebook
{
	if(![self isLoggedIn])
    {
        [FBSession openActiveSessionWithReadPermissions:arrFBPermission
                                           allowLoginUI:YES
                                      completionHandler:
                                                     ^(FBSession *session,
                                                       FBSessionState state,
                                                       NSError *error) {
                                                         [self sessionStateChanged:session state:state error:error];
                                                     }];
        
        /*[FBSession openActiveSessionWithReadPermissions:nil
                                           allowLoginUI:YES
                                      completionHandler:
         ^(FBSession *session,
           FBSessionState state, NSError *error) {
             [self sessionStateChanged:session state:state error:error];
         }];*/
    }	
}
-(void)logoutFromFacebook {
    [FBSession.activeSession closeAndClearTokenInformation];
	
	[self removeFBAuthData];
}
-(void)askForPermission:(NSString *)pstrPermission
{
    // No permissions found in session, ask for it
    [FBSession.activeSession
     reauthorizeWithPublishPermissions:
     [NSArray arrayWithObject:pstrPermission]
     defaultAudience:FBSessionDefaultAudienceFriends
     completionHandler:^(FBSession *session, NSError *error) {
         if (!error) {
             
             // If permissions granted
             switch((int)currentApiCallType)
             {
                 case FBApiCallShareLink:
                     [self shareLinkOnWall];
                     break;
                 case FBApiCallPostAll:
                     [self postAllToWall];
                     break;
                 default:
                     break;
             }
         }
     }];
}

#pragma mark - Facebook Methods
-(void)getUserInfo
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	currentApiCallType = FBApiCallGetUserInfo;
    
	if([self isLoggedIn])
	{
		[FBRequestConnection
         startForMeWithCompletionHandler:^(FBRequestConnection *connection,
                                           id<FBGraphUser> user,
                                           NSError *error) {
             if (!error) {
                 if([self.apiCallDelegate respondsToSelector:@selector(successUserInfoResponse:)])
                     [self.apiCallDelegate successUserInfoResponse:user];
             }
             else{
                 if ([self.apiCallDelegate respondsToSelector:@selector(failedUserInfoResponse:)])
                     [self.apiCallDelegate failedUserInfoResponse:error];
             }
             
             [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
             currentApiCallType = FBApiCallNone;
         }];
	}
	else
		[self loginToFacebook];
}
-(void)getUserFriends
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	currentApiCallType = FBApiCallGetUserFriend;
    
	if([self isLoggedIn])
	{
		FBFriendPickerViewController *friendPickerController = [[FBFriendPickerViewController alloc] init];
        friendPickerController.title = @"Select Friends";
        // Ask for friend device data
        //friendPickerController.fieldsForRequest = [NSSet setWithObjects:@"devices", nil];
        [friendPickerController loadData];
        
        // Use the modal wrapper method to display the picker.
        [friendPickerController presentModallyFromViewController:(UIViewController *)self.apiCallDelegate animated:YES handler:
         ^(FBViewController *sender, BOOL donePressed) {
             
             [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
             currentApiCallType = FBApiCallNone;
             
             if (!donePressed) {
                 return;
             }
             
             if([self.apiCallDelegate respondsToSelector:@selector(successUserFriendResponse:)])
                 [self.apiCallDelegate successUserFriendResponse:friendPickerController];
         }];
	}
	else
		[self loginToFacebook];
}
-(void)postStatusUpdateToWall
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	currentApiCallType = FBApiCallPostMessage;
    
	if([self isLoggedIn])
	{
        [FBRequestConnection startForPostStatusUpdate:self.strMessage
                                    completionHandler:^(FBRequestConnection *connection,
                                                        id result,
                                                        NSError *error) {
                                        
            if (!error) {
                if([self.apiCallDelegate respondsToSelector:@selector(successPostStatusResponse:)])
                    [self.apiCallDelegate successPostStatusResponse:result];
            }
            else{
                if ([self.apiCallDelegate respondsToSelector:@selector(failedPostStatusResponse:)])
                    [self.apiCallDelegate failedPostStatusResponse:error];
            }
            
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            currentApiCallType = FBApiCallNone;
        }];
	}
	else
		[self loginToFacebook];
}
-(void)postPictureToWall
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	currentApiCallType = FBApiCallPostPicture;
    
	if([self isLoggedIn])
	{
		[FBRequestConnection startForUploadPhoto:self.image
                               completionHandler:^(FBRequestConnection *connection,
                                                   id result,
                                                   NSError *error) {
               if (!error) {
                   if([self.apiCallDelegate respondsToSelector:@selector(successPostPictureResponse:)])
                       [self.apiCallDelegate successPostPictureResponse:result];
               }
               else{
                   if ([self.apiCallDelegate respondsToSelector:@selector(failedPostPictureResponse:)])
                       [self.apiCallDelegate failedPostPictureResponse:error];
               }
                                   
               [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
               currentApiCallType = FBApiCallNone;
        }];
	}
	else
		[self loginToFacebook];
}
-(void)shareLinkOnWall
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	currentApiCallType = FBApiCallShareLink;
    
	if([self isLoggedIn])
	{
        if ([FBSession.activeSession.permissions
             indexOfObject:@"publish_actions"] == NSNotFound) {
            
            [self askForPermission:@"publish_actions"];
        }
        else {
            NSMutableDictionary *postParams = [[[NSMutableDictionary alloc] initWithObjectsAndKeys:
                                               self.strUrl, @"link",
                                               self.strUrlTitle, @"name",
                                               self.strCaption, @"caption",
                                               self.strMessage, @"description",
                                               nil] autorelease];
            
            [FBRequestConnection
             startWithGraphPath:@"me/feed"
             parameters:postParams
             HTTPMethod:@"POST"
             completionHandler:^(FBRequestConnection *connection,
                                 id result,
                                 NSError *error) {
                 
                 if (!error) {
                     if([self.apiCallDelegate respondsToSelector:@selector(successShareLinkResponse:)])
                         [self.apiCallDelegate successShareLinkResponse:result];
                 }
                 else{
                     if ([self.apiCallDelegate respondsToSelector:@selector(failedShareLinkResponse:)])
                         [self.apiCallDelegate failedShareLinkResponse:error];
                 }
                 
                 [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
                 currentApiCallType = FBApiCallNone;
             }];
        }
	}
	else
		[self loginToFacebook];
}
-(void)postAllToWall
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	currentApiCallType = FBApiCallPostAll;
    
	if([self isLoggedIn])
	{
        if ([FBSession.activeSession.permissions
             indexOfObject:@"publish_actions"] == NSNotFound) {
            
            [self askForPermission:@"publish_actions"];
        }
        else {
            
            NSMutableDictionary *postParams = [[[NSMutableDictionary alloc] initWithObjectsAndKeys:
                                               self.strUrl, @"link",
                                               self.strPictureUrl, @"picture",
                                               self.strUrlTitle, @"name",
                                               self.strCaption, @"caption",
                                               self.strMessage, @"description",
                                               nil] autorelease];
            
            [FBRequestConnection
             startWithGraphPath:@"me/feed"
             parameters:postParams
             HTTPMethod:@"POST"
             completionHandler:^(FBRequestConnection *connection,
                                 id result,
                                 NSError *error) {
                 
                 if (!error) {
                     if([self.apiCallDelegate respondsToSelector:@selector(successPostAllResponse:)])
                         [self.apiCallDelegate successPostAllResponse:result];
                 }
                 else{
                     if ([self.apiCallDelegate respondsToSelector:@selector(failedPostAllResponse:)])
                         [self.apiCallDelegate failedPostAllResponse:error];
                 }
                 
                 [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
                 currentApiCallType = FBApiCallNone;
                 
             }];
        }
	}
	else
		[self loginToFacebook];
}

@end
