//
//  FacebookManager.h
//  FacebookComponent
//
//  Created by Nishant
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol FBApiCallDelegate;

typedef enum FBApiCallType
{
	FBApiCallNone = 0,
	FBApiCallGetUserInfo = 1,
	FBApiCallGetUserFriend = 2,
	FBApiCallPostMessage = 3,
	FBApiCallPostPicture = 4,
	FBApiCallShareLink = 5,
	FBApiCallPostAll = 6,
	FBApiCallPostMessageFriendWall = 7
	
} FBApiCallType;

@interface FacebookManager : NSObject <FBLoginViewDelegate>{
    NSArray *arrFBPermission;
	
	id<FBApiCallDelegate> apiCallDelegate;
	FBApiCallType currentApiCallType;
	
	NSString *strMessage;
	NSString *strUrl;
	NSString *strPictureUrl;
    NSString *strUrlTitle;
    NSString *strCaption;
	UIImage *image;
}
@property (nonatomic, assign) id<FBApiCallDelegate> apiCallDelegate;
@property (nonatomic, assign) FBApiCallType currentApiCallType;

@property (nonatomic, retain) NSString *strMessage;
@property (nonatomic, retain) NSString *strUrl;
@property (nonatomic, retain) NSString *strPictureUrl;
@property (nonatomic, retain) NSString *strUrlTitle;
@property (nonatomic, retain) NSString *strCaption;
@property (nonatomic, retain) UIImage *image;


+(FacebookManager *) sharedInstance;
-(void)releaseObjects;

// Store/Remove Facebook Authentication
-(void)storeFBAuthData:(NSString *)accessToken expiresAt:(NSDate *)expiresAt;
-(void)removeFBAuthData;

// String Methods
-(BOOL)isEmptyString:(NSString *)strValue;
-(NSString *)trimWhiteSpace:(NSString *)strValue;

// Show Message
-(void)showMessage:(NSString *)pstrTitle withMessage:(NSString *)pstrMsg withDelegage:(id)pIDDelegate;

//Public Methods
-(BOOL)isLoggedIn;
-(void)loginToFacebook;
-(void)logoutFromFacebook;
-(void)askForPermission:(NSString *)pstrPermission;

//Facebook Methods
-(void)getUserInfo;					//Get User Info
-(void)getUserFriends;				//Get User's Friend List

-(void)postStatusUpdateToWall;		//Post Status Update Message to FB Wall
-(void)postPictureToWall;			//Post Picture to FB Wall
-(void)shareLinkOnWall;				//Share Link on FB Wall
-(void)postAllToWall;				//Post All - Link, PhotoUrl, Name, Caption, Description

@end

@protocol FBApiCallDelegate <NSObject>

@optional

//User LogInLogout
-(void)userLoginToFacebook;
-(void)userLogoutFromFacebook;

//Get User Info Delegate
-(void)successUserInfoResponse:(id<FBGraphUser>)user;
-(void)failedUserInfoResponse:(NSError *)error;

//Get User's Friend List
-(void)successUserFriendResponse:(FBFriendPickerViewController *)pobjFriendPicker;
-(void)failedUserFriendResponse:(NSError *)error;

//Post Status Update Message to FB Wall Delegate
-(void)successPostStatusResponse:(id)result;
-(void)failedPostStatusResponse:(NSError *)error;

//Post Picture to FB Wall
-(void)successPostPictureResponse:(id)result;
-(void)failedPostPictureResponse:(NSError *)error;

//Share Link on FB Wall
-(void)successShareLinkResponse:(id)result;
-(void)failedShareLinkResponse:(NSError *)error;

//Post All - Link, PhotoUrl, Name, Caption, Description
-(void)successPostAllResponse:(id)result;
-(void)failedPostAllResponse:(NSError *)error;

@end
