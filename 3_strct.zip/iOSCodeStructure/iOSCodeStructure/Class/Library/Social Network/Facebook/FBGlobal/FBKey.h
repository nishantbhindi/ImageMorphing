//
//  FBKey.h
//  FacebookComponent
//
//  Created by Nishant
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#define kFacebookAccessToken		@"FacebookAccessTokenKey"
#define kFacebookExpirationDate     @"FacebookExpirationDateKey"
