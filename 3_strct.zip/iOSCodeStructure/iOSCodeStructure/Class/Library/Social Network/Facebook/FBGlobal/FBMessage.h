//
//  FBMessage.h
//  FacebookComponent
//
//  Created by Nishant
//  Copyright (c) 2013 Nishant. All rights reserved.
//

//AppID Missing
#define msgFacebookAppIDMissing                 @"Missing Facebook Application ID."

//Session Invalidated
#define msgFacebookSessionInvalidateTitle       @"Auth Exception"
#define msgFacebookSessionInvalidateMessage     @"Your session has been expired."


//Test Data
#define msgPostStatus           @"This is custom facebook message."
#define msgPostUrl				@"https://developers.facebook.com/ios"
#define msgPostPictureUrl		@"https://developers.facebook.com/attachment/iossdk_logo.png"
#define msgPostUrlTitle			@"Facebook SDK for iOS"
#define msgPostCaption			@"Social Network"
#define msgPostDescription      @"The Facebook SDK for iOS makes it easier and faster to develop Facebook integrated iOS apps."