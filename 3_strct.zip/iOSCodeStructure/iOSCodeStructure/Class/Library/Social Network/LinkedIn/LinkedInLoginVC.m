//
//  LinkedInLoginVC.m
//  BestBetting
//
//  Created by WebInfoways on 30/03/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import "LinkedInLoginVC.h"

@interface LinkedInLoginVC ()

@end

@implementation LinkedInLoginVC

@synthesize objConsumer, objRequestToken, objAccessToken;
@synthesize dicProfile;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [self initializeLinkedInApi];
}

#pragma mark - Initialize LinkedIn APIs
- (void)initializeLinkedInApi
{
    self.objConsumer = [[OAConsumer alloc] initWithKey:kLinkedInApiKey
                                             secret:kLinkedInSecretKey
                                              realm:kLinkedConsumerApiUrl];
}
- (void)viewDidAppear:(BOOL)animated
{
    [self requestTokenFromProvider];
}

#pragma mark - Post Notifications
- (void)postNotificationLoginSuccess
{
    NSDictionary *dicUserInfo = [NSDictionary dictionaryWithObject:@"Login Success" forKey:kLinkedInMessage];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"LinkedInLoginFinish" object:nil userInfo:dicUserInfo];
    //[[NSNotificationCenter defaultCenter] postNotificationName:@"LinkedInLoginFinish" object:self];
    [FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
}
- (void)postNotificationLoginFail:(NSString *)pstrError
{
    NSDictionary *dicUserInfo = [NSDictionary dictionaryWithObject:pstrError forKey:kLinkedInMessage];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"LinkedInLoginFail" object:nil userInfo:dicUserInfo];
    [FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
}
- (void)postNotificationAppAccessDenied:(NSString *)pstrError
{
    NSDictionary *dicUserInfo = [NSDictionary dictionaryWithObject:pstrError forKey:kLinkedInMessage];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"LinkedInAppAccessDenied" object:nil userInfo:dicUserInfo];
    [FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
}
- (void)postNotificationAccessTokenFail:(NSString *)pstrError
{
    NSDictionary *dicUserInfo = [NSDictionary dictionaryWithObject:pstrError forKey:kLinkedInMessage];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"LinkedInAccessTokenFail" object:nil userInfo:dicUserInfo];
    [FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
}

#pragma mark - Request Token
- (void)requestTokenFromProvider
{
    [FunctionManager displayLoadingView:self.view withMessage:msgLoadingGeneral appDelegate:appDelegate viewController:self];
    
    OAMutableURLRequest *request =
    [[[OAMutableURLRequest alloc] initWithURL:[kLinkedReuestTokenUrl toURL]
                                     consumer:self.objConsumer
                                        token:nil
                                     callback:kLinkedCallBackUrl
                            signatureProvider:nil] autorelease];
    [request setHTTPMethod:@"POST"];
    
    OARequestParameter *nameParam = [[OARequestParameter alloc] initWithName:@"scope"
                                                                       value:@"r_basicprofile+rw_nus"];
    NSArray *params = [NSArray arrayWithObjects:nameParam, nil];
    [request setParameters:params];
    
    //OARequestParameter *scopeParameter=[OARequestParameter requestParameter:@"scope" value:@"r_fullprofile rw_nus"];
    OARequestParameter *scopeParameter=[OARequestParameter requestParameter:@"scope" value:@"r_fullprofile r_emailaddress"];
    [request setParameters:[NSArray arrayWithObject:scopeParameter]];
    
    OADataFetcher *fetcher = [[[OADataFetcher alloc] init] autorelease];
    [fetcher fetchDataWithRequest:request
                         delegate:self
                didFinishSelector:@selector(requestTokenResult:didFinish:)
                  didFailSelector:@selector(requestTokenResult:didFail:)];
}
- (void)requestTokenResult:(OAServiceTicket *)ticket didFinish:(NSData *)data
{
    if (ticket.didSucceed == NO){
        [self postNotificationLoginFail:msgLinkedInRequestTokenFail];
        return;
    }
    
    NSString *responseBody = [[NSString alloc] initWithData:data
                                                   encoding:NSUTF8StringEncoding];
    self.objRequestToken = [[OAToken alloc] initWithHTTPResponseBody:responseBody];
    [responseBody release];
    
    [self allowUserToLogin];
}
- (void)requestTokenResult:(OAServiceTicket *)ticket didFail:(NSData *)error
{
    //[FunctionManager showMessage:@"Request Token" withMessage:[error description] withDelegage:nil];
    [self postNotificationLoginFail:[error description]];
}

#pragma mark - Login
- (void)allowUserToLogin
{
    NSString *userLoginURLWithToken = [NSString stringWithFormat:@"%@?oauth_token=%@",
                                       kLinkedAuthorizeUrl, self.objRequestToken.key];
    NSURLRequest *request = [NSMutableURLRequest requestWithURL: [userLoginURLWithToken toURL]];
    [webViewLinkedIn loadRequest:request];
}

#pragma mark - webView delegate
- (void)webViewDidStartLoad:(UIWebView *)webView
{    
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
	NSURL *url = request.URL;
	NSString *urlString = url.absoluteString;
    
    BOOL requestForCallbackURL = ([urlString rangeOfString:kLinkedCallBackUrl].location != NSNotFound);
    if ( requestForCallbackURL )
    {
        BOOL userAllowedAccess = ([urlString rangeOfString:@"user_refused"].location == NSNotFound);
        if ( userAllowedAccess )
        {
            [self.objRequestToken setVerifierWithUrl:url];
            [self accessTokenFromProvider];
        }
        else
        {
            // User refused to allow our app access
            [self postNotificationAppAccessDenied:msgLinkedInAllowAppAccess];
            [self dismissModalViewControllerAnimated:YES];
        }
    }
    else
    {
        // Case (a) or (b), so ignore it
    }
	return YES;
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{    
}

#pragma mark - Access Token
- (void)accessTokenFromProvider
{
    [FunctionManager displayLoadingView:self.view withMessage:msgLoadingGeneral appDelegate:appDelegate viewController:self];
    
    OAMutableURLRequest *request =
    [[[OAMutableURLRequest alloc] initWithURL:[kLinkedAccessTokenUrl toURL]
                                     consumer:self.objConsumer
                                        token:self.objRequestToken
                                     callback:nil
                            signatureProvider:nil] autorelease];
    [request setHTTPMethod:@"POST"];
    
    OADataFetcher *fetcher = [[[OADataFetcher alloc] init] autorelease];
    [fetcher fetchDataWithRequest:request
                         delegate:self
                didFinishSelector:@selector(accessTokenResult:didFinish:)
                  didFailSelector:@selector(accessTokenResult:didFail:)];
}
- (void)accessTokenResult:(OAServiceTicket *)ticket didFinish:(NSData *)data
{
    NSString *responseBody = [[NSString alloc] initWithData:data
                                                   encoding:NSUTF8StringEncoding];
    
    BOOL problem = ([responseBody rangeOfString:@"oauth_problem"].location != NSNotFound);
    if ( problem )
    {
        //NSLog(@"Request access token failed. = %@",responseBody);
        [self postNotificationAccessTokenFail:msgLinkedInAccessTokenFail];
    }
    else
    {
        self.objAccessToken = [[OAToken alloc] initWithHTTPResponseBody:responseBody];
        [self postNotificationLoginSuccess];
    }
    
    [self dismissModalViewControllerAnimated:YES];
    [responseBody release];
}
- (void)accessTokenResult:(OAServiceTicket *)ticket didFail:(NSData *)error
{
    //[FunctionManager showMessage:@"Access Token" withMessage:[error description] withDelegage:nil];
    [self postNotificationAccessTokenFail:[error description]];
}

#pragma mark - Close
-(IBAction)btnTappedClose:(id)sender
{
    [self dismissModalViewControllerAnimated:YES];
}

#pragma mark - Orientations
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
	[self.dicProfile release];
    
    [webViewLinkedIn release];
    
    [super dealloc];
}

@end
