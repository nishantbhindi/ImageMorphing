//
//  LinkedInManager.m
//  BestBetting
//
//  Created by WebInfoways on 30/03/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import "LinkedInManager.h"

@implementation LinkedInManager

@synthesize objLinkedInLoginVC;
@synthesize apiCallDelegate, currentApiCallType;
@synthesize strMessage, strUrl, strPictureUrl, strUrlTitle, strCaption, image;

#pragma mark -
#pragma mark Singleton Variables
static LinkedInManager *singletonManager = nil;

#pragma mark -
#pragma mark Singleton Methods
+ (LinkedInManager *)sharedInstance {
    @synchronized(self) {
        if(singletonManager == nil)
            singletonManager = [[super allocWithZone:NULL] init];
    }
    return singletonManager;
}
+ (id)allocWithZone:(NSZone *)zone {
    return [[self sharedInstance] retain];
}
- (id)copyWithZone:(NSZone *)zone {
    return self;
}
- (id)retain {
    return self;
}
- (unsigned)retainCount {
    return UINT_MAX; //denotes an object that cannot be released
}
- (oneway void)release {
    // never release
}
- (id)autorelease {
    return self;
}
- (id)init {
    if ((self = [super init])) {
        arrLIPermission = [[NSArray arrayWithObjects:
                            @"email",
                            @"firstName",
                            @"lastName",
                            @"headline",
                            @"user_birthday",
                            @"user_location",
                            @"user_photos",
                            @"status_update",
                            @"user_about_me",
                            nil] retain];
        
        
        if(g_IS_IPHONE_5_SCREEN)
            objLinkedInLoginVC = [[[LinkedInLoginVC alloc] initWithNibName:@"LinkedInLoginVC" bundle:nil] autorelease];
        else
            objLinkedInLoginVC = [[[LinkedInLoginVC alloc] initWithNibName:@"LinkedInLoginVC4" bundle:nil] autorelease];
        
        //objLinkedInLoginVC = [[[LinkedInLoginVC alloc] initWithNibName:nil bundle:nil] autorelease];
        [objLinkedInLoginVC retain];
        
        //Add Observer
        [self addNotificationObserver];
    }
    
    return self;
}
- (void)dealloc {
    // Should never be called, but just here for clarity really.
    [self releaseObjects];
	
	[super dealloc];
}
- (void)releaseObjects {
	[self.strMessage release];
    [self.strUrl release];
    [self.strPictureUrl release];
	[self.strUrlTitle release];
	[self.strCaption release];
	[self.image release];
}

#pragma mark - Store/Remove Authentication
-(void)storeLIAuthData:(NSString *)accessToken expiresAt:(NSDate *)expiresAt{
    //NSLog(@"Access Token: %@", accessToken);
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:accessToken forKey:kLinkedInAccessToken];
    [defaults setObject:expiresAt forKey:kLinkedInExpirationDate];
    [defaults synchronize];
}
-(void)removeLIAuthData{
	// Remove saved authorization information if it exists and it is
    // ok to clear it (logout, session invalid, app unauthorized)
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:kLinkedInAccessToken];
    [defaults removeObjectForKey:kLinkedInExpirationDate];
    [defaults synchronize];
}

#pragma mark - LinkedIn Login Notification
-(void)addNotificationObserver
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(LinkedInLoginDidFinish:)
                                                 name:@"LinkedInLoginFinish"
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(LinkedInLoginDidFail:)
                                                 name:@"LinkedInLoginFail"
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(LinkedInAppAccessFail:)
                                                 name:@"LinkedInAppAccessDenied"
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(LinkedInAccessTokenFail:)
                                                 name:@"LinkedInAccessTokenFail"
                                               object:nil];
}
-(void)LinkedInLoginDidFinish:(NSNotification*)notification
{
    //NSDictionary *userInfo = notification.userInfo;
    //[FunctionManager showMessage:@"" withMessage:[userInfo objectForKey:kLinkedInMessage] withDelegage:nil];
	[[NSNotificationCenter defaultCenter] removeObserver:self];
    
    switch((int)currentApiCallType)
    {
        case LIApiCallGetUserInfo:
            [self getUserInfo];
            break;
        case LIApiCallPostMessage:
            [self postStatusUpdateToWall];
            break;
        default:
            break;
    }
}
-(void)LinkedInLoginDidFail:(NSNotification*)notification
{
    NSDictionary *userInfo = notification.userInfo;
    [FunctionManager showMessage:@"" withMessage:[userInfo objectForKey:kLinkedInMessage] withDelegage:nil];
	[[NSNotificationCenter defaultCenter] removeObserver:self];
    
    switch((int)currentApiCallType)
    {
        case LIApiCallGetUserInfo:
            /*if ([self.apiCallDelegate respondsToSelector:@selector(failedUserInfoResponseLI:)])
             [self.apiCallDelegate failedUserInfoResponseLI:error];*/
            break;
        case LIApiCallPostMessage:
            /*if ([self.apiCallDelegate respondsToSelector:@selector(failedPostStatusResponse:)])
             [self.apiCallDelegate failedPostStatusResponse:error];*/
            break;
        default:
            break;
    }
}
-(void)LinkedInAppAccessFail:(NSNotification*)notification
{
    NSDictionary *userInfo = notification.userInfo;
    [FunctionManager showMessage:@"" withMessage:[userInfo objectForKey:kLinkedInMessage] withDelegage:nil];
	[[NSNotificationCenter defaultCenter] removeObserver:self];
    
    switch((int)currentApiCallType)
    {
        case LIApiCallGetUserInfo:
            /*if ([self.apiCallDelegate respondsToSelector:@selector(failedUserInfoResponseLI:)])
             [self.apiCallDelegate failedUserInfoResponseLI:error];*/
            break;
        case LIApiCallPostMessage:
            /*if ([self.apiCallDelegate respondsToSelector:@selector(failedPostStatusResponse:)])
             [self.apiCallDelegate failedPostStatusResponse:error];*/
            break;
        default:
            break;
    }
}
-(void)LinkedInAccessTokenFail:(NSNotification*)notification
{
    NSDictionary *userInfo = notification.userInfo;
    [FunctionManager showMessage:@"" withMessage:[userInfo objectForKey:kLinkedInMessage] withDelegage:nil];
	[[NSNotificationCenter defaultCenter] removeObserver:self];
    
    switch((int)currentApiCallType)
    {
        case LIApiCallGetUserInfo:
            /*if ([self.apiCallDelegate respondsToSelector:@selector(failedUserInfoResponseLI:)])
             [self.apiCallDelegate failedUserInfoResponseLI:error];*/
            break;
        case LIApiCallPostMessage:
            /*if ([self.apiCallDelegate respondsToSelector:@selector(failedPostStatusResponse:)])
             [self.apiCallDelegate failedPostStatusResponse:error];*/
            break;
        default:
            break;
    }
}

#pragma mark - Public Methods
-(BOOL)isLoggedIn
{
    if (objLinkedInLoginVC.objConsumer && objLinkedInLoginVC.objAccessToken)
        return YES;
    else
        return NO;
    
	return NO;
}
-(void)loginToLinkedIn
{
	if(![self isLoggedIn])
    {
        [self addNotificationObserver];
        [(UIViewController *)self.apiCallDelegate presentModalViewController:objLinkedInLoginVC animated:YES];
        //[self presentModalViewController:objLinkedInLoginVC animated:YES];
    }
}
-(void)logoutFromLinkedIn {
    //[LinkedInSession.activeSession closeAndClearTokenInformation];
	[self removeLIAuthData];
}

#pragma mark - LinkedIn Methods
#pragma mark Get User Info
-(void)getUserInfo
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	currentApiCallType = LIApiCallGetUserInfo;
    
	if([self isLoggedIn])
	{
        OAMutableURLRequest *objUrlRequest =
        [[OAMutableURLRequest alloc] initWithURL:[kLinkedProfileUrl toURL]
                                        consumer:objLinkedInLoginVC.objConsumer
                                           token:objLinkedInLoginVC.objAccessToken
                                        callback:nil
                               signatureProvider:nil];
        
        [objUrlRequest setValue:@"json" forHTTPHeaderField:@"x-li-format"];
        
        OADataFetcher *objFetcher = [[OADataFetcher alloc] init];
        [objFetcher fetchDataWithRequest:objUrlRequest
                             delegate:self
                    didFinishSelector:@selector(userInfoResult:didFinish:)
                      didFailSelector:@selector(userInfoResult:didFail:)];
        [objUrlRequest release];
	}
	else
		[self loginToLinkedIn];
}
- (void)userInfoResult:(OAServiceTicket *)ticket didFinish:(NSData *)data
{
    NSString *strResponseBody = [[NSString alloc] initWithData:data
                                                   encoding:NSUTF8StringEncoding];
    NSDictionary *dicUserProfile = [strResponseBody objectFromJSONString];
    [strResponseBody release];
    
    if ( dicUserProfile )
    {
        if ([self.apiCallDelegate respondsToSelector:@selector(successUserInfoResponseLI:)])
            [self.apiCallDelegate successUserInfoResponseLI:dicUserProfile];
    }
    else
    {
        if ([self.apiCallDelegate respondsToSelector:@selector(successUserInfoResponseLI:)])
            [self.apiCallDelegate successUserInfoResponseLI:nil];
    }
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
- (void)userInfoResult:(OAServiceTicket *)ticket didFail:(NSData *)error
{
    [FunctionManager showMessage:@"User Info" withMessage:[error description] withDelegage:nil];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    
    /*if ([self.apiCallDelegate respondsToSelector:@selector(failedUserInfoResponseLI:)])
        [self.apiCallDelegate failedUserInfoResponseLI:error];*/
}

#pragma mark Post Status On Wall
-(void)postStatusUpdateToWall
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	currentApiCallType = LIApiCallPostMessage;
    
	if([self isLoggedIn])
	{
        OAMutableURLRequest *objUrlRequest =
        [[OAMutableURLRequest alloc] initWithURL:[kLinkedPostStatusUrl toURL]
                                        consumer:objLinkedInLoginVC.objConsumer
                                           token:objLinkedInLoginVC.objAccessToken
                                        callback:nil
                               signatureProvider:nil];
        
        NSDictionary *dicUpdate = [[NSDictionary alloc] initWithObjectsAndKeys:
                                [[NSDictionary alloc]
                                 initWithObjectsAndKeys:
                                 @"anyone",@"code",nil], @"visibility",
                                self.strMessage, @"comment", nil];
        NSString *strUpdate = [dicUpdate JSONString];
        
        [objUrlRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        [objUrlRequest setHTTPBodyWithString:strUpdate];
        [objUrlRequest setHTTPMethod:@"POST"];
        
        OADataFetcher *objFetcher = [[OADataFetcher alloc] init];
        [objFetcher fetchDataWithRequest:objUrlRequest
                             delegate:self
                    didFinishSelector:@selector(postStatusResult:didFinish:)
                      didFailSelector:@selector(postStatusResult:didFail:)];
        [objUrlRequest release];
	}
	else
		[self loginToLinkedIn];
}
- (void)postStatusResult:(OAServiceTicket *)ticket didFinish:(NSData *)data
{
    if ([self.apiCallDelegate respondsToSelector:@selector(successPostStatusResponse)])
        [self.apiCallDelegate successPostStatusResponse];
 
    [FunctionManager showMessage:@"Post Status" withMessage:msgLinkedInPostStatusSuccess withDelegage:nil];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
- (void)postStatusResult:(OAServiceTicket *)ticket didFail:(NSData *)error
{
    [FunctionManager showMessage:@"Post Status" withMessage:[error description] withDelegage:nil];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    
    /*if ([self.apiCallDelegate respondsToSelector:@selector(failedPostStatusResponse:)])
        [self.apiCallDelegate failedPostStatusResponse:error];*/
}

@end
