//
//  LinkedInManager.h
//  BestBetting
//
//  Created by WebInfoways on 30/03/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LinkedInLoginVC.h"

@protocol LinkedInApiCallDelegate;

typedef enum LinkedInApiCallType
{
	LIApiCallNone = 0,
	LIApiCallGetUserInfo = 1,
	LIApiCallGetUserFriend = 2,
	LIApiCallPostMessage = 3,
	LIApiCallPostPicture = 4,
	LIApiCallShareLink = 5,
	LIApiCallPostAll = 6,
	LIApiCallPostMessageFriendWall = 7
	
} LinkedInApiCallType;

@interface LinkedInManager : NSObject{
    NSArray *arrLIPermission;
	
	id<LinkedInApiCallDelegate> apiCallDelegate;
	LinkedInApiCallType currentApiCallType;
	
	NSString *strMessage;
	NSString *strUrl;
	NSString *strPictureUrl;
    NSString *strUrlTitle;
    NSString *strCaption;
	UIImage *image;
}
@property (nonatomic, retain) LinkedInLoginVC *objLinkedInLoginVC;

@property (nonatomic, assign) id<LinkedInApiCallDelegate> apiCallDelegate;
@property (nonatomic, assign) LinkedInApiCallType currentApiCallType;

@property (nonatomic, retain) NSString *strMessage;
@property (nonatomic, retain) NSString *strUrl;
@property (nonatomic, retain) NSString *strPictureUrl;
@property (nonatomic, retain) NSString *strUrlTitle;
@property (nonatomic, retain) NSString *strCaption;
@property (nonatomic, retain) UIImage *image;


+(LinkedInManager *) sharedInstance;
-(void)releaseObjects;

// Store/Remove Authentication
-(void)storeLIAuthData:(NSString *)accessToken expiresAt:(NSDate *)expiresAt;
-(void)removeLIAuthData;

// Add Notification Observer
-(void)addNotificationObserver;

//Public Methods
-(BOOL)isLoggedIn;
-(void)loginToLinkedIn;
-(void)logoutFromLinkedIn;

//LinkedIn Methods
-(void)getUserInfo;					//Get User Info
-(void)postStatusUpdateToWall;		//Post Status Update Message to LI Wall

@end

@protocol LinkedInApiCallDelegate <NSObject>

@optional

//User LogInLogout
-(void)userLoginToLinkedIn;
-(void)userLogoutFromLinkedIn;

//Get User Info Delegate
-(void)successUserInfoResponseLI:(NSDictionary *)dicUser;
-(void)failedUserInfoResponseLI:(NSError *)error;

//Post Status Update Message to LI Wall Delegate
-(void)successPostStatusResponse;
-(void)failedPostStatusResponse:(NSError *)error;

@end
