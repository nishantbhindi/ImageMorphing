//
//  LinkedInLoginVC.h
//  BestBetting
//
//  Created by WebInfoways on 30/03/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppDelegate;

@interface LinkedInLoginVC : UIViewController <UIWebViewDelegate>
{
    AppDelegate *appDelegate;
    
    IBOutlet UIWebView *webViewLinkedIn;
    
    OAConsumer *objConsumer;
    OAToken *objRequestToken;
    OAToken *objAccessToken;
    
    NSDictionary *dicProfile;
}

@property(nonatomic, retain) OAConsumer *objConsumer;
@property(nonatomic, retain) OAToken *objRequestToken;
@property(nonatomic, retain) OAToken *objAccessToken;
@property(nonatomic, retain) NSDictionary *dicProfile;

- (void)initializeLinkedInApi;

- (void)requestTokenFromProvider;
- (void)allowUserToLogin;
- (void)accessTokenFromProvider;

- (void)postNotificationLoginSuccess;
- (void)postNotificationLoginFail:(NSString *)pstrError;
- (void)postNotificationAppAccessDenied:(NSString *)pstrError;
- (void)postNotificationAccessTokenFail:(NSString *)pstrError;

-(IBAction)btnTappedClose:(id)sender;

@end
