//
//  LinkedInGlobal.h
//  BestBetting
//
//  Created by WebInfoways on 30/03/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

//App Keys/Secret
#define kLinkedInApiKey                         @"324on68utfre"
#define kLinkedInSecretKey                      @"9IiiYoJeWnsVG7JY"

//LinkedIn URLs
#define kLinkedConsumerApiUrl                   @"http://api.linkedin.com/"
#define kLinkedReuestTokenUrl                   @"https://api.linkedin.com/uas/oauth/requestToken"
#define kLinkedAccessTokenUrl                   @"https://api.linkedin.com/uas/oauth/accessToken"
#define kLinkedAuthorizeUrl                     @"https://www.linkedin.com/uas/oauth/authorize"
#define kLinkedCallBackUrl                      @"hdlinked://linkedin/oauth"


#define kLinkedPostStatusUrl                    @"http://api.linkedin.com/v1/people/~/shares"
//#define kLinkedProfileUrl                     @"http://api.linkedin.com/v1/people/~"


//#define kLinkedProfileUrl                       @"http://api.linkedin.com/v1/people/~:(id,first-name,last-name,maiden-name,formatted-name,phonetic-last-name,location:(country:(code)),industry,distance,current-status,current-share,network,skills,phone-numbers,date-of-birth,main-address,positions:(title),educations:(school-name,field-of-study,start-date,end-date,degree,activities))"

#define kLinkedProfileUrl                       @"http://api.linkedin.com/v1/people/~:(id,first-name,last-name,maiden-name,formatted-name,phonetic-last-name,email-address,location:(country:(code)),current-status,phone-numbers,date-of-birth,main-address)"



//Remember Key
#define kLinkedInAccessToken                    @"LinkedInAccessTokenKey"
#define kLinkedInExpirationDate                 @"LinkedInExpirationDateKey"

//Message
//AppID Missing
#define msgLinkedInKeyMissing                   @"Missing LinkedIn ApiKey and SecretKey."

//Session Invalidated
#define msgLinkedInSessionInvalidateTitle       @"OAuth Exception"
#define msgLinkedInSessionInvalidateMessage     @"Your session has been expired."

//Message Request Error
#define kLinkedInMessage                        @"Message"
#define msgLinkedInRequestTokenFail             @"Failed to get request token. Please try again!"
#define msgLinkedInAllowAppAccess               @"Please allow app to logged in with LinkedIn."
#define msgLinkedInAccessTokenFail              @"Failed to get access token. Please try again!"

#define msgLinkedInPostStatusSuccess            @"Message has been post to your wall successfully."

//Test Data
#define msgLinkedInPostStatus                   @"This is custom linkedin message."
#define msgLinkedInPostUrl                      @"http://developer.linkedin.com/rest"
#define msgLinkedInPostPictureUrl               @"http://developer.linkedin.com/rest/linkedin_logo.png"
#define msgLinkedInPostUrlTitle                 @"LinkedIn SDK for iOS"
#define msgLinkedInPostCaption                  @"Social Network"
#define msgLinkedInPostDescription              @"The LinkedIn SDK for iOS makes it easier and faster to develop LinkedIn integrated iOS apps."
