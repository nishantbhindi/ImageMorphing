//
//  Message.h
//  iOSCodeStructure
//
//  Created by Nishant
//  Copyright (c) 2012 Nishant. All rights reserved.
//

//Internet Connection
#define msgInternetConnTitle            @"Internet Connection"
#define msgInternetConnOff              @"Please turn on internet connection to use this application."
#define msgInternetConnTimeOut          @"Request Timed Out."
#define msgInternetConnNotConnHost      @"Can not connect to host."
#define msgInternetConnError            @"Error loading page, Please try again later."
#define msgWiFiOff                      @"Please turn on Wi-Fi connection to use this application."
#define msgConnectionNull               @"Connection is NULL."
#define msgConnectionError              @"ERROR with Conenction."

//Allow GPS Location
#define msgGPSLocationAllow             @"Please allow GPS location to use this application."
#define msgGPSLocationOnInfo            @"You can allow GPS location for this app by going to: Settings > Location Services > #AppName# > ON.                                         You can reset this for all apps by going to: Settings > General > Reset > Reset Location Warnings."

//Record Add/Update
#define msgRecordAddTitle           @"Record Add"
#define msgRecordAddSuccess         @"Record has been added successfully."
#define msgRecordAddFail            @"Error has been occurred while adding record."

#define msgRecordUpdateTitle        @"Record Update"
#define msgRecordUpdateSuccess      @"Record has been updated successfully."
#define msgRecordUpdateFail         @"Error has been occurred while updating record."

//Title Success/Fail
#define msgSuccessTitle         @"Success"
#define msgFailTitle            @"Fail"

//No Data
#define msgNoDataFound          @"No Data Found."

//Calling
#define msgCallTitle            @"Calling"
#define msgCallMessage          @"is not supported in this device."
#define msgCallNotSupport       @"Calling is not supported in this device."

//Camera
#define msgNoCameraAvailable    @"Camera is not available in this device."

//Not Proper URL
#define msgURLInvalidToOpen     @"This URL format is not valid."

//Local Notification
#define msgNotificationTest     @"Test notification message."

//Loading
#define msgLoadingGeneral       @"Please Wait..."
#define msgLoadingDownload      @"Downloading..."
#define msgLoadingUpload        @"Uploading..."
#define msgLoadingSubmit        @"Submitting..."
#define msgLoadingLogin         @"Authenticating..."

//---------------PROJECT WISE---------------//

//General
#define msgGenEnterCredential       @"Please enter email & password."
#define msgGenEnterUsername         @"Please enter username."
#define msgGenEnterPassword         @"Please enter password."
#define msgGenEnterValidPassword    @"Password length should 6 or more characters."
#define msgGenEnterEmail            @"Please enter email."
#define msgGenEnterValidEmail       @"Please enter valid email."
#define msgGenEnterFirstname        @"Please enter firstname."
#define msgGenEnterLastname         @"Please enter lastname."
#define msgGenEnterZipcode          @"Please enter zipcode."
#define msgGenEnterMessage          @"Please enter message."

//Login
#define msgLoginTitle               @"Login"
#define msgLoginEnterCredential     @"Please enter username & password!"
#define msgLoginEnterUsername       @"Please enter username!"
#define msgLoginEnterPassword       @"Please enter password!"

//Forgot Password
#define msgForgotPwdTitle           @"Forgot Password"

//Remember Me Message
#define msgRememberMeAdd            @"Credential has beed added successfully!"
#define msgRememberMeRemove         @"Credential has beed removed successfully!"

