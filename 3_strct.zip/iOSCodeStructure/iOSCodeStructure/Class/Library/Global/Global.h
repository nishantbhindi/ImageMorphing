//
//  Global.h
//  iOSCodeStructure
//
//  Created by Nishant
//  Copyright (c) 2012 Nishant. All rights reserved.
//


////////////////Project-Wise////////////////
//http://174.129.55.54:180/api/Mobile/LoginMember?userName=bogdan@advensis-software.ro&password=admin

//Webservice Url
//#define g_WebserviceUrl						@"http://174.129.55.54:180/api/Mobile/"
//#define g_WebserviceImageUploadUrl			@"http://174.129.55.54:180/api/Mobile/imageupload/"
#define g_WebserviceUrl                         @"http://dev.boardprospects.com:801/api/Mobile/"
#define g_WebserviceImageUploadUrl              @"http://dev.boardprospects.com:801/api/Mobile/"

//Web-Sevice PageName
#define g_Pagename_UpdateGPSLocation		@"updategps.php"

#define g_Pagename_Login					@"LoginMember"
#define g_Pagename_Logout					@"logout.php"
#define g_Pagename_ForgotPassword			@"forgot-password.php"
#define g_Pagename_UpdateProfile			@"update-profile.php"
#define g_Pagename_ChangePassword			@"change-password.php"

#define g_Pagename_MemberSignUp				@"RegisterMember"

//Tab-ID
#define g_TabID_Tab1            0
#define g_TabID_Tab2            1
#define g_TabID_Tab3            2
#define g_TabID_Tab4            3
#define g_TabID_Tab5            4

//Tab-Title
#define g_TabTitle_Tab1         @"Tab 1"
#define g_TabTitle_Tab2         @"Tab 2"
#define g_TabTitle_Tab3         @"Tab 3"
#define g_TabTitle_Tab4         @"Tab 4"
#define g_TabTitle_Tab5         @"Tab 5"

//Page-Title
#define g_Title_Registration_Add		@"Add Registration"
#define g_Title_Registration_Edit		@"Edit Registration"
#define g_Title_Setting_Add             @"Add Settings"
#define g_Title_Setting_Edit            @"Edit Settings"

#define g_Database_Name                 @"testDB.sqlite3"

#define g_THUMB_IMAGE_WIDTH             75.0

//Static Pages
#define g_WebPageUrl_UserAccept_Aggrement              @"http://webplanex.net/projects/bpro2/mobile/about.html"
#define g_WebPageUrl_UserAccept_PrivacyPolicy          @"https://www.boardprospects.com/privacy/"
#define g_WebPageUrl_UserAccept_CookiePolicy           @"http://webplanex.net/projects/bpro2/mobile/about.html"

//Social Network ID
#define g_SNID_LinkedIn                 1
#define g_SNID_Facebook                 2
#define g_SNID_Twitter                  3
#define g_SNID_GooglePlus               4
#define g_SNID_Beknow                   5


//Body
#define g_BODY_FACE                     1
#define g_BODY_HALF                     2
#define g_BODY_FULL                     3

//Style
#define g_STYLE_NORMAL                  1
#define g_STYLE_BUSINESS                2
#define g_STYLE_PARTY                   3

//Gender
#define g_GENDER_MAN                    1
#define g_GENDER_WOMAN                  2

////////////////GENERAL////////////////

//DateTime Format
#define g_DateTimeFormatDefaultAMPM		@"yyyy-MM-dd HH:mm"
#define g_DateTimeFormatDefault			@"yyyy-MM-dd HH:mm:ss"	//yyyy-MM-dd'T'HH:mm:ss.S
#define g_DateFormatDefault				@"yyyy-MM-dd"			//dd/MM/yyyy //eee MMM dd HH:mm:ss ZZZZ yyyy //eee MMM dd hh:mm:ss a //MMM YYYY //yyyy-MM-dd
#define g_TimeFormatDefault				@"HH:mm"
#define g_TimeFormatFullDefault			@"HH:mm:ss"

#define g_DateTimeFormatDisplay			@"yyyy-MM-dd HH:mm:ss" //yyyy-MM-dd'T'HH:mm:ss.S
#define g_DateFormatDisplay				@"MM/dd/yyyy"          //dd/MM/yyyy //eee MMM dd HH:mm:ss ZZZZ yyyy  //eee MMM dd hh:mm:ss a  //MMM YYYY //yyyy-MM-dd
#define g_TimeFormatDisplay				@"hh:mm a"             //HH:mm a

#define g_DateFormat_Facebook			@"yyyy-MM-dd'T'HH:mm:ssZZZ"
#define g_DateFormat_Twitter			@"eee MMM dd HH:mm:ss ZZZZ yyyy"

//Font-Family
#define g_Font_Name_Default				@"Helvetica Neue"
#define g_Font_Size_Title_Default		18.0
#define g_Font_Size_Default				14.0

#define g_Font_Name_Default_Control		@"Arial"
#define g_Font_Size_Default_Control		14.0

//Alert
#define g_Alert_DisplayTime				@"2"        //In Second
#define g_Alert_Extra_Height			@"70"

//Size
#define g_Size_Width_Default			20000

//Color
#define g_ColorPlaceholderDefault		[UIColor lightGrayColor]
#define g_ColorDefault					[UIColor grayColor]
#define g_ColorYes						[UIColor greenColor]
#define g_ColorNo						[UIColor redColor]
#define g_ColorComplete					[UIColor greenColor]
#define g_ColorCancel					[UIColor redColor]

//Cell Content
#define g_CellHeight_Simple_Default		44.0f
#define g_Cell_Content_Margin			10.0f
#define g_Cell_Content_Width			320.0f

//TextView Content
#define g_TextView_Content_Margin		-8.0f
#define g_TextView_Content_Width		200.0f

//Border
#define g_Border_Radius_Default         10.0
#define g_Border_Width_Default			1.0

//For Success/Failure/Duplicate Response
#define g_Response_Success				1
#define g_Response_Failure				2
#define g_Response_Duplicate			3

//For Default Selection
#define g_Default_SelectText			@"Select"
#define g_Default_SelectID				0
#define g_Default_IntegerValue			0

#define g_Default_PasswordLength		6

//Other Defaults
#define g_Default_Timeout_Seconds				600		//Timeout
#define g_Default_DeviceType					1		//iPhone
#define g_Default_CharactorLimit				149		//Charactor Limit
#define g_Default_PasswordMinLength				6		//Password Minimum Length
#define g_Default_Animation_Duration			0.3		//Animation Duration
#define g_Default_Image_Corner_Radious			5.0		//Image


//Document Directory
#define kAppDirectoryPath   NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)
//Cache Directory
#define kAppCachePath       NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)


//For Language Selection
#define g_Language_EnglishId			1
#define g_Language_EspanolId			2

//Language
#define currentLanguageBundle [NSBundle bundleWithPath:[[NSBundle mainBundle] pathForResource:[[NSLocale preferredLanguages] objectAtIndex:0] ofType:@"lproj"]]
#define getLocalizedText(pstrKey) NSLocalizedStringFromTableInBundle(pstrKey, nil, currentLanguageBundle, @"")
//getLocalizedText(@"LOGIN_ENTER_USER_PWD");


//For Replacing NSLog
#define DEBUG_MODE 1 //Comment this line while release the app

#ifdef DEBUG_MODE
#define DLog( s, ... ) NSLog( @"<%p %@:(%d)> %@", self, [[NSString stringWithUTF8String:__FILE__] lastPathComponent], __LINE__, [NSString stringWithFormat:(s), ##__VA_ARGS__] )
#else
    #define DLog( s, ... )
#endif

//Device Compatibility
#define g_IS_IPHONE             ( [[[UIDevice currentDevice] model] isEqualToString:@"iPhone"] )
#define g_IS_IPOD               ( [[[UIDevice currentDevice] model] isEqualToString:@"iPod touch"] )
#define g_IS_IPAD               ( [[[UIDevice currentDevice] model] isEqualToString:@"iPad"] )
#define g_IS_IPHONE_5_SCREEN    [[UIScreen mainScreen] bounds].size.height >= 568.0f && [[UIScreen mainScreen] bounds].size.height < 1024.0f
#define g_IS_IPHONE_4_SCREEN    [[UIScreen mainScreen] bounds].size.height >= 480.0f && [[UIScreen mainScreen] bounds].size.height < 568.0f

//Version Compatibility
// thanks to yasirmturk : http://stackoverflow.com/questions/3339722/check-iphone-ios-version/5337804#5337804
#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

////////////////Rair Used////////////////

//Used to specify the Application used in Keychain accessing
#define g_APP_NAME [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"] //CFBundleIdentifier, CFBundleName, CFBundleDisplayName

//Password
#define g_PasswordRandomString  @"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
// Used to help secure the PIN
// Ideally, this is randomly generated, but to avoid unneccessary complexity and overhead of storing the Salt seperately we will standardize on this key.
// !!KEEP IT A SECRET!!
#define g_SALT_HASH             @"FvTivqTqZXsgLLx1v3P8TGRyVHaSOB1pvfm02wvGadj7RLHV8GrfxaZ84oGA8RsKdNRpxdAojXYg9iAj"
#define g_SECURE_STORE          1  //1=Data will be stored in Keychain,0=Data will be stored in NSUserDefaults

//Conversion
#define M_PI                        3.14159265358979323846264338327950288   /* pi */

#define DegreesToRadians(degrees)   (degrees * M_PI / 180)
#define RadiansToDegrees(radians)   (radians * 180/M_PI)

//Google Map
#define g_GoogleGeoCodingString     @"http://maps.google.com/maps/geo?q=%f,%f&output=csv"
#define g_Default_Latitude          23.012231
#define g_Default_Longitude         72.511569

#define	g_MeterToMile 0.000621371192

//Color
#define UIColorFromHEX(hexValue) [UIColor colorWithRed:((float)((hexValue & 0xFF0000) >> 16))/255.0 green:((float)((hexValue & 0xFF00) >> 8))/255.0 blue:((float)(hexValue & 0xFF))/255.0 alpha:1.0]
#define RGB(r, g, b)            [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1]
#define RGBA(r, g, b, a)        [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]


////////////////////////////////////////////////Project Wise////////////////////////////////////////////////
//Notification
#define g_Notification_Cell_Height              66.0
#define kNOTIFICATION_MAX_HEIGHT                ((g_IS_IPHONE_5_SCREEN) ? 460.0 : 375.0)

