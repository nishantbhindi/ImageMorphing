//
//  SimpleListCell.m
//  iOSCodeStructure
//
//  Created by Nishant on 08/02/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import "SimpleListCell.h"

@implementation SimpleListCell

@synthesize lblTitle;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
	[self.lblTitle release];
	
    [super dealloc];
}

@end
