//
//  SimpleListCell.h
//  iOSCodeStructure
//
//  Created by Nishant on 08/02/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SimpleListCell : UITableViewCell {
	UILabel *lblTitle;
}
@property(nonatomic,retain)IBOutlet UILabel *lblTitle;

@end
