//
//  KeychainWrapper.h
//  Design Compability
//
//  Created by Nishant on 26/12/12.
//  Copyright (c) 2012 Nishant. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KeychainWrapper : NSObject {
@private
    
}

+ (KeychainWrapper *)sharedKeychainBindings;

- (id)objectForKey:(NSString *)pstrKey;
- (void)setObject:(NSString *)pstrValue forKey:(NSString *)pstrKey;
- (void)setString:(NSString *)pstrValue forKey:(NSString *)pstrKey;
- (void)removeObjectForKey:(NSString *)pstrKey;

- (NSString *)stringForKey:(NSString *)pstrKey;

@end
