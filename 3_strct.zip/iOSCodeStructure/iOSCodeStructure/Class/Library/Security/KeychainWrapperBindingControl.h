//
//  KeychainWrapperBindingControl.h
//  Design Compability
//
//  Created by Nishant on 26/12/12.
//  Copyright (c) 2012 Nishant. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KeychainWrapper.h"

@interface KeychainWrapperBindingControl : NSObject {
@private
    KeychainWrapper *_keychainBindings;
    NSMutableDictionary *_valueBuffer;
}

+ (KeychainWrapperBindingControl *)sharedKeychainBindingsController;
- (KeychainWrapper *) keychainBindings;

- (id)values;    // accessor object for KeychainWrapper values. This property is observable using key-value observing.

- (NSString*)stringForKey:(NSString*)pstrKey;
- (BOOL)storeString:(NSString*)pstrValue forKey:(NSString*)pstrKey;

@end
