//
//  KeychainWrapper.m
//  Design Compability
//
//  Created by Nishant on 26/12/12.
//  Copyright (c) 2012 Nishant. All rights reserved.
//

#import "KeychainWrapper.h"
#import "KeychainWrapperBindingControl.h"

@implementation KeychainWrapper

+ (KeychainWrapper *)sharedKeychainBindings
{
	return [[KeychainWrapperBindingControl sharedKeychainBindingsController] keychainBindings];
}
- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}
- (void)dealloc
{
    [super dealloc];
}

- (id)objectForKey:(NSString *)pstrKey {
    return [[KeychainWrapperBindingControl sharedKeychainBindingsController] valueForKeyPath:[NSString stringWithFormat:@"values.%@",pstrKey]];
}
- (void)setObject:(NSString *)pstrValue forKey:(NSString *)pstrKey {
    [[KeychainWrapperBindingControl sharedKeychainBindingsController] setValue:pstrValue forKeyPath:[NSString stringWithFormat:@"values.%@",pstrKey]];
}
- (void)setString:(NSString *)pstrValue forKey:(NSString *)pstrKey {
    [[KeychainWrapperBindingControl sharedKeychainBindingsController] setValue:pstrValue forKeyPath:[NSString stringWithFormat:@"values.%@",pstrKey]];
}
- (void)removeObjectForKey:(NSString *)pstrKey {
    [[KeychainWrapperBindingControl sharedKeychainBindingsController] setValue:nil forKeyPath:[NSString stringWithFormat:@"values.%@",pstrKey]];
}

- (NSString *)stringForKey:(NSString *)pstrKey {
    return (NSString *) [self objectForKey:pstrKey];
}

@end
