//
//  DashboardViewController.h
//  BestBetting
//
//  Created by WebInfoways on 10/07/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppDelegate;

@interface DashboardViewController : UIViewController{
    AppDelegate *appDelegate;
}

@property(nonatomic,retain) IBOutlet UIButton *btnBodyFace;
@property(nonatomic,retain) IBOutlet UIButton *btnBodyHalf;
@property(nonatomic,retain) IBOutlet UIButton *btnBodyFull;

@property(nonatomic,retain) IBOutlet UIButton *btnStyleNormal;
@property(nonatomic,retain) IBOutlet UIButton *btnStyleBusiness;
@property(nonatomic,retain) IBOutlet UIButton *btnStyleParty;

@property(nonatomic,retain) IBOutlet UIButton *btnGenderMan;
@property(nonatomic,retain) IBOutlet UIButton *btnGenderWoman;

-(void)setInitialParameter;

-(IBAction)btnTappedBody:(id)sender;
-(IBAction)btnTappedStyle:(id)sender;
-(IBAction)btnTappedGender:(id)sender;

-(void)setSelectedBody:(int)pintSelectedId;
-(void)setSelectedStyle:(int)pintSelectedId;
-(void)setSelectedGender:(int)pintSelectedId;

-(IBAction)btnTappedAbout:(id)sender;
-(IBAction)btnTappedHelp:(id)sender;

@end
