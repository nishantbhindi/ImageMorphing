//
//  DashboardViewController.m
//  BestBetting
//
//  Created by WebInfoways on 10/07/13.
//  Copyright (c) 2013 Nishant. All rights reserved.
//

#import "DashboardViewController.h"

@interface DashboardViewController ()

@end

@implementation DashboardViewController

@synthesize btnBodyFace,btnBodyHalf,btnBodyFull;
@synthesize btnStyleNormal,btnStyleBusiness,btnStyleParty;
@synthesize btnGenderMan,btnGenderWoman;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [self setInitialParameter];
}
#pragma mark - Initial Parameter
-(void)setInitialParameter
{
    [self setSelectedBody:appDelegate.intSelectedBody];
    [self setSelectedStyle:appDelegate.intSelectedStyle];
    [self setSelectedGender:appDelegate.intSelectedGender];
}

#pragma mark - Set Selected Data
-(void)setSelectedBody:(int)pintSelectedId{    
    switch (pintSelectedId) {
        case 1:
            [btnBodyFace setAlpha:1.0];
            [btnBodyHalf setAlpha:0.5];
            [btnBodyFull setAlpha:0.5];
            break;
        case 2:
            [btnBodyFace setAlpha:0.5];
            [btnBodyHalf setAlpha:1.0];
            [btnBodyFull setAlpha:0.5];
            break;
        case 3:
            [btnBodyFace setAlpha:0.5];
            [btnBodyHalf setAlpha:0.5];
            [btnBodyFull setAlpha:1.0];
            break;
    }
}
-(void)setSelectedStyle:(int)pintSelectedId{
    switch (pintSelectedId) {
        case 1:
            [btnStyleNormal setAlpha:1.0];
            [btnStyleBusiness setAlpha:0.5];
            [btnStyleParty setAlpha:0.5];
            break;
        case 2:
            [btnStyleNormal setAlpha:0.5];
            [btnStyleBusiness setAlpha:1.0];
            [btnStyleParty setAlpha:0.5];
            break;
        case 3:
            [btnStyleNormal setAlpha:0.5];
            [btnStyleBusiness setAlpha:0.5];
            [btnStyleParty setAlpha:1.0];
            break;
    }
}
-(void)setSelectedGender:(int)pintSelectedId{
    switch (pintSelectedId) {
        case 1:
            [btnGenderMan setAlpha:1.0];
            [btnGenderWoman setAlpha:0.5];
            break;
        case 2:
            [btnGenderMan setAlpha:0.5];
            [btnGenderWoman setAlpha:1.0];
            break;
    }
}

#pragma mark - Button Tapped Option Select
-(IBAction)btnTappedBody:(id)sender{
    appDelegate.intSelectedBody=[sender tag];
    [self setSelectedBody:appDelegate.intSelectedBody];
}
-(IBAction)btnTappedStyle:(id)sender{
    appDelegate.intSelectedStyle=[sender tag];
    [self setSelectedStyle:appDelegate.intSelectedStyle];
}
-(IBAction)btnTappedGender:(id)sender{
    appDelegate.intSelectedGender=[sender tag];
    [self setSelectedGender:appDelegate.intSelectedGender];
}

#pragma mark - Button Tapped About, Help
-(IBAction)btnTappedAbout:(id)sender{
    
}
-(IBAction)btnTappedHelp:(id)sender{
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Orientations
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [btnBodyFace release];
    [btnBodyHalf release];
    [btnBodyFull release];
    
    [btnStyleNormal release];
    [btnStyleBusiness release];
    [btnStyleParty release];
    
    [btnGenderMan release];
    [btnGenderWoman release];
    
    [super dealloc];
}

@end
