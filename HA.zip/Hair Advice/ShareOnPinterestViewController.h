//
//  ShareOnPinterestViewController.h
//  Donna Bella
//
//  Created by WebInfoways on 24/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Blog.h"

@class AppDelegate;

@interface ShareOnPinterestViewController : UIViewController <UIWebViewDelegate>
{
    AppDelegate *appDelegate;
    id parent;
    
    IBOutlet UILabel *lblTitle;
	IBOutlet UIWebView *webviewPage;
}
@property(nonatomic,retain) Blog *objBlog;

-(void)setInitialParameter;

-(NSString*)generatePinterestHTML;
-(void)postToPinterest;

-(IBAction)btnTappedBack:(id)sender;

@end
