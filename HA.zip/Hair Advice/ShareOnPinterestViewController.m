//
//  ShareOnPinterestViewController.m
//  Donna Bella
//
//  Created by WebInfoways on 24/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import "ShareOnPinterestViewController.h"

@interface ShareOnPinterestViewController ()

@end

@implementation ShareOnPinterestViewController

@synthesize objBlog;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [self setInitialParameter];
}
-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.view setUserInteractionEnabled:YES];
    
    [self postToPinterest];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [webviewPage stopLoading];
    //[FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
}

#pragma mark - Set Initial Parameter
-(void)setInitialParameter{
    [FunctionManager stopWebViewBounce:webviewPage];
}

#pragma mark - Post to Pinterest
-(NSString*)generatePinterestHTML{
    NSString *strDescription = objBlog.strTitle;
    NSString *strImageUrl = objBlog.strPhotoUrl;
    //NSLog(@"URL:%@", strImageUrl);
    NSString *strProtectedUrl = ( NSString *)CFURLCreateStringByAddingPercentEscapes(NULL,( CFStringRef)strImageUrl, NULL, (CFStringRef)@"!*'\"();:@&=+$,/?%#[]% ",CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding));
    DLog(@"Protected URL:%@", strProtectedUrl);
    NSString *strImageUrl2 = [NSString stringWithFormat:@"\"%@\"", strImageUrl];
    NSString *strButtonUrl = [NSString stringWithFormat:@"\"http://pinterest.com/pin/create/button/?url=%@&media=%@&description=%@\"", objBlog.strBlogUrl, strProtectedUrl, strDescription];
    
    NSString *strUrlString =[NSString stringWithFormat:@"<html> <body><p align=\"center\"><a href=%@ class=\"pin-it-button\" count-layout=\"horizontal\"><img border=\"0\" src=\"http://assets.pinterest.com/images/PinExt.png\" title=\"Pin It\" /></a></p><p align=\"center\"><img width=\"320px\" height = \"380px\" src=%@></img></p><script type=\"text/javascript\" src=\"//assets.pinterest.com/js/pinit.js\"></script></body> </html>",strButtonUrl,strImageUrl2];
    
    [strProtectedUrl release];
    
    return strUrlString;
}
-(void)postToPinterest{
    NSString *strPinterestHTML = [self generatePinterestHTML];
    //DLog(@"Pinterest HTML: %@", strPinterestHTML);
    [webviewPage loadHTMLString:strPinterestHTML baseURL:nil];
}

#pragma mark - webView delegate
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [FunctionManager displayLoadingView:self.view withMessage:msgLoadingGeneral appDelegate:appDelegate viewController:self];
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
	return YES;
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [FunctionManager webviewFailToLoad:webviewPage withError:error];
}

#pragma mark - Go Back
-(IBAction)btnTappedBack:(id)sender
{
    [FunctionManager gotoBack:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
	//[lblTitle release];
	//[webviewPage release];
    [super dealloc];
}

@end
