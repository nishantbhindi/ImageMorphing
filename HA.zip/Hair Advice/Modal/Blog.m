//
//  Blog.m
//  Donna Bella
//
//  Created by WebInfoways on 20/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import "Blog.h"

@implementation Blog

@synthesize intBlogId,intNoOfLike;
@synthesize strTitle,strDateTime,strBlogUrl;
@synthesize strPhotoUrl,imgPhoto,imgPhotoData,bolPhotoAvailable;
@synthesize fltImgWidth,fltImgHeight;

-(void)dealloc{
	[self.strTitle release];
	[self.strDateTime release];
    [self.strBlogUrl release];
    
    [self.strPhotoUrl release];
    [self.imgPhoto release];
    [self.imgPhotoData release];
    
	[super dealloc];
}

@end
