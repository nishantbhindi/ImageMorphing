//
//  Blog.h
//  Donna Bella
//
//  Created by WebInfoways on 20/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Blog : NSObject {
	int intBlogId;
	int intNoOfLike;
    
	NSString *strTitle;
	NSString *strDateTime;
    
    NSString *strBlogUrl;
    
    NSString *strPhotoUrl;
    UIImage *imgPhoto;
	NSData *imgPhotoData;
    BOOL bolPhotoAvailable;
    
    CGFloat fltImgWidth;
    CGFloat fltImgHeight;
}
@property(nonatomic) int intBlogId;
@property(nonatomic) int intNoOfLike;

@property(nonatomic,retain) NSString *strTitle;
@property(nonatomic,retain) NSString *strDateTime;
@property(nonatomic,retain) NSString *strBlogUrl;

@property(nonatomic,retain) NSString *strPhotoUrl;
@property(nonatomic,retain) UIImage *imgPhoto;
@property(nonatomic,retain) NSData *imgPhotoData;
@property(nonatomic) BOOL bolPhotoAvailable;

@property(nonatomic) CGFloat fltImgWidth;
@property(nonatomic) CGFloat fltImgHeight;

@end
