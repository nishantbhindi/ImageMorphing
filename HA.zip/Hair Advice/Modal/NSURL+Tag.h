//
//  NSURL+Tag.h
//  ImageGallery
//
//  Created by Sandip Saha on 06/11/13.
//  Copyright (c) 2013 Sandip Saha. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURL (Tag)
-(void)setTag:(int)tag;
-(int) tag;
@end
