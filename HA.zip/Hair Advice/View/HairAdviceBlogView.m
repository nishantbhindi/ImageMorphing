//
//  HairAdviceBlogView.m
//  Donna Bella
//
//  Created by WebInfoways on 21/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import "HairAdviceBlogView.h"

@implementation HairAdviceBlogView

@synthesize imgPhoto,actLoading;
@synthesize viewFooter,lblTitle;
@synthesize btnFacebook,btnTwitter,btnGooglePlus,btnPinterest,btnEmail;
@synthesize btnComment;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc {
	[self.imgPhoto release];
    [self.actLoading release];
    
    [self.viewFooter release];
	[self.lblTitle release];
    
    [self.btnFacebook release];
    [self.btnTwitter release];
    [self.btnGooglePlus release];
	[self.btnPinterest release];
    [self.btnEmail release];
    
    [self.btnComment release];
    
    [super dealloc];
}

@end
