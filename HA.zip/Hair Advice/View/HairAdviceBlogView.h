//
//  HairAdviceBlogView.h
//  Donna Bella
//
//  Created by WebInfoways on 21/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HairAdviceBlogView : UIView {
	IBOutlet UIImageView *imgPhoto;
	IBOutlet UIActivityIndicatorView *actLoading;
    
    UIView *viewFooter;
    
	IBOutlet UILabel *lblTitle;
    
    UIButton *btnFacebook;
    UIButton *btnTwitter;
    UIButton *btnGooglePlus;
    UIButton *btnPinterest;
    UIButton *btnEmail;
    
    UIButton *btnComment;
}
@property(nonatomic,retain)IBOutlet UIImageView *imgPhoto;
@property(nonatomic,retain)IBOutlet UIActivityIndicatorView *actLoading;

@property(nonatomic,retain)IBOutlet UIView *viewFooter;

@property(nonatomic,retain)IBOutlet UILabel *lblTitle;

@property(nonatomic,retain)IBOutlet UIButton *btnFacebook;
@property(nonatomic,retain)IBOutlet UIButton *btnTwitter;
@property(nonatomic,retain)IBOutlet UIButton *btnGooglePlus;
@property(nonatomic,retain)IBOutlet UIButton *btnPinterest;
@property(nonatomic,retain)IBOutlet UIButton *btnEmail;

@property(nonatomic,retain)IBOutlet UIButton *btnComment;

@end
