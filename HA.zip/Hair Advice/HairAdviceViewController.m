//
//  HairAdviceViewController.m
//  Donna Bella
//
//  Created by WebInfoways on 20/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import "HairAdviceViewController.h"

#import "SHKFacebook.h"
#import "SHKTwitter.h"
#import "SHKGooglePlus.h"

@interface HairAdviceViewController ()

@end

@implementation HairAdviceViewController

@synthesize intSuccess, strMessage, bolIsSearched;
@synthesize arrBlogList,arrBlogListSearched;
@synthesize scrHorizontal;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	[self setInitialParameter];
}
- (void)viewWillAppear:(BOOL)animated{
    [self resetData];
    
    [self bindStaticContent];
    
    //[self fetchBlogList];
    //[_tblBlogList reloadData];
}
- (void)viewDidDisappear:(BOOL)animated{
    [self resignResponder];
}

#pragma mark - Set Initial Parameter
-(void)setInitialParameter{
    //self.arrBlogList = [[NSMutableArray alloc] init];
    self.arrBlogListSearched = [[NSMutableArray alloc] init];
    
    [FunctionManager setDefaultTableViewStyle:_tblBlogList delegate:self];
}
-(void)resetData{
    self.bolIsSearched = FALSE;
    _txtSearch.text=@"";
    
    [self resignResponder];
}

#pragma mark - Fetch Blog List
-(void)fetchBlogList{
    [self resignResponder];
    
    self.strMessage = @"";
    if(self.arrBlogList.count>0)
        [self.arrBlogList removeAllObjects];
    
    [FunctionManager displayLoadingView:self.view withMessage:msgLoadingGeneral appDelegate:appDelegate viewController:self];
    
    //http://webplanex.co.in/projects/donna_bella/iphone_api/calc_api.php?method=get_client&user_id=1
    
    NSString *strURL = [NSString stringWithFormat:@"%@calc_api.php?",g_BaseUrl];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[strURL toURL]];
    [request setDelegate:self];
    [request setRequestMethod:@"POST"];  //GET
    [request setTimeOutSeconds:g_Default_Timeout_Seconds];
    
    [request setPostValue:@"get_client" forKey:@"method"];
    [request setPostValue:@"json" forKey:@"format"];
    [request setPostValue:[NSString stringWithFormat:@"%d", appDelegate.objUser.intUserId] forKey:@"user_id"];
    //[request setPostValue:@"1" forKey:@"user_id"];
    
    [request setDidFinishSelector:@selector(blogListSuccess:)];
    [request setDidFailSelector:@selector(blogListFailed:)];
    [request startAsynchronous];
}
#pragma mark Blog List Response
- (void)blogListSuccess:(ASIHTTPRequest *)request
{
    NSString *strResponse = [request responseString];
    SBJSON *objSBJSONParser = [[SBJSON alloc] init];
	NSDictionary *dictData = [objSBJSONParser objectWithString:strResponse error:nil];
	
    [FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
    
    int intStatus = [[dictData objectForKey:@"status"] intValue];
    
    if (intStatus==1) {
        self.arrBlogList = (NSMutableArray *)[dictData objectForKey:@"data"];
        [_tblBlogList reloadData];
    }
    else{
        if(![self.strMessage isEmptyString] && self.strMessage)
            [FunctionManager showMessage:nil withMessage:self.strMessage withDelegage:nil];
        else
            [FunctionManager showMessage:nil withMessage:msgRecordFetchFail withDelegage:nil];
        //msgGenFetchRecordFail
    }
}
- (void)blogListFailed:(ASIHTTPRequest *)request
{
	NSError *error = [request error];
	[FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
	[FunctionManager showMessage:nil withMessage:[error localizedDescription] withDelegage:nil];
}
-(void)bindStaticContent
{
    self.arrBlogList = [[NSMutableArray alloc] init];
    
    Blog *objBlog1 = [[Blog alloc] init];
    objBlog1.intBlogId = 1;
    objBlog1.intNoOfLike = 5;
    objBlog1.strTitle = @"Introducing: Hands On Certification Classes and Free Installations in New York!";
    objBlog1.strDateTime = @"2014-02-14";
    objBlog1.strBlogUrl = @"http://www.google.com";
    objBlog1.strPhotoUrl = @"http://www.whitegadget.com/attachments/pc-wallpapers/25222d1235656623-nature-photos-wallpapers-images-beautiful-pictures-nature-mountains-photo.jpg";
    objBlog1.fltImgWidth = 145.0;
    objBlog1.fltImgHeight = 109.0;
    [self.arrBlogList addObject:objBlog1];
    [objBlog1 release];
    
    Blog *objBlog2 = [[Blog alloc] init];
    objBlog2.intBlogId = 2;
    objBlog2.intNoOfLike = 7;
    objBlog2.strTitle = @"5 Quick Tips for Grooved Beads";
    objBlog2.strDateTime = @"2014-02-07";
    objBlog2.strBlogUrl = @"http://www.google.com";
    objBlog2.strPhotoUrl = @"http://3.bp.blogspot.com/-YmEyAa4elTo/UDtaclzno9I/AAAAAAAAC-w/JsqwSuoj260/s1600/Beautiful-Nature.jpg";
    objBlog2.fltImgWidth = 145.0;
    objBlog2.fltImgHeight = 181.0;
    [self.arrBlogList addObject:objBlog2];
    [objBlog2 release];
    
    Blog *objBlog3 = [[Blog alloc] init];
    objBlog3.intBlogId = 3;
    objBlog3.intNoOfLike = 2;
    objBlog3.strTitle = @"Style Tip: Single Clip Ins";
    objBlog3.strDateTime = @"2014-01-31";
    objBlog3.strBlogUrl = @"http://www.google.com";
    objBlog3.strPhotoUrl = @"http://www.wallsave.com/wallpapers/1920x1080/scenery-of-nature/658761/scenery-of-nature-background-658761.jpg";
    objBlog3.fltImgWidth = 145.0;
    objBlog3.fltImgHeight = 82.0;
    [self.arrBlogList addObject:objBlog3];
    [objBlog3 release];
    
    Blog *objBlog4 = [[Blog alloc] init];
    objBlog4.intBlogId = 4;
    objBlog4.intNoOfLike = 4;
    objBlog4.strTitle = @"Donna Bella Social Media Contests";
    objBlog4.strDateTime = @"2014-01-24";
    objBlog4.strBlogUrl = @"http://www.google.com";
    objBlog4.strPhotoUrl = @"http://www.wallcoo.net/1920x1200/1920x1200_widescreen_wallpaper_nature_01/images/wallcoo.com_1920x1200_Widescreen_Wallpaper_nature_01149_multnomahfalls_1920x1200.jpg";
    objBlog4.fltImgWidth = 145.0;
    objBlog4.fltImgHeight = 91.0;
    [self.arrBlogList addObject:objBlog4];
    [objBlog4 release];
    
    Blog *objBlog5 = [[Blog alloc] init];
    objBlog5.intBlogId = 5;
    objBlog5.intNoOfLike = 3;
    objBlog5.strTitle = @"Using Single Sided Tape for Highlights";
    objBlog5.strDateTime = @"2014-02-20";
    objBlog5.strBlogUrl = @"http://www.google.com";
    objBlog5.strPhotoUrl = @"http://www.funxone.com/files/2011/11/Best-Of-Nature-Photography-13.jpg";
    objBlog5.fltImgWidth = 145.0;
    objBlog5.fltImgHeight = 189.0;
    [self.arrBlogList addObject:objBlog5];
    [objBlog5 release];
    
    Blog *objBlog6 = [[Blog alloc] init];
    objBlog6.intBlogId = 6;
    objBlog6.intNoOfLike = 9;
    objBlog6.strTitle = @"Reviewing your Donna Bella Extensions Online";
    objBlog6.strDateTime = @"2013-10-20";
    objBlog6.strBlogUrl = @"http://www.google.com";
    objBlog6.strPhotoUrl = @"http://www.colourbox.com/preview/2619803-244991-big-wild-african-giraffe-walking-in-savanna-game-drive-wildlife-safari-animals-in-natural-habitat-beauty-of-nature-kenya-travel-masai-mara.jpg";
    objBlog6.fltImgWidth = 145.0;
    objBlog6.fltImgHeight = 201.0;
    [self.arrBlogList addObject:objBlog6];
    [objBlog6 release];
    
    Blog *objBlog7 = [[Blog alloc] init];
    objBlog7.intBlogId = 7;
    objBlog7.intNoOfLike = 7;
    objBlog7.strTitle = @"Questions to ask at a New Client Consultation";
    objBlog7.strDateTime = @"2013-11-25";
    objBlog7.strBlogUrl = @"http://www.google.com";
    objBlog7.strPhotoUrl = @"http://cache.desktopnexus.com/thumbnails/1309401-bigthumbnail.jpg";
    objBlog7.fltImgWidth = 145.0;
    objBlog7.fltImgHeight = 91.0;
    [self.arrBlogList addObject:objBlog7];
    [objBlog7 release];
    
    Blog *objBlog8 = [[Blog alloc] init];
    objBlog8.intBlogId = 8;
    objBlog8.intNoOfLike = 11;
    objBlog8.strTitle = @"More Single Sided Tape Tips";
    objBlog8.strDateTime = @"2013-11-20";
    objBlog8.strBlogUrl = @"http://www.google.com";
    objBlog8.strPhotoUrl = @"http://th04.deviantart.net/fs10/200H/i/2006/099/c/d/nature_portrait_8_by_blackbutterflypaku.jpg";
    objBlog8.fltImgWidth = 145.0;
    objBlog8.fltImgHeight = 194.0;
    [self.arrBlogList addObject:objBlog8];
    [objBlog8 release];
    
    Blog *objBlog9 = [[Blog alloc] init];
    objBlog9.intBlogId = 9;
    objBlog9.intNoOfLike = 14;
    objBlog9.strTitle = @"Deep Conditioning Your Hair Extensions";
    objBlog9.strDateTime = @"2013-12-20";
    objBlog9.strBlogUrl = @"http://www.google.com";
    objBlog9.strPhotoUrl = @"http://wallpaper.pickywallpapers.com/nokia-5233/preview/water-portrait.jpg";
    objBlog9.fltImgWidth = 145.0;
    objBlog9.fltImgHeight = 259.0;
    [self.arrBlogList addObject:objBlog9];
    [objBlog9 release];
    
    Blog *objBlog10 = [[Blog alloc] init];
    objBlog10.intBlogId = 10;
    objBlog10.intNoOfLike = 8;
    objBlog10.strTitle = @"Caring for Your Extensions on Your Tropical Vacation";
    objBlog10.strDateTime = @"2013-02-20";
    objBlog10.strBlogUrl = @"http://www.google.com";
    objBlog10.strPhotoUrl = @"http://www.wallsave.com/wallpapers/2560x1920/beauty-of-nature/545885/beauty-of-nature-field-sunflowers-beautiful-clouds-hi-545885.jpg";
    objBlog10.fltImgWidth = 145.0;
    objBlog10.fltImgHeight = 109.0;
    [self.arrBlogList addObject:objBlog10];
    [objBlog10 release];
    
    /*
    [self.arrBlogList addObject:@"http://www.whitegadget.com/attachments/pc-wallpapers/25222d1235656623-nature-photos-wallpapers-images-beautiful-pictures-nature-mountains-photo.jpg"];
    [self.arrBlogList addObject:@"http://3.bp.blogspot.com/-YmEyAa4elTo/UDtaclzno9I/AAAAAAAAC-w/JsqwSuoj260/s1600/Beautiful-Nature.jpg"];
    [self.arrBlogList addObject:@"http://www.wallsave.com/wallpapers/1920x1080/scenery-of-nature/658761/scenery-of-nature-background-658761.jpg"];
    [self.arrBlogList addObject:@"http://www.wallcoo.net/1920x1200/1920x1200_widescreen_wallpaper_nature_01/images/wallcoo.com_1920x1200_Widescreen_Wallpaper_nature_01149_multnomahfalls_1920x1200.jpg"];
    [self.arrBlogList addObject:@"http://www.funxone.com/files/2011/11/Best-Of-Nature-Photography-13.jpg"];
    [self.arrBlogList addObject:@"http://www.colourbox.com/preview/2619803-244991-big-wild-african-giraffe-walking-in-savanna-game-drive-wildlife-safari-animals-in-natural-habitat-beauty-of-nature-kenya-travel-masai-mara.jpg"];
    [self.arrBlogList addObject:@"http://cache.desktopnexus.com/thumbnails/1309401-bigthumbnail.jpg"];
    [self.arrBlogList addObject:@"http://th04.deviantart.net/fs10/200H/i/2006/099/c/d/nature_portrait_8_by_blackbutterflypaku.jpg"];
    [self.arrBlogList addObject:@"http://wallpaper.pickywallpapers.com/nokia-5233/preview/water-portrait.jpg"];
    [self.arrBlogList addObject:@"http://www.wallsave.com/wallpapers/2560x1920/beauty-of-nature/545885/beauty-of-nature-field-sunflowers-beautiful-clouds-hi-545885.jpg"];
    [self.arrBlogList addObject:@"http://datastore04.rediff.com/h1500-w1500/thumb/5A5A5B5B4F5C1E5255605568365E655A63672A606D6C/0upnd2vwarhp3y9i.D.0.Copy-of-Nature-Wallpapers-9.jpg"];
    [self.arrBlogList addObject:@"http://wp.1920x1080.org/wp-content/uploads/2011/11/wallpapers-of-nature-546319448.jpg"];
    [self.arrBlogList addObject:@"http://www.wallcoo.net/nature/amazing%20hd%20landscapes%20wallpapers/wallpapers/1600x1200/%5Bwallcoo_com%5D_Beautiful%20Nature%20%20HD%20Landscape%2020.jpg"];
    [self.arrBlogList addObject:@"http://wp.1920x1080.org/wp-content/uploads/2011/11/wallpapers-of-nature-575376234.jpg"];
    [self.arrBlogList addObject:@"http://www.bigpicture.in/wp-content/uploads/2010/07/LatestCollectionOfNaturePhotosByIustyn11.jpg"];
    [self.arrBlogList addObject:@"http://img.tradeindia.com/fp/1/377/778.jpg"];
    [self.arrBlogList addObject:@"http://behance.vo.llnwd.net/profiles17/1327451/projects/4862239/b3d14c57055cd37557105b6d0baebcfc.jpg"];
    [self.arrBlogList addObject:@"http://3.bp.blogspot.com/-ls3LcSetQdw/TmUwikE1ljI/AAAAAAAAFtM/MU87FnNvXT4/s1600/mobile_wallpaper_nature%2B%25281%2529.jpg"];
    [self.arrBlogList addObject:@"http://3.bp.blogspot.com/-8GMksL8RcYs/UdSpG5NMPjI/AAAAAAAAAkM/VgHJgnxnGmw/s760/clouds-and-sunrays.jpg"];
    [self.arrBlogList addObject:@"http://cache4.indulgy.net/j3/z4/b/0203a4b04dd7c1XL.jpg"];
    [self.arrBlogList addObject:@"http://carlylove.files.wordpress.com/2011/07/016.jpg"];
    [self.arrBlogList addObject:@"http://4.bp.blogspot.com/-uc1hO9wWYnY/T-3ir12mTVI/AAAAAAAAOy4/9mx0UP3Hq6A/s1600/Leonid+Andreyev++Vammasluu+At+Sunset.jpg"];
    [self.arrBlogList addObject:@"http://lijiun.files.wordpress.com/2013/05/p1010003.jpg"];
    [self.arrBlogList addObject:@"http://thefabweb.com/wp-content/uploads/2012/03/Sunny-Side-Up.jpg"];
    [self.arrBlogList addObject:@"http://thefabweb.com/wp-content/uploads/2012/03/Cherry-Trees1.jpg"];
    [self.arrBlogList addObject:@"http://browseideas.com/wp-content/uploads/2011/11/Inspiring-Examples-of-Nature-Photography-06.jpg"];
    [self.arrBlogList addObject:@"http://viewfromnaturalflorida.files.wordpress.com/2013/03/saucer-magnolia-under-blue-sky-web.jpg"];
    [self.arrBlogList addObject:@"http://www.wallsave.com/wallpapers/1280x800/new-love-nature/517518/new-love-nature-hd-staircase-stairs-of-related-517518.jpg"];
    [self.arrBlogList addObject:@"http://thefabweb.com/wp-content/uploads/2012/06/1210.jpg"];
    [self.arrBlogList addObject:@"http://thefabweb.com/wp-content/uploads/2012/06/88.jpg"];
    [self.arrBlogList addObject:@"http://bookurgift.com/images/111.jpg"];
    [self.arrBlogList addObject:@"http://images4.fanpop.com/image/photos/23800000/Pink-flowers-pink-color-23830799-1920-1233.jpg"];
    [self.arrBlogList addObject:@"http://4.bp.blogspot.com/-ik3E8PBBf70/TwaZ9PMNbrI/AAAAAAAAAG0/kNrGnEbZ-WY/s640/flowers2.jpg"];
    */
    
    [self initializeScroll:2];
}
#pragma mark - Initialize ScrollView
-(void)initializeScroll:(int)pintNoOfColumn{
    [self initializeScrollColumnHeight:pintNoOfColumn];
    
    ////Remove all subviews first////
    NSArray* subviews = [[NSArray alloc] initWithArray: self.scrHorizontal.subviews];
    for (UIView *view in subviews) {
        [view removeFromSuperview];
        
        /*if ([view isKindOfClass:[HomeBNewsHorizontalSubView class]]) {
            [view removeFromSuperview];
        }*/
    }
    if(subviews != nil)
        [subviews release];
    ////Remove all subviews first end////
    
    
    //Loading-2: Static get image width and height and based on that filling grid
    for (int i = 0; i < [self.arrBlogList count]; i++) {
        Blog *objBlogTmp = [self.arrBlogList objectAtIndex:i];
        
        HairAdviceBlogView *objHairBlog = [[[NSBundle mainBundle] loadNibNamed:@"HairAdviceBlogView" owner:self options:nil]objectAtIndex:0];
        
        CGFloat fltImageWidth = 145.0;
        CGFloat fltImageGap = 10.0;
        
        NSInteger intMinHeightColumnIndex = 0;
        CGFloat fltMinHeightColumn = 20000.0;
        CGFloat fltMaxHeightColumn = 0.0;
        
        //Check for minimum column index of min height
        for (int j=0; j<pintNoOfColumn; j++) {
            if (fltMinHeightColumn > arrayColumnHeight[j])
            {
                fltMinHeightColumn = arrayColumnHeight[j];
                intMinHeightColumnIndex = j;
            }
        }
        CGFloat imgX =  intMinHeightColumnIndex * (fltImageWidth + fltImageGap);
        
        CGRect viewFrame = CGRectMake(imgX, fltMinHeightColumn, fltImageWidth, objBlogTmp.fltImgHeight+75.0);
        [objHairBlog setFrame:viewFrame];
        
        objHairBlog.lblTitle.text = objBlogTmp.strTitle;
        [objHairBlog.btnComment setTitle:[NSString stringWithFormat:@"%d", objBlogTmp.intNoOfLike] forState:UIControlStateNormal];
        
        [objHairBlog.btnFacebook setTag:i];
        [objHairBlog.btnTwitter setTag:i];
        [objHairBlog.btnGooglePlus setTag:i];
        [objHairBlog.btnPinterest setTag:i];
        [objHairBlog.btnEmail setTag:i];
        
        [objHairBlog.btnFacebook addTarget:self action:@selector(btnTappedFacebook:) forControlEvents:UIControlEventTouchUpInside];
        [objHairBlog.btnTwitter addTarget:self action:@selector(btnTappedTwitter:) forControlEvents:UIControlEventTouchUpInside];
        [objHairBlog.btnGooglePlus addTarget:self action:@selector(btnTappedGooglePlus:) forControlEvents:UIControlEventTouchUpInside];
        [objHairBlog.btnPinterest addTarget:self action:@selector(btnTappedPinterest:) forControlEvents:UIControlEventTouchUpInside];
        [objHairBlog.btnEmail addTarget:self action:@selector(btnTappedEmail:) forControlEvents:UIControlEventTouchUpInside];
        
        CGRect imageFrame = CGRectMake(objHairBlog.imgPhoto.frame.origin.x, objHairBlog.imgPhoto.frame.origin.y, fltImageWidth, objBlogTmp.fltImgHeight);
        [objHairBlog.imgPhoto setFrame:imageFrame];
        
        CGRect subviewFrame = CGRectMake(objHairBlog.viewFooter.frame.origin.x, objHairBlog.imgPhoto.frame.origin.y + objBlogTmp.fltImgHeight, objHairBlog.viewFooter.frame.size.width, objHairBlog.viewFooter.frame.size.height);
        [objHairBlog.viewFooter setFrame:subviewFrame];
        
        [self.scrHorizontal addSubview:objHairBlog];
        
        arrayColumnHeight[intMinHeightColumnIndex] = viewFrame.origin.y+viewFrame.size.height;
        
        //Check for maximum column height for scroll height
        for (int j=0; j<pintNoOfColumn; j++){
            if (fltMaxHeightColumn < arrayColumnHeight[j])
            {
                fltMaxHeightColumn = arrayColumnHeight[j];
            }
        }
        
        self.scrHorizontal.contentSize=CGSizeMake(self.scrHorizontal.frame.size.width,fltMaxHeightColumn);
        
        dispatch_queue_t imageQ = dispatch_queue_create("imageQ", NULL);
        dispatch_async(imageQ, ^{
            NSData *imageData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:objBlogTmp.strPhotoUrl]];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                if(imageData){
                    
                    //CGFloat fltImageWidth = 145.0;
                    //CGFloat fltImageWidth = 93.0;
                    
                    objBlogTmp.imgPhoto = [UIImage imageWithData:imageData];
                    UIImage *imgTemp = [FunctionManager imageScaleAndCropWithFixWidth:objBlogTmp.imgPhoto withWidth:fltImageWidth];
                    objHairBlog.imgPhoto.image = imgTemp;
                    [FunctionManager setImageCorner:objHairBlog.imgPhoto radius:10.0];
                }
            });
        });
        dispatch_release(imageQ);
        
        //[self.scrHorizontal addSubview:imageView];
	}
    //Loading-2: End
    
    /*
     //Loading-1: Dyanmic get image width and height and based on that filling grid
	for (int i = 0; i < [self.arrBlogList count]; i++) {
        Blog *objBlogTmp = [self.arrBlogList objectAtIndex:i];
        
        dispatch_queue_t imageQ = dispatch_queue_create("imageQ", NULL);
        dispatch_async(imageQ, ^{
            NSData *imageData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:objBlogTmp.strPhotoUrl]];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                if(imageData){
                    
                    HairAdviceBlogView *objHairBlog = [[[NSBundle mainBundle] loadNibNamed:@"HairAdviceBlogView" owner:self options:nil]objectAtIndex:0];
                    
                    CGFloat fltImageWidth = 145.0;
                    CGFloat fltImageGap = 10.0;
                    //CGFloat fltImageWidth = 93.0;
                    //CGFloat fltImageGap = 10.0;
                    
                    objBlogTmp.imgPhoto = [UIImage imageWithData:imageData];
                    //imageView.image = objBlogTmp.imgPhoto;
                    UIImage *imgTemp = [FunctionManager imageScaleAndCropWithFixWidth:objBlogTmp.imgPhoto withWidth:fltImageWidth];
                    
                    //DLog(@"ID: %d, Width: %f, Height: %f", objBlogTmp.intBlogId, imgTemp.size.width, imgTemp.size.height);
                    
                    ////Currently static data is:
                    //total column : 2
                    //Gap between two column : 10
                    //Image width : 145
                     
                    ////Image width and Image inside UiView should be same.
                    
                    NSInteger intMinHeightColumnIndex = 0;
                    CGFloat fltMinHeightColumn = 20000.0;
                    CGFloat fltMaxHeightColumn = 0.0;
                    
                    //Check for minimum column index of min height
                    for (int j=0; j<pintNoOfColumn; j++) {
                        if (fltMinHeightColumn > arrayColumnHeight[j])
                        {
                            fltMinHeightColumn = arrayColumnHeight[j];
                            intMinHeightColumnIndex = j;
                        }
                    }
                    CGFloat imgX =  intMinHeightColumnIndex * (fltImageWidth + fltImageGap);
                    
                    CGRect viewFrame = CGRectMake(imgX, fltMinHeightColumn, fltImageWidth, imgTemp.size.height+75.0);
                    [objHairBlog setFrame:viewFrame];
                    
                    objHairBlog.lblTitle.text = objBlogTmp.strTitle;
                    [objHairBlog.btnFacebook setTag:i];
                    [objHairBlog.btnFacebook addTarget:self action:@selector(btnTappedFacebook:) forControlEvents:UIControlEventTouchUpInside];
                    
                    
//                    CGRect imageFrame = CGRectMake(imgX, fltMinHeightColumn, imgTemp.size.width, imgTemp.size.height);
//                    UIImageView *imageView=[[UIImageView alloc] initWithFrame:imageFrame];
//                    imageView.image = imgTemp;
                    
                    CGRect imageFrame = CGRectMake(objHairBlog.imgPhoto.frame.origin.x, objHairBlog.imgPhoto.frame.origin.y, imgTemp.size.width, imgTemp.size.height);
                    [objHairBlog.imgPhoto setFrame:imageFrame];
                    objHairBlog.imgPhoto.image = imgTemp;
                    
                    CGRect subviewFrame = CGRectMake(objHairBlog.viewFooter.frame.origin.x, objHairBlog.imgPhoto.frame.origin.y + imgTemp.size.height, objHairBlog.viewFooter.frame.size.width, objHairBlog.viewFooter.frame.size.height);
                    [objHairBlog.viewFooter setFrame:subviewFrame];
                    
                    //DLog(@"X: %f, Y: %f, Width: %f, Height: %f", imageView.frame.origin.x, imageView.frame.origin.y, imageView.frame.size.width, imageView.frame.size.height);
                    
                    //[self.scrHorizontal addSubview:imageView];
                    [self.scrHorizontal addSubview:objHairBlog];
                    
                    //arrayColumnHeight[intMinHeightColumnIndex] = imageView.frame.origin.y+imageView.frame.size.height+fltImageGap;
                    arrayColumnHeight[intMinHeightColumnIndex] = viewFrame.origin.y+viewFrame.size.height;
                    
                    //Check for maximum column height for scroll height
                    for (int j=0; j<pintNoOfColumn; j++){
                        if (fltMaxHeightColumn < arrayColumnHeight[j])
                        {
                            fltMaxHeightColumn = arrayColumnHeight[j];
                        }
                    }
                    
                    self.scrHorizontal.contentSize=CGSizeMake(self.scrHorizontal.frame.size.width,fltMaxHeightColumn);
                    DLog(@"Scroll Height: %f", fltMaxHeightColumn);
                }
            });
        });
        dispatch_release(imageQ);
        
        //[self.scrHorizontal addSubview:imageView];
	}
    */
    
    
	//self.scrHorizontal.contentSize = CGSizeMake(self.scrHorizontal.frame.size.width * self.arrBoardNews.count, self.scrHorizontal.frame.size.height);
}
-(void)initializeScrollColumnHeight:(int)pintNoOfColumn{
    for (int i=0; i<pintNoOfColumn; i++) {
        arrayColumnHeight[i] = 0.0;
    }
}

#pragma mark - Go Back
-(IBAction)btnTappedFacebook:(id)sender{
    Blog *objBlogTmp = [self.arrBlogList objectAtIndex:[sender tag]];
    DLog(@"%@", objBlogTmp.strTitle);
    
    //[SHKFacebook shareImage:objBlogTmp.imgPhoto title:objBlogTmp.strTitle];
}
-(IBAction)btnTappedTwitter:(id)sender{
    Blog *objBlogTmp = [self.arrBlogList objectAtIndex:[sender tag]];
    DLog(@"%@", objBlogTmp.strTitle);
    
    //[SHKTwitter shareImage:objBlogTmp.imgPhoto title:objBlogTmp.strTitle];
}
-(IBAction)btnTappedGooglePlus:(id)sender{
    Blog *objBlogTmp = [self.arrBlogList objectAtIndex:[sender tag]];
    DLog(@"%@", objBlogTmp.strTitle);
    
    //[SHKGooglePlus shareImage:objBlogTmp.imgPhoto title:objBlogTmp.strTitle];
}
-(IBAction)btnTappedPinterest:(id)sender{
    Blog *objBlogTmp = [self.arrBlogList objectAtIndex:[sender tag]];
    //DLog(@"%@", objBlogTmp.strTitle);
    
    ShareOnPinterestViewController *objShareOnPinterestVC;
    if(g_IS_IPHONE_5_SCREEN)
        objShareOnPinterestVC = [[[ShareOnPinterestViewController alloc] initWithNibName:@"ShareOnPinterestViewController" bundle:nil] autorelease];
    else
        objShareOnPinterestVC = [[[ShareOnPinterestViewController alloc] initWithNibName:@"ShareOnPinterestViewController4" bundle:nil] autorelease];
    
    objShareOnPinterestVC.objBlog = objBlogTmp;
    [self.navigationController pushViewController:objShareOnPinterestVC animated:YES];
}
-(IBAction)btnTappedEmail:(id)sender{
    Blog *objBlogTmp = [self.arrBlogList objectAtIndex:[sender tag]];
    DLog(@"%@", objBlogTmp.strTitle);
    
    [FunctionManager sendEmail:@"Donna Bella Hair" mailBody:objBlogTmp.strTitle isBodyHTML:YES toRecipientList:nil ccRecipientList:nil bccRecipientList:nil withImage:objBlogTmp.imgPhoto imageType:@"png" viewController:self delegate:self];
}
#pragma mark - Mail delegate
- (void)mailComposeController:(MFMailComposeViewController *)controller
          didFinishWithResult:(MFMailComposeResult)result
                        error:(NSError *)error
{
    switch (result) {
        case MFMailComposeResultCancelled:
            DLog(@"Cancelled");
            break;
        case MFMailComposeResultSaved:
            DLog(@"Saved");
            break;
        case MFMailComposeResultSent:
            DLog(@"Sent");
            break;
        case MFMailComposeResultFailed:
            DLog(@"Failed");
            break;
    }
    //[controller dismissModalViewControllerAnimated:YES];
    [controller dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - TableView DataSource and Delegate
/*
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(self.bolIsSearched){
        return [self.arrBlogListSearched count]+1;
    }
    else{
        return [self.arrBlogList count]+1;
    }
    //return 10;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 40.0;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CustomCellIdentifier = @"CustomCellIdentifier";
    ClientListCell *cell = (ClientListCell *)[tableView dequeueReusableCellWithIdentifier: CustomCellIdentifier];
    
    if(cell==nil || ![cell isKindOfClass:[ClientListCell class]])
    {
        NSArray *nib;
        nib = [[NSBundle mainBundle] loadNibNamed:@"ClientListCell"
                                            owner:self options:nil];
        
//         if((g_IS_IPHONE_5_SCREEN) || (g_IS_IPHONE_4_SCREEN))
//            nib = [[NSBundle mainBundle] loadNibNamed:@"ClientListCell"
//                owner:self options:nil];
//         else
//            nib = [[NSBundle mainBundle] loadNibNamed:@"ListDataCell_iPad"
//                owner:self options:nil];
        
        for (id oneObject in nib) if ([oneObject isKindOfClass:[ClientListCell class]])
            cell = (ClientListCell *)oneObject;
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [cell setBackgroundColor:[UIColor clearColor]];
    cell.lblTitle.font=[UIFont fontWithName:@"Rockwell-Bold" size:14];
    
    if(self.bolIsSearched){
        if(indexPath.row==[self.arrBlogListSearched count]){
            cell.lblTitle.text = @"Add a client...";
            [cell.lblTitle setTextColor:[UIColor magentaColor]];
        }
        else{
            //cell.lblTitle.text = [NSString stringWithFormat:@"Client: %d", indexPath.row];
            
            NSDictionary *dictClient=[self.arrBlogListSearched objectAtIndex:indexPath.row];
            cell.lblTitle.text=[dictClient objectForKey:@"client_name"];
            
            [cell.lblTitle setTextColor:[UIColor whiteColor]];
        }
    }
    else{
        if(indexPath.row==[self.arrBlogList count]){
            cell.lblTitle.text = @"Add a client...";
            [cell.lblTitle setTextColor:[UIColor magentaColor]];
        }
        else{
            //cell.lblTitle.text = [NSString stringWithFormat:@"Client: %d", indexPath.row];
            
            NSDictionary *dictClient=[self.arrBlogList objectAtIndex:indexPath.row];
            cell.lblTitle.text=[dictClient objectForKey:@"client_name"];
            
            [cell.lblTitle setTextColor:[UIColor whiteColor]];
        }
    }
    
    [cell.btnCell setTag:indexPath.row];
    [cell.btnCell addTarget:self action:@selector(btnTappedClientList:) forControlEvents:UIControlEventTouchUpInside];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
- (IBAction)btnTappedClientList:(id)sender{
    //DLog(@"Clicked: %d", [sender tag]);
    
    if(self.bolIsSearched){
        if([sender tag]==[self.arrBlogListSearched count]){
            //[self addClient];
        }
        else{
            NSDictionary *dictClient=[self.arrBlogListSearched objectAtIndex:[sender tag]];
            [self openClientProfile:dictClient];
        }
    }
    else{
        if([sender tag]==[self.arrBlogList count]){
            //[self addClient];
        }
        else{
            NSDictionary *dictClient=[self.arrBlogList objectAtIndex:[sender tag]];
            [self openClientProfile:dictClient];
        }
    }
}
*/
#pragma mark - Open Blog Detail
-(void)openClientProfile:(NSDictionary *)pDictClient{
    [self resignResponder];
    
    /*
    AddClientViewController *objAddClientVC;
    if(g_IS_IPHONE_5_SCREEN)
        objAddClientVC = [[[AddClientViewController alloc] initWithNibName:@"AddClientViewController" bundle:nil] autorelease];
    else
        objAddClientVC = [[[AddClientViewController alloc] initWithNibName:@"AddClientViewController4" bundle:nil] autorelease];
    
    objAddClientVC.bolIsEditMode = TRUE;
    objAddClientVC.dictClient = pDictClient;
    [self.navigationController pushViewController:objAddClientVC animated:YES];
     */
}

#pragma mark - Search
-(BOOL)checkEnteredData{
	if([_txtSearch.text isEmptyString]){
		[FunctionManager showMessage:nil withMessage:msgCTEnterSearch withDelegage:nil];
		return FALSE;
	}
	else {
	}
	return TRUE;
}
- (IBAction)btnTappedSearch:(id)sender{
    if([self checkEnteredData]){
        [self resignResponder];
        
        [self searchClient:_txtSearch.text];
    }
}
-(void)resignResponder{
	[_txtSearch resignFirstResponder];
}
-(void)searchClient:(NSString*)searchText{
    if([searchText isEmptyString]){
        self.bolIsSearched = FALSE;
    }
    else{
        self.bolIsSearched = TRUE;
        
        [self.arrBlogListSearched removeAllObjects];	// clear the filtered array first
        
        // search the table content for cell titles that match "searchText"
        // if found add to the mutable array
        
        for (NSDictionary *clientData in self.arrBlogList) {
            NSString *strClientName = [clientData objectForKey:@"client_name"];
            
            NSComparisonResult result = [strClientName compare:searchText options:NSCaseInsensitiveSearch range:NSMakeRange(0, [searchText length])];
            
            if (result == NSOrderedSame)  {
                [self.arrBlogListSearched addObject:clientData];
            }
        }
    }
    
    [_tblBlogList reloadData];
}
#pragma mark - UITextField delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString *strSearchText = [textField.text stringByReplacingCharactersInRange:range withString:string];
    //DLog(@"shouldChangeCharactersInRange = %@", newString);
    [self searchClient:strSearchText];
    
	return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField{
    //DLog(@"textFieldDidEndEditing = %@", textField.text);
    //[self searchClient:textField.text];
    
    if([_txtSearch.text isEmptyString]){
        self.bolIsSearched = FALSE;
        [_tblBlogList reloadData];
    }
}

#pragma mark - Go Back
-(IBAction)btnTappedBack:(id)sender{
    [FunctionManager gotoBack:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Orientations
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
	[self.strMessage release];
    
    if(self.arrBlogList.count>0)
        [self.arrBlogList removeAllObjects];
    [self.arrBlogList release];
    
    if(self.arrBlogListSearched.count>0)
        [self.arrBlogListSearched removeAllObjects];
    [self.arrBlogListSearched release];
    
    [_tblBlogList release];
    [_txtSearch release];
    
    [self.scrHorizontal release];
    
    [super dealloc];
}

@end
