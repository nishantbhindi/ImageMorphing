//
//  HairAdviceViewController.h
//  Donna Bella
//
//  Created by WebInfoways on 20/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShareKit.h"

#import "Blog.h"
#import "HairAdviceBlogView.h"

#import "ShareOnPinterestViewController.h"

#import "ClientListCell.h"

@class AppDelegate;

@interface HairAdviceViewController : UIViewController {
    AppDelegate *appDelegate;
	
	int intSuccess;
	NSString *strMessage;
    
    BOOL bolIsSearched;
    
    CGFloat arrayColumnHeight[2];
}
@property(nonatomic) int intSuccess;
@property(nonatomic,retain) NSString *strMessage;
@property(nonatomic) BOOL bolIsSearched;

@property(nonatomic,retain) NSMutableArray *arrBlogList;
@property(nonatomic,retain) NSMutableArray *arrBlogListSearched;
@property(nonatomic,retain) IBOutlet UITableView *tblBlogList;

@property (nonatomic, retain) IBOutlet UIScrollView *scrHorizontal;

@property(nonatomic,retain) IBOutlet UITextField *txtSearch;

-(void)setInitialParameter;
-(void)resetData;

-(void)bindStaticContent;
-(void)initializeScroll:(int)pintNoOfColumn;
-(void)initializeScrollColumnHeight:(int)pintNoOfColumn;

-(void)fetchBlogList;
-(void)openClientProfile:(NSDictionary *)pDictClient;

-(BOOL)checkEnteredData;
-(IBAction)btnTappedSearch:(id)sender;
-(void)resignResponder;
-(void)searchClient:(NSString*)searchText;

-(IBAction)btnTappedBack:(id)sender;

@end
