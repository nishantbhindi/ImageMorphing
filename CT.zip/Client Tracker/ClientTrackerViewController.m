//
//  ClientTrackerViewController.m
//  Donna Bella
//
//  Created by WebInfoways on 13/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import "ClientTrackerViewController.h"

@interface ClientTrackerViewController ()

@end

@implementation ClientTrackerViewController

@synthesize intSuccess, strMessage, bolIsSearched;
@synthesize arrClientList,arrClientListSearched;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	[self setInitialParameter];
}
- (void)viewWillAppear:(BOOL)animated{
    [self resetData];
    
    [self fetchClientList];
    //[_tblClientList reloadData];
}
- (void)viewDidDisappear:(BOOL)animated{
    [self resignResponder];
}

#pragma mark - Set Initial Parameter
-(void)setInitialParameter{
    //self.arrClientList = [[NSMutableArray alloc] init];
    self.arrClientListSearched = [[NSMutableArray alloc] init];
    [FunctionManager setDefaultTableViewStyle:_tblClientList delegate:self];
}
-(void)resetData{
    self.bolIsSearched = FALSE;
    _txtSearch.text=@"";
    
    [self resignResponder];
}

#pragma mark - Fetch Client List
-(void)fetchClientList{
    [self resignResponder];
    
    self.strMessage = @"";
    if(self.arrClientList.count>0)
        [self.arrClientList removeAllObjects];
    
    [FunctionManager displayLoadingView:self.view withMessage:msgLoadingGeneral appDelegate:appDelegate viewController:self];
    
    //http://webplanex.co.in/projects/donna_bella/iphone_api/calc_api.php?method=get_client&user_id=1
    
    NSString *strURL = [NSString stringWithFormat:@"%@calc_api.php?",g_BaseUrl];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[strURL toURL]];
    [request setDelegate:self];
    [request setRequestMethod:@"POST"];  //GET
    [request setTimeOutSeconds:g_Default_Timeout_Seconds];
    
    [request setPostValue:@"get_client" forKey:@"method"];
    [request setPostValue:@"json" forKey:@"format"];
    [request setPostValue:[NSString stringWithFormat:@"%d", appDelegate.objUser.intUserId] forKey:@"user_id"];
    //[request setPostValue:@"1" forKey:@"user_id"];
    
    [request setDidFinishSelector:@selector(clientListSuccess:)];
    [request setDidFailSelector:@selector(clientListFailed:)];
    [request startAsynchronous];
}
#pragma mark Client List Response
- (void)clientListSuccess:(ASIHTTPRequest *)request
{
    NSString *strResponse = [request responseString];
    SBJSON *objSBJSONParser = [[SBJSON alloc] init];
	NSDictionary *dictData = [objSBJSONParser objectWithString:strResponse error:nil];
	
    [FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
    
    int intStatus = [[dictData objectForKey:@"status"] intValue];
    
    if (intStatus==1) {
        self.arrClientList = (NSMutableArray *)[dictData objectForKey:@"data"];
        [_tblClientList reloadData];
    }
    else{
        if(![self.strMessage isEmptyString] && self.strMessage)
            [FunctionManager showMessage:nil withMessage:self.strMessage withDelegage:nil];
        else
            [FunctionManager showMessage:nil withMessage:msgRecordFetchFail withDelegage:nil];
    }
    
    /*
	NSString *strResponse = [request responseString];
	JSONParser *objJSONParser = [[JSONParser alloc] init];
    //[objJSONParser checkListResponse:strResponse withProductArray:self.arrClientList withParent:self withPageId:1];
	[objJSONParser release];
	
	[FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
    
    if(self.intSuccess==1)
        [_tblClientList reloadData];
    else{
        if(![self.strMessage isEmptyString] && self.strMessage)
            [FunctionManager showMessage:nil withMessage:self.strMessage withDelegage:nil];
        else
            [FunctionManager showMessage:nil withMessage:@"Error has been occurred while fetching data!" withDelegage:nil];
    }
     */
}
- (void)clientListFailed:(ASIHTTPRequest *)request
{
	NSError *error = [request error];
	[FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
	[FunctionManager showMessage:nil withMessage:[error localizedDescription] withDelegage:nil];
    //msgGenFetchRecordFail
}

#pragma mark - TableView DataSource and Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(self.bolIsSearched){
        return [self.arrClientListSearched count]+1;
    }
    else{
        return [self.arrClientList count]+1;
    }
    //return 10;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 40.0;
    /*
    if((g_IS_IPHONE_5_SCREEN) || (g_IS_IPHONE_4_SCREEN))
        return 40.0;
    else
        return 140.0;
     */
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CustomCellIdentifier = @"CustomCellIdentifier";
    ClientListCell *cell = (ClientListCell *)[tableView dequeueReusableCellWithIdentifier: CustomCellIdentifier];
    
    if(cell==nil || ![cell isKindOfClass:[ClientListCell class]])
    {
        NSArray *nib;
        nib = [[NSBundle mainBundle] loadNibNamed:@"ClientListCell"
                                            owner:self options:nil];
        /*
        if((g_IS_IPHONE_5_SCREEN) || (g_IS_IPHONE_4_SCREEN))
            nib = [[NSBundle mainBundle] loadNibNamed:@"ClientListCell"
                                                owner:self options:nil];
        else
            nib = [[NSBundle mainBundle] loadNibNamed:@"ListDataCell_iPad"
                                                owner:self options:nil];
        */
        
        for (id oneObject in nib) if ([oneObject isKindOfClass:[ClientListCell class]])
            cell = (ClientListCell *)oneObject;
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    [cell setBackgroundColor:[UIColor clearColor]];
    cell.lblTitle.font=[UIFont fontWithName:@"Rockwell-Bold" size:14];
    
    if(self.bolIsSearched){
        if(indexPath.row==[self.arrClientListSearched count]){
            cell.lblTitle.text = @"Add a client...";
            [cell.lblTitle setTextColor:[UIColor magentaColor]];
        }
        else{
            //cell.lblTitle.text = [NSString stringWithFormat:@"Client: %d", indexPath.row];
            
            NSDictionary *dictClient=[self.arrClientListSearched objectAtIndex:indexPath.row];
            cell.lblTitle.text=[dictClient objectForKey:@"client_name"];
            
            [cell.lblTitle setTextColor:[UIColor whiteColor]];
        }
    }
    else{
        if(indexPath.row==[self.arrClientList count]){
            cell.lblTitle.text = @"Add a client...";
            [cell.lblTitle setTextColor:[UIColor magentaColor]];
        }
        else{
            //cell.lblTitle.text = [NSString stringWithFormat:@"Client: %d", indexPath.row];
            
            NSDictionary *dictClient=[self.arrClientList objectAtIndex:indexPath.row];
            cell.lblTitle.text=[dictClient objectForKey:@"client_name"];
            
            [cell.lblTitle setTextColor:[UIColor whiteColor]];
        }
    }
    
    [cell.btnCell setTag:indexPath.row];
    [cell.btnCell addTarget:self action:@selector(btnTappedClientList:) forControlEvents:UIControlEventTouchUpInside];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
- (IBAction)btnTappedClientList:(id)sender{
    //DLog(@"Clicked: %d", [sender tag]);
    
    if(self.bolIsSearched){
        if([sender tag]==[self.arrClientListSearched count]){
            [self addClient];
        }
        else{
            NSDictionary *dictClient=[self.arrClientListSearched objectAtIndex:[sender tag]];
            [self openClientProfile:dictClient];
        }
    }
    else{
        if([sender tag]==[self.arrClientList count]){
            [self addClient];
        }
        else{
            NSDictionary *dictClient=[self.arrClientList objectAtIndex:[sender tag]];
            [self openClientProfile:dictClient];
        }
    }
}

#pragma mark - Open Client Profile
-(void)openClientProfile:(NSDictionary *)pDictClient{
    [self resignResponder];
    
    AddClientViewController *objAddClientVC;
    if(g_IS_IPHONE_5_SCREEN)
        objAddClientVC = [[[AddClientViewController alloc] initWithNibName:@"AddClientViewController" bundle:nil] autorelease];
    else
        objAddClientVC = [[[AddClientViewController alloc] initWithNibName:@"AddClientViewController4" bundle:nil] autorelease];
    
    objAddClientVC.bolIsEditMode = TRUE;
    objAddClientVC.dictClient = pDictClient;
    [self.navigationController pushViewController:objAddClientVC animated:YES];
}
#pragma mark - Add Client
- (IBAction)btnTappedAddClient:(id)sender{
    [self addClient];
}
-(void)addClient{
    [self resignResponder];
    
    AddClientViewController *objAddClientVC;
    if(g_IS_IPHONE_5_SCREEN)
        objAddClientVC = [[[AddClientViewController alloc] initWithNibName:@"AddClientViewController" bundle:nil] autorelease];
    else
        objAddClientVC = [[[AddClientViewController alloc] initWithNibName:@"AddClientViewController4" bundle:nil] autorelease];
    
    objAddClientVC.bolIsEditMode = FALSE;
    [self.navigationController pushViewController:objAddClientVC animated:YES];
}

#pragma mark - Search
-(BOOL)checkEnteredData{
	if([_txtSearch.text isEmptyString]){
		[FunctionManager showMessage:nil withMessage:msgCTEnterSearch withDelegage:nil];
		return FALSE;
	}
	else {
	}
	return TRUE;
}
- (IBAction)btnTappedSearch:(id)sender{
    if([self checkEnteredData]){
        [self resignResponder];
        
        [self searchClient:_txtSearch.text];
    }
}
-(void)resignResponder{
	[_txtSearch resignFirstResponder];
}
-(void)searchClient:(NSString*)searchText{
    if([searchText isEmptyString]){
        self.bolIsSearched = FALSE;
    }
    else{
        self.bolIsSearched = TRUE;
        
        [self.arrClientListSearched removeAllObjects];	// clear the filtered array first
        
        // search the table content for cell titles that match "searchText"
        // if found add to the mutable array
        
        for (NSDictionary *clientData in self.arrClientList) {
            NSString *strClientName = [clientData objectForKey:@"client_name"];
            
            NSComparisonResult result = [strClientName compare:searchText options:NSCaseInsensitiveSearch range:NSMakeRange(0, [searchText length])];
            
            if (result == NSOrderedSame)  {
                [self.arrClientListSearched addObject:clientData];
            }
        }
    }
    
    [_tblClientList reloadData];
}
#pragma mark - UITextField delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString *strSearchText = [textField.text stringByReplacingCharactersInRange:range withString:string];
    //DLog(@"shouldChangeCharactersInRange = %@", newString);
    [self searchClient:strSearchText];
    
	return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField{
    //DLog(@"textFieldDidEndEditing = %@", textField.text);
    //[self searchClient:textField.text];
    
    if([_txtSearch.text isEmptyString]){
        self.bolIsSearched = FALSE;
        [_tblClientList reloadData];
    }
}

#pragma mark - Go Back
-(IBAction)btnTappedBack:(id)sender{
    [FunctionManager gotoBack:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Orientations
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
	[self.strMessage release];
    
    if(self.arrClientList.count>0)
        [self.arrClientList removeAllObjects];
    [self.arrClientList release];
    
    if(self.arrClientListSearched.count>0)
        [self.arrClientListSearched removeAllObjects];
    [self.arrClientListSearched release];
    
    [_tblClientList release];
    [_txtSearch release];
    
    [super dealloc];
}
@end
