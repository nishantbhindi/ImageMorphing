//
//  ClientListCell.h
//  Donna Bella
//
//  Created by WebInfoways on 13/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClientListCell : UITableViewCell

@property(nonatomic,retain) IBOutlet UILabel *lblTitle;
@property(nonatomic,retain) IBOutlet UIButton *btnCell;

@end
