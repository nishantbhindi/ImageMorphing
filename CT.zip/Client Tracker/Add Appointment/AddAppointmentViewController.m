//
//  AddAppointmentViewController.m
//  Donna Bella
//
//  Created by WebInfoways on 17/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import "AddAppointmentViewController.h"

#define kANIMATION_DURATION         0.5

@interface AddAppointmentViewController ()

@end

@implementation AddAppointmentViewController

@synthesize bolIsEditMode, intClientId, dictAppointment;
@synthesize intSuccess, strMessage;
@synthesize strSelectedAppointmentDate, intSelectedHairExtension, intSelectedLength, intSelectedColor;
@synthesize strSelectedScheduledDate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	[self setInitialParameter];
}
- (void)viewWillAppear:(BOOL)animated{
    [self resetData];
    
    if(self.bolIsEditMode){
        [self setData];
    }
    else{
        [self setDefaultData];
    }
}

#pragma mark - Set Initial Parameter
-(void)setInitialParameter{
    _lblTitle.font=[UIFont fontWithName:@"Rockwell-Bold" size:15];
    
    [_viewNote setFrame:CGRectMake(0.0, self.view.frame.size.height, _viewNote.frame.size.width, _viewNote.frame.size.height)];
	[self.view addSubview:_viewNote];
    
    [_viewReminder setFrame:CGRectMake(0.0, self.view.frame.size.height, _viewReminder.frame.size.width, _viewReminder.frame.size.height)];
	[self.view addSubview:_viewReminder];
}
-(void)setData{
    self.strSelectedAppointmentDate = [self.dictAppointment objectForKey:@"appoin_date"];
    
    NSString *strAppointmentDisplayDt = [FunctionManager getFormatedDate:self.strSelectedAppointmentDate withDateFormat:g_DateTimeFormatDefault withDisplayFormat:g_DateFormatDisplay2];
    [_btnAppointmentDate setTitle:strAppointmentDisplayDt forState:UIControlStateNormal];
    
    [self setHairExtensionMethod:[[self.dictAppointment objectForKey:@"hair_extension_method"] intValue]];
    [self setLength:[[self.dictAppointment objectForKey:@"length"] intValue]];
    [self setColor:[[self.dictAppointment objectForKey:@"color"] intValue]];
    
    _txtNote.text = [self.dictAppointment objectForKey:@"notes"];
    self.strSelectedScheduledDate = [self.dictAppointment objectForKey:@"schedule_reminder"];
    
    _lblNoOfPack.text = [NSString stringWithFormat:@"%d", [[self.dictAppointment objectForKey:@"no_of_pack"] intValue]];
}
-(void)resetData{
}

#pragma mark - Set Data
-(void)setDefaultData{
    self.strSelectedAppointmentDate = @"";
    self.strSelectedScheduledDate = @"";
    
    [self setHairExtensionMethod:0];
    [self setLength:0];
    [self setColor:0];
    
    _lblNoOfPack.text = @"3";
    _txtNote.text = @"Start here...";
}
-(void)setHairExtensionMethod:(int)pTag{
    self.intSelectedHairExtension = pTag;
    
    switch (pTag) {
        case 0:
            [_btnHairExtensionMethod1 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            [_btnHairExtensionMethod2 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnHairExtensionMethod3 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            break;
        case 1:
            [_btnHairExtensionMethod1 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnHairExtensionMethod2 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            [_btnHairExtensionMethod3 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [_btnHairExtensionMethod1 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnHairExtensionMethod2 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnHairExtensionMethod3 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            break;
        default:
            [_btnHairExtensionMethod1 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            [_btnHairExtensionMethod2 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnHairExtensionMethod3 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            break;
    }
}
-(void)setLength:(int)pTag{
    self.intSelectedLength = pTag;
    
    switch (pTag) {
        case 0:
            [_btnLength1 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            [_btnLength2 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnLength3 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            break;
        case 1:
            [_btnLength1 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnLength2 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            [_btnLength3 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [_btnLength1 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnLength2 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnLength3 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            break;
        default:
            [_btnLength1 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            [_btnLength2 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnLength3 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            break;
    }
}
-(void)setColor:(int)pTag{
    self.intSelectedColor = pTag;
    
    switch (pTag) {
        case 0:
            [_btnColor1 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            [_btnColor2 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor3 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor4 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor5 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            break;
        case 1:
            [_btnColor1 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor2 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            [_btnColor3 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor4 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor5 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [_btnColor1 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor2 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor3 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            [_btnColor4 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor5 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [_btnColor1 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor2 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor3 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor4 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            [_btnColor5 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            break;
        case 4:
            [_btnColor1 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor2 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor3 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor4 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor5 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            break;
        default:
            [_btnColor1 setImage:[UIImage imageNamed:@"btnCheck.png"] forState:UIControlStateNormal];
            [_btnColor2 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor3 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor4 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            [_btnColor5 setImage:[UIImage imageNamed:@"btnUnCheck.png"] forState:UIControlStateNormal];
            break;
    }
}

#pragma mark - Btn Tapped Selection
-(IBAction)btnTappedHairExtension:(id)sender{
    [self setHairExtensionMethod:[sender tag]];
}
-(IBAction)btnTappedLength:(id)sender{
    [self setLength:[sender tag]];
}
-(IBAction)btnTappedColor:(id)sender{
    [self setColor:[sender tag]];
}
-(IBAction)btnTappedNoOfPack:(id)sender{
    if([sender tag]==1){
        //Increase Value
        _lblNoOfPack.text = [NSString stringWithFormat:@"%d",  [_lblNoOfPack.text intValue]+1];
    }
    else{
        //Decrease Value
        if([_lblNoOfPack.text intValue]>0)
            _lblNoOfPack.text = [NSString stringWithFormat:@"%d",  [_lblNoOfPack.text intValue]-1];
    }
}

#pragma mark - Btn Tapped Add Date
-(IBAction)btnTappedAddDate:(id)sender{
    DatePickerVC *objDatePickerVC;
    
    objDatePickerVC = [[DatePickerVC alloc] initWithNibNameAndData:self.strSelectedAppointmentDate withDateFormat:g_DateTimeFormatDefault withDateDisplayFormat:g_DateFormatDisplay2 withID:self withPickerOptionID:1 withButtonTag:1];
    objDatePickerVC.delegate = self;
	[self.view addSubview:objDatePickerVC.view];
	objDatePickerVC.view.frame=CGRectMake(objDatePickerVC.view.frame.origin.x, self.view.frame.size.height-objDatePickerVC.view.frame.size.height, objDatePickerVC.view.frame.size.width, objDatePickerVC.view.frame.size.height);
    //[objPickerController release];
}
-(void)onSelect:(int)pintPickerOptionId withDate:(NSDate *)pdtSelectedDate
{
    [self removePicker];
    
    self.strSelectedAppointmentDate = [FunctionManager getFormatedDate:[pdtSelectedDate description] withDateFormat:g_DateTimeFormatDefaultZone withDisplayFormat:g_DateTimeFormatDefault];
    
    NSString *strAppointmentDisplayDt = [FunctionManager getFormatedDate:[pdtSelectedDate description] withDateFormat:g_DateTimeFormatDefaultZone withDisplayFormat:g_DateFormatDisplay2];
    [_btnAppointmentDate setTitle:strAppointmentDisplayDt forState:UIControlStateNormal];
}
-(IBAction)btnTappedClose:(id)sender
{
    [self removePicker];
}
-(void)removePicker{
    /*if([self.view.subviews containsObject:appDelegate.objPickerView])
        [appDelegate.objPickerView removeFromSuperview];*/
    
    /*
    for(int i=0;i<[self.view.subviews count];i++){
        //DLog(@"%@", [self.view.subviews objectAtIndex:i]);
        
        if ([[self.view.subviews objectAtIndex:i] isKindOfClass:[PickerView class]])
            [appDelegate.objPickerView removeFromSuperview];
    }*/
    for(int i=0;i<[self.view.subviews count];i++){
        //DLog(@"%@", [self.view.subviews objectAtIndex:i]);
        
        id nextResponder = [[self.view.subviews objectAtIndex:i] nextResponder];
        if ([nextResponder isKindOfClass:[DatePickerVC class]]) {
            [[self.view.subviews objectAtIndex:i] removeFromSuperview];
        }
    }
}

#pragma mark - Btn Tapped Notes
-(IBAction)btnTappedAddNotesView:(id)sender{
    [UIView animateWithDuration:kANIMATION_DURATION delay:0.0f options:UIViewAnimationCurveEaseInOut animations:^{
        _viewNote.frame = CGRectMake(_viewNote.frame.origin.x, self.view.frame.size.height-(_viewNote.frame.size.height+51.0), _viewNote.frame.size.width, _viewNote.frame.size.height);
        [self.view bringSubviewToFront:_viewNote];
        [_txtNote becomeFirstResponder];
    }completion:^(BOOL finished) {
        //DLog(@"Animation is complete");
    }];
}
-(IBAction)btnTappedRemoveNotesView:(id)sender{
    [_txtNote resignFirstResponder];
    
    [UIView animateWithDuration:kANIMATION_DURATION delay:0.0f options:UIViewAnimationCurveEaseInOut animations:^{
        _viewNote.frame = CGRectMake(_viewNote.frame.origin.x, self.view.frame.size.height, _viewNote.frame.size.width, _viewNote.frame.size.height);
    }completion:^(BOOL finished) {
        //DLog(@"Animation is complete");
    }];
}
-(IBAction)btnTappedDoneNotes:(id)sender{
    [self btnTappedRemoveNotesView:nil];
}
#pragma mark - UITextField delegate
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    if(textView==_txtNote){
        if([_txtNote.text isEqualToString:@"Start here..."]){
            _txtNote.text = @"";
        }
    }
    return YES;
}

#pragma mark - Btn Tapped Schedule Reminder
-(IBAction)btnTappedAddReminderView:(id)sender{
    [UIView animateWithDuration:kANIMATION_DURATION delay:0.0f options:UIViewAnimationCurveEaseInOut animations:^{
        if(![self.strSelectedScheduledDate isEmptyString])
            [_datePickerReminder setDate:[FunctionManager getDateFromString:self.strSelectedScheduledDate withFormat:g_DateTimeFormatDefault] animated:YES];
        
        _viewReminder.frame = CGRectMake(_viewReminder.frame.origin.x, self.view.frame.size.height-(_viewReminder.frame.size.height+51.0), _viewReminder.frame.size.width, _viewReminder.frame.size.height);
        [self.view bringSubviewToFront:_viewReminder];
    }completion:^(BOOL finished) {
        //DLog(@"Animation is complete");
    }];
}
-(IBAction)btnTappedRemoveReminderView:(id)sender{
    [UIView animateWithDuration:kANIMATION_DURATION delay:0.0f options:UIViewAnimationCurveEaseInOut animations:^{
        _viewReminder.frame = CGRectMake(_viewReminder.frame.origin.x, self.view.frame.size.height, _viewReminder.frame.size.width, _viewReminder.frame.size.height);
    }completion:^(BOOL finished) {
        //DLog(@"Animation is complete");
    }];
}
-(IBAction)btnTappedDoneReminder:(id)sender{
    self.strSelectedScheduledDate = [FunctionManager getFormatedDate:[[_datePickerReminder date] description] withDateFormat:g_DateTimeFormatDefaultZone withDisplayFormat:g_DateTimeFormatDefault];
    
    [self btnTappedRemoveReminderView:nil];
}

#pragma mark - Save
-(BOOL)checkEnteredData{
    if([self.strSelectedAppointmentDate isEmptyString]){
		[FunctionManager showMessage:nil withMessage:msgCASelectAppointmentDate withDelegage:nil];
		return FALSE;
	}
	else {
	}
	return TRUE;
}
-(IBAction)btnTappedSave:(id)sender{
    if([self checkEnteredData]){
        [FunctionManager displayLoadingView:self.view withMessage:msgLoadingGeneral appDelegate:appDelegate viewController:self];
        
        //http://webplanex.co.in/projects/donna_bella/iphone_api/calc_api.php?method=insertAppoinment&user_id=1&client_id=1&appoin_date=2014-02-14%2005:54:16&hair_extension_method=TAPE-IN&length=16&no_of_pack=1&color=1B&notes=Lorem%20Ipsum%20is%20simply%20dummy%20text%20of%20the%20printing%20and%20typesetting%20industry.&schedule_reminder=2014-02-14%2005:54:16
        
        //http://webplanex.co.in/projects/donna_bella/iphone_api/calc_api.php?method=updateAppoinment&user_id=1&client_id=1&appoin_date=2014-02-14%2013:16:14&hair_extension_method=1&length=2&no_of_pack=2&color=1&notes=Let%20every%20user%20access%20this%20bookmark&schedule_reminder=2014-02-14%2007:22:36&id=1
        
        NSString *strURL = [NSString stringWithFormat:@"%@calc_api.php?",g_BaseUrl];
        ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[strURL toURL]];
        [request setDelegate:self];
        [request setRequestMethod:@"POST"];  //GET
        [request setTimeOutSeconds:g_Default_Timeout_Seconds];
        [request setPostValue:@"json" forKey:@"format"];
        
        if(self.bolIsEditMode){
            [request setPostValue:@"updateAppoinment" forKey:@"method"];
            [request setPostValue:[NSString stringWithFormat:@"%d", [[self.dictAppointment objectForKey:@"appoinment_id"] intValue]] forKey:@"appoinment_id"];
        }
        else{
            [request setPostValue:@"insertAppoinment" forKey:@"method"];
        }
        
        [request setPostValue:[NSString stringWithFormat:@"%d", appDelegate.objUser.intUserId] forKey:@"user_id"];
        [request setPostValue:[NSString stringWithFormat:@"%d", self.intClientId] forKey:@"client_id"];
        
        [request setPostValue:self.strSelectedAppointmentDate forKey:@"appoin_date"];
        [request setPostValue:[NSString stringWithFormat:@"%d", self.intSelectedHairExtension] forKey:@"hair_extension_method"];
        [request setPostValue:[NSString stringWithFormat:@"%d", self.intSelectedLength] forKey:@"length"];
        [request setPostValue:[NSString stringWithFormat:@"%d", self.intSelectedColor] forKey:@"color"];
        [request setPostValue:_lblNoOfPack.text forKey:@"no_of_pack"];
        [request setPostValue:self.strSelectedScheduledDate forKey:@"schedule_reminder"];
        
        if([_txtNote.text isEqualToString:@"Start here..."])
            [request setPostValue:@"" forKey:@"notes"];
        else
            [request setPostValue:_txtNote.text forKey:@"notes"];
        
        [request setDidFinishSelector:@selector(saveAppointmentSuccess:)];
        [request setDidFailSelector:@selector(saveAppointmentFailed:)];
        [request startAsynchronous];
    }
}
#pragma mark Save Appointment Response
- (void)saveAppointmentSuccess:(ASIHTTPRequest *)request
{
    NSString *strResponse = [request responseString];
    SBJSON *objSBJSONParser = [[SBJSON alloc] init];
	NSDictionary *dictData = [objSBJSONParser objectWithString:strResponse error:nil];
	
    [FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
    
    int intStatus = [[dictData objectForKey:@"status"] intValue];
    
    if (intStatus==1){
        if(self.bolIsEditMode)
            [FunctionManager showMessage:nil withMessage:msgRecordUpdateSuccess withDelegage:nil];
        else
            [FunctionManager showMessage:nil withMessage:msgRecordAddSuccess withDelegage:nil];
        
        [self btnTappedBack:nil];
    }
    else
        [FunctionManager showMessage:nil withMessage:msgRecordAddFail withDelegage:nil];
}
- (void)saveAppointmentFailed:(ASIHTTPRequest *)request
{
	NSError *error = [request error];
	[FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
	[FunctionManager showMessage:nil withMessage:[error localizedDescription] withDelegage:nil];
}

#pragma mark - Go Back
-(IBAction)btnTappedBack:(id)sender{
    [FunctionManager gotoBack:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Orientations
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
	[self.strMessage release];
    
    [self.strSelectedAppointmentDate release];
    [self.strSelectedScheduledDate release];
    
    [_lblTitle release];
    [_lblClientName release];
    
    [_btnAppointmentDate release];
    
    [_btnHairExtensionMethod1 release];
    [_btnHairExtensionMethod2 release];
    [_btnHairExtensionMethod3 release];
    
    [_btnLength1 release];
    [_btnLength2 release];
    [_btnLength3 release];
    
    [_btnColor1 release];
    [_btnColor2 release];
    [_btnColor3 release];
    [_btnColor4 release];
    [_btnColor5 release];
    
    [_btnPackMinus release];
    [_btnPackPlus release];
    
    [_viewNote release];
    [_txtNote release];
    
    [_viewReminder release];
    [_datePickerReminder release];
    
    [super dealloc];
}

@end
