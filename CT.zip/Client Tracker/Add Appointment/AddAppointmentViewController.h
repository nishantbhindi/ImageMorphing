//
//  AddAppointmentViewController.h
//  Donna Bella
//
//  Created by WebInfoways on 17/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DatePickerVC.h"

@class AppDelegate;

@interface AddAppointmentViewController : UIViewController <DatePickerViewChangeDelegate> {
    AppDelegate *appDelegate;
}
@property(nonatomic) BOOL bolIsEditMode;
@property(nonatomic) int intClientId;
@property(nonatomic,retain) NSDictionary *dictAppointment;

@property(nonatomic) int intSuccess;
@property(nonatomic,retain) NSString *strMessage;

@property (nonatomic, retain) IBOutlet UILabel *lblTitle;
@property (nonatomic, retain) IBOutlet UILabel *lblClientName;

@property (nonatomic, retain) IBOutlet UIButton *btnAppointmentDate;

@property (nonatomic, retain) IBOutlet UIButton *btnHairExtensionMethod1;
@property (nonatomic, retain) IBOutlet UIButton *btnHairExtensionMethod2;
@property (nonatomic, retain) IBOutlet UIButton *btnHairExtensionMethod3;

@property (nonatomic, retain) IBOutlet UIButton *btnLength1;
@property (nonatomic, retain) IBOutlet UIButton *btnLength2;
@property (nonatomic, retain) IBOutlet UIButton *btnLength3;

@property (nonatomic, retain) IBOutlet UIButton *btnColor1;
@property (nonatomic, retain) IBOutlet UIButton *btnColor2;
@property (nonatomic, retain) IBOutlet UIButton *btnColor3;
@property (nonatomic, retain) IBOutlet UIButton *btnColor4;
@property (nonatomic, retain) IBOutlet UIButton *btnColor5;

@property (nonatomic, retain) IBOutlet UIButton *btnPackMinus;
@property (nonatomic, retain) IBOutlet UIButton *btnPackPlus;

@property (nonatomic, retain) IBOutlet UILabel *lblNoOfPack;

@property(nonatomic,retain) NSString *strSelectedAppointmentDate;
@property(nonatomic) int intSelectedHairExtension;
@property(nonatomic) int intSelectedLength;
@property(nonatomic) int intSelectedColor;

@property (nonatomic, retain) IBOutlet UIView *viewNote;
@property (nonatomic, retain) IBOutlet UITextView *txtNote;

@property (nonatomic, retain) IBOutlet UIView *viewReminder;
@property(nonatomic, retain) IBOutlet UIDatePicker *datePickerReminder;
@property(nonatomic,retain) NSString *strSelectedScheduledDate;

-(void)setInitialParameter;
-(void)setData;
-(void)resetData;

-(void)setDefaultData;

-(void)setHairExtensionMethod:(int)pTag;
-(void)setLength:(int)pTag;
-(void)setColor:(int)pTag;
    
-(IBAction)btnTappedHairExtension:(id)sender;
-(IBAction)btnTappedLength:(id)sender;
-(IBAction)btnTappedColor:(id)sender;
-(IBAction)btnTappedNoOfPack:(id)sender;

-(IBAction)btnTappedAddDate:(id)sender;

-(IBAction)btnTappedAddNotesView:(id)sender;
-(IBAction)btnTappedRemoveNotesView:(id)sender;
-(IBAction)btnTappedDoneNotes:(id)sender;

-(IBAction)btnTappedAddReminderView:(id)sender;
-(IBAction)btnTappedRemoveReminderView:(id)sender;
-(IBAction)btnTappedDoneReminder:(id)sender;

-(BOOL)checkEnteredData;
-(IBAction)btnTappedSave:(id)sender;

-(IBAction)btnTappedBack:(id)sender;

@end
