//
//  AddClientView.h
//  Donna Bella
//
//  Created by WebInfoways on 15/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppDelegate;

@interface AddClientView : UIView
{
    id _parent;
    AppDelegate *_appDelegate;
    UIViewController *_parentController;
}
@property(nonatomic) BOOL bolIsEditMode;
@property(nonatomic) int intClientId;

@property (nonatomic, retain) IBOutlet UITextField *txtName;
@property (nonatomic, retain) IBOutlet UITextField *txtPhone;
@property (nonatomic, retain) IBOutlet UITextField *txtEmail;
@property (nonatomic, retain) IBOutlet UITextView *txtAddress;

@property (nonatomic, retain) IBOutlet UILabel *lblAddress;
@property (nonatomic, retain) IBOutlet UILabel *lblPhone;
@property (nonatomic, retain) IBOutlet UILabel *lblMobile;
@property (nonatomic, retain) IBOutlet UILabel *lblEmail;

@property (nonatomic, retain) IBOutlet UIButton *btnEdit;

-(void)setData:(id)pID appDelegate:(AppDelegate*)pAppDelegate viewController:(UIViewController*)pViewController isEditMode:(BOOL)pBolEditMode ClientData:(NSDictionary*)pDicClient;

-(BOOL)checkEnteredData;
-(IBAction)btnTappedSave:(id)sender;
-(void)resignResponder;
-(void)resetData;
-(void)saveClientData;

-(IBAction)btnTappedDelete:(id)sender;
-(void)deleteClient;

-(IBAction)btnTappedCall:(id)sender;
-(IBAction)btnTappedEmail:(id)sender;

@end
