//
//  AddClientViewController.m
//  Donna Bella
//
//  Created by WebInfoways on 13/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import "AddClientViewController.h"

@interface AddClientViewController ()

@end

@implementation AddClientViewController

@synthesize bolIsEditMode, dictClient;
@synthesize intSuccess, strMessage;
@synthesize arrAppointment,intAppointmentDeleteIndex;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	[self setInitialParameter];
}
- (void)viewWillAppear:(BOOL)animated{
    [self resetData];
    [_tblClient reloadData];
    
    if(self.bolIsEditMode){
        [self fetchClientDetail];
    }
}

#pragma mark - Set Initial Parameter
-(void)setInitialParameter{
    [FunctionManager setDefaultTableViewStyle:_tblClient delegate:self];
    
    if (!expandedSections)
    {
        expandedSections = [[NSMutableIndexSet alloc] init];
    }
}
-(void)resetData{
}
-(void)reloadData{
    [_tblClient reloadData];
}

#pragma mark - Fetch Client Detail
-(void)fetchClientDetail{    
    self.strMessage = @"";
    
    [FunctionManager displayLoadingView:self.view withMessage:msgLoadingGeneral appDelegate:appDelegate viewController:self];
    
    //http://webplanex.co.in/projects/donna_bella/iphone_api/calc_api.php?method=getClientDetail&client_id=2&user_id=1
    
    NSString *strURL = [NSString stringWithFormat:@"%@calc_api.php?",g_BaseUrl];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[strURL toURL]];
    [request setDelegate:self];
    [request setRequestMethod:@"POST"];  //GET
    [request setTimeOutSeconds:g_Default_Timeout_Seconds];
    
    [request setPostValue:@"getClientDetail" forKey:@"method"];
    [request setPostValue:@"json" forKey:@"format"];
    [request setPostValue:[NSString stringWithFormat:@"%d", appDelegate.objUser.intUserId] forKey:@"user_id"];
    [request setPostValue:[NSString stringWithFormat:@"%d", [[dictClient objectForKey:@"client_id"] intValue]] forKey:@"client_id"];
    
    [request setDidFinishSelector:@selector(clientDetailSuccess:)];
    [request setDidFailSelector:@selector(clientDetailFailed:)];
    [request startAsynchronous];
}
#pragma mark Client Detail Response
- (void)clientDetailSuccess:(ASIHTTPRequest *)request
{
    NSString *strResponse = [request responseString];
    SBJSON *objSBJSONParser = [[SBJSON alloc] init];
	NSDictionary *dictData = [objSBJSONParser objectWithString:strResponse error:nil];
	
    [FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
    
    int intStatus = [[dictData objectForKey:@"status"] intValue];
    
    if (intStatus==1) {
        self.dictClient = [[dictData objectForKey:@"data"] objectForKey:@"client"];
        self.arrAppointment = (NSMutableArray *)[[dictData objectForKey:@"data"] objectForKey:@"appoinment"];
        [_tblClient reloadData];
    }
    else{
        if(![self.strMessage isEmptyString] && self.strMessage)
            [FunctionManager showMessage:nil withMessage:self.strMessage withDelegage:nil];
        else
            [FunctionManager showMessage:nil withMessage:msgRecordFetchFail withDelegage:nil];
    }
}
- (void)clientDetailFailed:(ASIHTTPRequest *)request
{
	NSError *error = [request error];
	[FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
	[FunctionManager showMessage:nil withMessage:[error localizedDescription] withDelegage:nil];
    //msgGenFetchRecordFail
}

#pragma mark - TableView DataSource and Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ([expandedSections containsIndex:section]){
        switch (section) {
            case 0:
                return 1;
                break;
            case 1:
                return [self.arrAppointment count]+3;
                //return 6;   //3+3
                break;
            case 2:
                return 0;
                break;
            default:
                return 0;
                break;
        }
    }
    else
        return 0;
    
    return 0;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *objView =[[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 320.0, 30.0)];
    [objView setBackgroundColor:[UIColor grayColor]];
    
    UIImageView *imgBgHeader = [[UIImageView alloc] init];
    [imgBgHeader setImage:[UIImage imageNamed:@"bg_Search.png"]];
    [imgBgHeader setFrame:CGRectMake(0.0, 0.0, 320.0, 30.0)];
    [objView addSubview:imgBgHeader];
    [imgBgHeader release];
    
    /*
    UIImageView *imgExpCollp = [[UIImageView alloc] init];
    if ([expandedSections containsIndex:section])
        [imgExpCollp setImage:[UIImage imageNamed:@"ico_expand.png"]];
    else
        [imgExpCollp setImage:[UIImage imageNamed:@"ico_collapse.png"]];
    [imgExpCollp setFrame:CGRectMake(295.0, 10.0, 13.0, 9.0)];
    [objView addSubview:imgExpCollp];
    [imgExpCollp release];*/
    
    UIButton *btnTitle=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnTitle setFrame:CGRectMake(10.0, 0.0, 300.0, 30.0)];
    switch (section) {
        case 0:
            [btnTitle setTitle:@"PROFILE" forState:UIControlStateNormal];
            break;
        case 1:
            [btnTitle setTitle:@"APPOINTMENTS" forState:UIControlStateNormal];
            break;
        case 2:
            [btnTitle setTitle:@"SAVED CALCULATIONS" forState:UIControlStateNormal];
            break;
        default:
            [btnTitle setTitle:@"" forState:UIControlStateNormal];
            break;
    }
    [btnTitle.titleLabel setFont:[UIFont fontWithName:@"Rockwell-Bold" size:12.0]];
    [btnTitle setContentHorizontalAlignment:UIControlContentHorizontalAlignmentCenter];
    [btnTitle setTag:section];
    [btnTitle addTarget:self action:@selector(btnTappedSection:) forControlEvents:UIControlEventTouchDown];
    [objView addSubview:btnTitle];
    
    /*
    UIImageView *imgSeperator = [[UIImageView alloc] init];
    [imgSeperator setImage:[UIImage imageNamed:@"img_SeperatorHorizotal.png"]];
    [imgSeperator setFrame:CGRectMake(0.0, 29.0, 320.0, 1.0)];
    [objView addSubview:imgSeperator];
    [imgSeperator release];
    */
    
    return objView;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 30.0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case 0:
            return 310.0;
            break;
        case 1:
            return 40.0;
            break;
        case 2:
            return 0.0;
            break;
        default:
            return 0.0;
            break;
    }
    return 0;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CustomCellIdentifier = @"CustomCellIdentifier";
    UITableViewCell *cell;
    
    /*
    CategoryMenuCell *cell = (CategoryMenuCell *)[tableView dequeueReusableCellWithIdentifier: CustomCellIdentifier];
    
    if(cell==nil || ![cell isKindOfClass:[CategoryMenuCell class]])
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CategoryMenuCell"
                                                     owner:self options:nil];
        for (id oneObject in nib) if ([oneObject isKindOfClass:[CategoryMenuCell class]])
            cell = (CategoryMenuCell *)oneObject;
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    Category *objCatTemp1 = [self.arrCategory objectAtIndex:indexPath.section];
    
    if(objCatTemp1.intType==1){
        BettingSites *objBettingSitesTmp = [objCatTemp1.arrSubCategory objectAtIndex:indexPath.row];
        cell.lblCategoryTitle.text = objBettingSitesTmp.strName;
    }
    else{
        Category *objCatTemp2 = [objCatTemp1.arrSubCategory objectAtIndex:indexPath.row];
        cell.lblCategoryTitle.text = objCatTemp2.strCategoryName;
    }
     */
    
    
    if(indexPath.section==0){
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CustomCellIdentifier];
        if (cell == nil) {
            cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CustomCellIdentifier] autorelease];
        }
        if(indexPath.row==0){
            objViewAddClient = [[[NSBundle mainBundle] loadNibNamed:@"AddClientView" owner:self options:nil]objectAtIndex:0];
            //[objViewAddClient setFrame:CGRectMake(0.0, 0.0, objViewAddClient.frame.size.width, objViewAddClient.frame.size.height)];
            [cell.contentView addSubview:objViewAddClient];
            [objViewAddClient setData:self appDelegate:appDelegate viewController:self isEditMode:bolIsEditMode ClientData:dictClient];
        }
        [cell setBackgroundColor:[UIColor clearColor]];
        return cell;
    }
    else{
        AppointmentListCell *cell = (AppointmentListCell *)[tableView dequeueReusableCellWithIdentifier: CustomCellIdentifier];
        
        if(cell==nil || ![cell isKindOfClass:[AppointmentListCell class]])
        {
            NSArray *nib;
            nib = [[NSBundle mainBundle] loadNibNamed:@"AppointmentListCell"
                                                owner:self options:nil];
            
            for (id oneObject in nib) if ([oneObject isKindOfClass:[AppointmentListCell class]])
                cell = (AppointmentListCell *)oneObject;
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        [cell setBackgroundColor:[UIColor clearColor]];
        
        cell.lblTitle.font=[UIFont fontWithName:@"Rockwell-Bold" size:14];
        
        if(indexPath.row==0){
            [cell.btnCell setHidden:TRUE];
            [cell.btnAddAppointment setHidden:TRUE];
            
            if(self.bolIsEditMode){
                cell.lblTitle.text = [dictClient objectForKey:@"client_name"];
            }
            else{
                cell.lblTitle.text = @"Add client...";
            }
            [cell.lblTitle setTextColor:[UIColor magentaColor]];
        }
        else if(indexPath.row==1){
            [cell.btnCell setHidden:TRUE];
            [cell.btnAddAppointment setHidden:FALSE];
            
            [cell.btnAddAppointment setImage:[UIImage imageNamed:@"ico_Plus.png"] forState:UIControlStateNormal];
            
            cell.lblTitle.text = @"APPOINTMENTS";
            [cell.lblTitle setTextColor:[UIColor grayColor]];
        }
        else if(indexPath.row==[self.arrAppointment count]+2){
            [cell.btnCell setHidden:FALSE];
            [cell.btnAddAppointment setHidden:TRUE];
            
            cell.lblTitle.text = @"Add appointment";
            [cell.lblTitle setTextColor:[UIColor magentaColor]];
        }
        else{
            [cell.btnCell setHidden:FALSE];
            [cell.btnAddAppointment setHidden:FALSE];
          
            [cell.btnAddAppointment setImage:[UIImage imageNamed:@"ico_Cross.png"] forState:UIControlStateNormal];
            
            NSDictionary *dictAppointment=[self.arrAppointment objectAtIndex:indexPath.row-2];
            //cell.lblTitle.text = [NSString stringWithFormat:@"%@", [dictAppointment objectForKey:@"appoin_date"]];            
            cell.lblTitle.text = [FunctionManager getFormatedDate:[dictAppointment objectForKey:@"appoin_date"] withDateFormat:g_DateTimeFormatDefault withDisplayFormat:g_DateFormatDisplay2];
            
            [cell.lblTitle setTextColor:[UIColor whiteColor]];
        }
        
        [cell.btnAddAppointment setTag:indexPath.row];
        [cell.btnAddAppointment addTarget:self action:@selector(btnTappedAddDeleteAppointment:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnCell setTag:indexPath.row];
        [cell.btnCell addTarget:self action:@selector(btnTappedAddUpdateAppointment:) forControlEvents:UIControlEventTouchUpInside];
        
        return cell;
    }
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    /*
    Category *objCatTemp1 = [self.arrCategory objectAtIndex:indexPath.section];
    
    switch (objCatTemp1.intType) {
        case 1:
        {
            BettingSites *objBettingSitesTmp = [objCatTemp1.arrSubCategory objectAtIndex:indexPath.row];
            
            SiteDetailViewController *objSiteDetailViewController;
            objSiteDetailViewController = [[[SiteDetailViewController alloc] initWithNibName:@"SiteDetailViewController" bundle:nil] autorelease];

//             if(g_IS_IPHONE_5_SCREEN)
//             objSiteDetailViewController = [[[SiteDetailViewController alloc] initWithNibName:@"SiteDetailViewController" bundle:nil] autorelease];
//             else
//             objSiteDetailViewController = [[[SiteDetailViewController alloc] initWithNibName:@"SiteDetailViewController4" bundle:nil] autorelease];

            objSiteDetailViewController.objBettingSites = objBettingSitesTmp;
            [self.navigationController pushViewController:objSiteDetailViewController animated:YES];
        }
            break;
        case 3:
        {
            Category *objCatTemp = [objCatTemp1.arrSubCategory objectAtIndex:indexPath.row];
            
            GeneralDetailViewController *objGeneralDetailViewController;
            objGeneralDetailViewController = [[[GeneralDetailViewController alloc] initWithNibName:@"GeneralDetailViewController" bundle:nil] autorelease];

//             if(g_IS_IPHONE_5_SCREEN)
//             objGeneralDetailViewController = [[[GeneralDetailViewController alloc] initWithNibName:@"GeneralDetailViewController" bundle:nil] autorelease];
//             else
//             objGeneralDetailViewController = [[[GeneralDetailViewController alloc] initWithNibName:@"GeneralDetailViewController4" bundle:nil] autorelease];

            objGeneralDetailViewController.objCategory = objCatTemp;
            [self.navigationController pushViewController:objGeneralDetailViewController animated:YES];
        }
            break;
        case 4:
        {
            Category *objCatTemp = [objCatTemp1.arrSubCategory objectAtIndex:indexPath.row];
            
            MoreInfoViewController *objMoreInfoViewController;
            objMoreInfoViewController = [[[MoreInfoViewController alloc] initWithNibName:@"MoreInfoViewController" bundle:nil] autorelease];

//             if(g_IS_IPHONE_5_SCREEN)
//             objMoreInfoViewController = [[[MoreInfoViewController alloc] initWithNibName:@"MoreInfoViewController" bundle:nil] autorelease];
//             else
//             objMoreInfoViewController = [[[MoreInfoViewController alloc] initWithNibName:@"MoreInfoViewController4" bundle:nil] autorelease];

            objMoreInfoViewController.intDisplayIndexNo = objCatTemp.intCategoryId;
            [self.navigationController pushViewController:objMoreInfoViewController animated:YES];
        }
            break;
    }
     */
}
#pragma mark Section Tapped
- (void)btnTappedSection:(UIButton*)btn {
    BOOL currentlyExpanded = [expandedSections containsIndex:btn.tag];
    if (currentlyExpanded)
    {
        [expandedSections removeIndex:btn.tag];
        [_tblClient reloadSections:[NSIndexSet indexSetWithIndex:btn.tag] withRowAnimation:UITableViewRowAnimationNone];
    }
    else
    {
        [expandedSections addIndex:btn.tag];
        [_tblClient reloadSections:[NSIndexSet indexSetWithIndex:btn.tag] withRowAnimation:UITableViewRowAnimationNone];
    }
}
#pragma mark - Add/Update/Delete Appointment
- (IBAction)btnTappedAddDeleteAppointment:(id)sender{
    //DLog(@"Clicked: %d", [sender tag]);
    
    if([sender tag]==1){
        //DLog(@"Add appointment");
        [self addAppointment];
    }
    else{
        //NSDictionary *dictAppointment=[self.arrAppointment objectAtIndex:[sender tag]-2];
        //DLog(@"Delete appointment: %@", [dictAppointment objectForKey:@"appoin_date"]);
        
        self.intAppointmentDeleteIndex = [sender tag]-2;
        [FunctionManager showMessageWithConfirm:@"" withMessage:msgRecordDeleteConfirm withTag:1 withDelegage:self];
    }
}
- (IBAction)btnTappedAddUpdateAppointment:(id)sender{
    //DLog(@"Clicked: %d", [sender tag]);
    
    if([sender tag]==[self.arrAppointment count]+2){
        //DLog(@"Add appointment");
        [self addAppointment];
    }
    else{
        NSDictionary *dictAppointment=[self.arrAppointment objectAtIndex:[sender tag]-2];
        //DLog(@"Update appointment: %@", [dictAppointment objectForKey:@"appoin_date"]);
        [self updateAppointment:dictAppointment];
    }
}
-(void)addAppointment{
    if([dictClient count]){
        int intClientId = [[dictClient objectForKey:@"client_id"] intValue];
        
        if(intClientId==0)
            [FunctionManager showMessage:nil withMessage:msgCAAddClient withDelegage:nil];
        else{
            AddAppointmentViewController *objAddAppointmentVC;
            if(g_IS_IPHONE_5_SCREEN)
                objAddAppointmentVC = [[[AddAppointmentViewController alloc] initWithNibName:@"AddAppointmentViewController" bundle:nil] autorelease];
            else
                objAddAppointmentVC = [[[AddAppointmentViewController alloc] initWithNibName:@"AddAppointmentViewController4" bundle:nil] autorelease];
            
            objAddAppointmentVC.bolIsEditMode = FALSE;
            objAddAppointmentVC.intClientId = [[dictClient objectForKey:@"client_id"] intValue];
            
            [self.navigationController pushViewController:objAddAppointmentVC animated:YES];
        }
    }
    else
        [FunctionManager showMessage:nil withMessage:msgCAAddClient withDelegage:nil];
}
-(void)updateAppointment:(NSDictionary *)pDictAppointment{
    AddAppointmentViewController *objAddAppointmentVC;
    if(g_IS_IPHONE_5_SCREEN)
        objAddAppointmentVC = [[[AddAppointmentViewController alloc] initWithNibName:@"AddAppointmentViewController" bundle:nil] autorelease];
    else
        objAddAppointmentVC = [[[AddAppointmentViewController alloc] initWithNibName:@"AddAppointmentViewController4" bundle:nil] autorelease];
    
    objAddAppointmentVC.bolIsEditMode = TRUE;
    objAddAppointmentVC.intClientId = [[dictClient objectForKey:@"client_id"] intValue];
    objAddAppointmentVC.dictAppointment = pDictAppointment;
    
    [self.navigationController pushViewController:objAddAppointmentVC animated:YES];
}

#pragma mark - Delete Appointment
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex==0)
        [self deleteAppointment];
}
-(void)deleteAppointment{
    NSDictionary *dictAppointment=[self.arrAppointment objectAtIndex:self.intAppointmentDeleteIndex];
    
    [FunctionManager displayLoadingView:self.view withMessage:msgLoadingGeneral appDelegate:appDelegate viewController:self];
    
    //http://webplanex.co.in/projects/donna_bella/iphone_api/calc_api.php?method=deleteAppoinment&id=1
    
    NSString *strURL = [NSString stringWithFormat:@"%@calc_api.php?",g_BaseUrl];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[strURL toURL]];
    [request setDelegate:self];
    [request setRequestMethod:@"POST"];  //GET
    [request setTimeOutSeconds:g_Default_Timeout_Seconds];
    [request setPostValue:@"json" forKey:@"format"];
    
    [request setPostValue:@"deleteAppoinment" forKey:@"method"];
    [request setPostValue:[NSString stringWithFormat:@"%d", [[dictAppointment objectForKey:@"appoinment_id"] intValue]] forKey:@"appoinment_id"];
    
    [request setDidFinishSelector:@selector(deleteAppointmentSuccess:)];
    [request setDidFailSelector:@selector(deleteAppointmentFailed:)];
    [request startAsynchronous];
}
#pragma mark Delete Appointment Response
- (void)deleteAppointmentSuccess:(ASIHTTPRequest *)request
{
    NSString *strResponse = [request responseString];
    SBJSON *objSBJSONParser = [[SBJSON alloc] init];
	NSDictionary *dictData = [objSBJSONParser objectWithString:strResponse error:nil];
	
    [FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
    
    int intStatus = [[dictData objectForKey:@"status"] intValue];
    
    if (intStatus==1){
        [FunctionManager showMessage:nil withMessage:msgRecordDeleteSuccess withDelegage:nil];
        
        [self.arrAppointment removeObjectAtIndex:self.intAppointmentDeleteIndex];
        [_tblClient reloadData];
    }
    else
        [FunctionManager showMessage:nil withMessage:msgRecordDeleteFail withDelegage:nil];
}
- (void)deleteAppointmentFailed:(ASIHTTPRequest *)request
{
	NSError *error = [request error];
	[FunctionManager hideLoadingView:self.view appDelegate:appDelegate viewController:self];
	[FunctionManager showMessage:nil withMessage:[error localizedDescription] withDelegage:nil];
}

#pragma mark - Go Back
-(IBAction)btnTappedBack:(id)sender{
    [FunctionManager gotoBack:self];
}
-(IBAction)btnTappedHome:(id)sender{
    [FunctionManager gotoRoot:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Orientations
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
	[self.strMessage release];
    
    if(self.arrAppointment.count>0)
        [self.arrAppointment removeAllObjects];
    [self.arrAppointment release];
    
    [_tblClient release];
    
    [super dealloc];
}

@end
