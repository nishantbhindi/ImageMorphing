	//
//  AddClientView.m
//  Donna Bella
//
//  Created by WebInfoways on 15/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import "AddClientView.h"
#import "AddClientViewController.h"

@implementation AddClientView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

#pragma mark - Set Parent
-(void)setData:(id)pID appDelegate:(AppDelegate*)pAppDelegate viewController:(UIViewController*)pViewController isEditMode:(BOOL)pBolEditMode ClientData:(NSDictionary*)pDicClient
{
    _parent = pID;
    _appDelegate = pAppDelegate;
    _parentController = pViewController;
    
    _bolIsEditMode = pBolEditMode;
    
    _lblAddress.font=[UIFont fontWithName:@"Rockwell-Bold" size:15];
    _lblPhone.font=[UIFont fontWithName:@"Rockwell-Bold" size:15];
    _lblMobile.font=[UIFont fontWithName:@"Rockwell-Bold" size:14];
    _lblEmail.font=[UIFont fontWithName:@"Rockwell-Bold" size:15];
    
    [_txtName setTextColor:[UIColor magentaColor]];
    
    _txtName.font=[UIFont fontWithName:@"Rockwell-Bold" size:14];
    _txtPhone.font=[UIFont fontWithName:@"Rockwell-Bold" size:14];
    _txtEmail.font=[UIFont fontWithName:@"Rockwell-Bold" size:14];
    _txtAddress.font=[UIFont fontWithName:@"Rockwell-Bold" size:14];
    
    [_btnEdit.titleLabel setFont:[UIFont fontWithName:@"Rockwell-Bold" size:15]];
    
    [self resignResponder];
    [self resetData];
    
    if(_bolIsEditMode){        
        _intClientId = [[pDicClient objectForKey:@"client_id"] intValue];
        _txtName.text = [pDicClient objectForKey:@"client_name"];
        _txtPhone.text = [pDicClient objectForKey:@"phone_no"];
        _txtEmail.text = [pDicClient objectForKey:@"email"];
        _txtAddress.text = [pDicClient objectForKey:@"address"];
    }
    else{
        _intClientId = 0;
    }
}
#pragma mark - UITextField delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if(textField==_txtName){
        if([_txtName.text isEqualToString:@"Add name"]){
            _txtName.text = @"";
        }
    }
    else if(textField==_txtPhone){
        if([_txtPhone.text isEqualToString:@"Add number"]){
            _txtPhone.text = @"";
        }
    }
    else if(textField==_txtEmail){
        if([_txtEmail.text isEqualToString:@"Add email"]){
            _txtEmail.text = @"";
        }
    }
    return YES;
}
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    if(textView==_txtAddress){
        if([_txtAddress.text isEqualToString:@"Add address"]){
            _txtAddress.text = @"";
        }
    }
    return YES;
}

#pragma mark - Save
-(BOOL)checkEnteredData{
	if([_txtName.text isEmptyString]){
		[FunctionManager showMessage:nil withMessage:msgACEnterName withDelegage:nil];
		return FALSE;
	}
    else if([_txtAddress.text isEmptyString]){
		[FunctionManager showMessage:nil withMessage:msgACEnterAddress withDelegage:nil];
		return FALSE;
	}
    else if([_txtPhone.text isEmptyString]){
		[FunctionManager showMessage:nil withMessage:msgACEnterPhone withDelegage:nil];
		return FALSE;
	}
    else if([_txtEmail.text isEmptyString]){
		[FunctionManager showMessage:nil withMessage:msgACEnterEmail withDelegage:nil];
		return FALSE;
	}
    else if(![_txtEmail.text isValidEmail]){
        [FunctionManager showMessage:@"" withMessage:msgGenEnterValidEmail withDelegage:nil];
		return FALSE;
	}
	else {
	}
	return TRUE;
}
-(IBAction)btnTappedSave:(id)sender{
    if([self checkEnteredData]){
        [self resignResponder];
        [self saveClientData];
    }
}
-(void)resignResponder{
	[_txtName resignFirstResponder];
    [_txtPhone resignFirstResponder];
    [_txtEmail resignFirstResponder];
    [_txtAddress resignFirstResponder];
}
-(void)resetData{
    _txtName.text = @"";
    _txtPhone.text = @"";
    _txtEmail.text = @"";
    _txtAddress.text = @"";
    
    _txtName.text = @"Add name";
    _txtPhone.text = @"Add number";
    _txtEmail.text = @"Add email";
    _txtAddress.text = @"Add address";
}
#pragma mark - Save Client Data
-(void)saveClientData{
    [FunctionManager displayLoadingView:self withMessage:msgLoadingGeneral appDelegate:_appDelegate viewController:_parentController];
    
    //http://webplanex.co.in/projects/donna_bella/iphone_api/calc_api.php?method=insertClient&user_id=1&client_name=testinsert&email=test@test.com&address=test&phone_no=1234567890
    
    //http://webplanex.co.in/projects/donna_bella/iphone_api/calc_api.php?method=updateClient&user_id=1&client_name=testinsert&email=test@test123.com&address=test&phone_no=1234567890&id=1
    
    NSString *strURL = [NSString stringWithFormat:@"%@calc_api.php?",g_BaseUrl];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[strURL toURL]];
    [request setDelegate:self];
    [request setRequestMethod:@"POST"];  //GET
    [request setTimeOutSeconds:g_Default_Timeout_Seconds];
    
    if(_bolIsEditMode){
        [request setPostValue:@"updateClient" forKey:@"method"];
        [request setPostValue:[NSString stringWithFormat:@"%d", _intClientId] forKey:@"client_id"];
    }
    else{
        [request setPostValue:@"insertClient" forKey:@"method"];
    }
    
    [request setPostValue:@"json" forKey:@"format"];
    [request setPostValue:[NSString stringWithFormat:@"%d", _appDelegate.objUser.intUserId] forKey:@"user_id"];
    
    [request setPostValue:_txtName.text forKey:@"client_name"];
    [request setPostValue:_txtEmail.text forKey:@"email"];
    [request setPostValue:_txtAddress.text forKey:@"address"];
    [request setPostValue:_txtPhone.text forKey:@"phone_no"];
    
    [request setDidFinishSelector:@selector(saveClientSuccess:)];
    [request setDidFailSelector:@selector(saveClientFailed:)];
    [request startAsynchronous];
}
#pragma mark Save Client Response
- (void)saveClientSuccess:(ASIHTTPRequest *)request
{
    NSString *strResponse = [request responseString];
    SBJSON *objSBJSONParser = [[SBJSON alloc] init];
	NSDictionary *dictData = [objSBJSONParser objectWithString:strResponse error:nil];
	
    [FunctionManager hideLoadingView:self appDelegate:_appDelegate viewController:_parentController];
    
    int intStatus = [[dictData objectForKey:@"status"] intValue];
    
    if (intStatus==1){
        if(_bolIsEditMode)
            [FunctionManager showMessage:nil withMessage:msgRecordUpdateSuccess withDelegage:nil];
        else
            [FunctionManager showMessage:nil withMessage:msgRecordAddSuccess withDelegage:nil];
        
        NSDictionary *updatedClientData = [NSDictionary dictionaryWithObjectsAndKeys:
                                           [NSString stringWithFormat:@"%d", _appDelegate.objUser.intUserId],@"user_id",
                                           [NSString stringWithFormat:@"%d", [[dictData objectForKey:@"data"] intValue]],@"client_id",
                                           _txtName.text,@"client_name",
                                           _txtEmail.text,@"email",
                                           _txtAddress.text,@"address",
                                           _txtPhone.text,@"phone_no",
                                       nil];
        
        [_parent setDictClient:updatedClientData];
        [_parent setBolIsEditMode:TRUE];
        [_parent reloadData];
    }
    else
        [FunctionManager showMessage:nil withMessage:msgRecordAddFail withDelegage:nil];

}
- (void)saveClientFailed:(ASIHTTPRequest *)request
{
	NSError *error = [request error];
	[FunctionManager hideLoadingView:self appDelegate:_appDelegate viewController:_parentController];
	[FunctionManager showMessage:nil withMessage:[error localizedDescription] withDelegage:nil];
}

#pragma mark - Delete Client
-(IBAction)btnTappedDelete:(id)sender{
    if(_bolIsEditMode)
        [FunctionManager showMessageWithConfirm:@"" withMessage:msgRecordDeleteConfirm withTag:1 withDelegage:self];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex==0)
        [self deleteClient];
}
-(void)deleteClient{
    if(_bolIsEditMode){
        [FunctionManager displayLoadingView:self withMessage:msgLoadingGeneral appDelegate:_appDelegate viewController:_parentController];
        
        //http://webplanex.co.in/projects/donna_bella/iphone_api/calc_api.php?method=deleteClient&client_id=1
        
        NSString *strURL = [NSString stringWithFormat:@"%@calc_api.php?",g_BaseUrl];
        ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[strURL toURL]];
        [request setDelegate:self];
        [request setRequestMethod:@"POST"];  //GET
        [request setTimeOutSeconds:g_Default_Timeout_Seconds];
        [request setPostValue:@"json" forKey:@"format"];
        
        [request setPostValue:@"deleteClient" forKey:@"method"];
        [request setPostValue:[NSString stringWithFormat:@"%d", _intClientId] forKey:@"client_id"];
        
        [request setDidFinishSelector:@selector(deleteClientSuccess:)];
        [request setDidFailSelector:@selector(deleteClientFailed:)];
        [request startAsynchronous];
    }
}
#pragma mark Delete Client Response
- (void)deleteClientSuccess:(ASIHTTPRequest *)request
{
    NSString *strResponse = [request responseString];
    SBJSON *objSBJSONParser = [[SBJSON alloc] init];
	NSDictionary *dictData = [objSBJSONParser objectWithString:strResponse error:nil];
	
    [FunctionManager hideLoadingView:self appDelegate:_appDelegate viewController:_parentController];
    
    int intStatus = [[dictData objectForKey:@"status"] intValue];
    
    if (intStatus==1){
        [FunctionManager showMessage:nil withMessage:msgRecordDeleteSuccess withDelegage:nil];
        [FunctionManager gotoBack:_parentController];
    }
    else
        [FunctionManager showMessage:nil withMessage:msgRecordDeleteFail withDelegage:nil];
}
- (void)deleteClientFailed:(ASIHTTPRequest *)request
{
	NSError *error = [request error];
	[FunctionManager hideLoadingView:self appDelegate:_appDelegate viewController:_parentController];
	[FunctionManager showMessage:nil withMessage:[error localizedDescription] withDelegage:nil];
}

#pragma mark - Call/Email Client
-(IBAction)btnTappedCall:(id)sender{
    if(![_txtPhone.text isEmptyString] && ![_txtPhone.text isEqualToString:@"Add number"]){
		[FunctionManager callNumber:_txtPhone.text];
	}
}
-(IBAction)btnTappedEmail:(id)sender{
    if(![_txtEmail.text isEmptyString] && ![_txtEmail.text isEqualToString:@"Add email"]){
        [FunctionManager sendEmail:@"" mailBody:@"" isBodyHTML:YES toRecipientList:[NSArray arrayWithObject:_txtEmail.text] ccRecipientList:nil bccRecipientList:nil withImage:nil imageType:@"" viewController:_parentController delegate:self];
    }
}
#pragma mark - Mail delegate
- (void)mailComposeController:(MFMailComposeViewController *)controller
          didFinishWithResult:(MFMailComposeResult)result
                        error:(NSError *)error
{
    switch (result) {
        case MFMailComposeResultCancelled:
            DLog(@"Cancelled");
            break;
        case MFMailComposeResultSaved:
            DLog(@"Saved");
            break;
        case MFMailComposeResultSent:
            DLog(@"Sent");
            break;
        case MFMailComposeResultFailed:
            DLog(@"Failed");
            break;
    }
    //[controller dismissModalViewControllerAnimated:YES];
    [controller dismissViewControllerAnimated:YES completion:nil];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc {
    [_lblAddress release];
    [_lblPhone release];
    [_lblMobile release];
    [_lblEmail release];
    
    [_txtName release];
    [_txtPhone release];
    [_txtEmail release];
    [_txtAddress release];
    
    [_btnEdit release];
    
    [super dealloc];
}

@end
