//
//  AddClientViewController.h
//  Donna Bella
//
//  Created by WebInfoways on 13/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddClientView.h"
#import "AppointmentListCell.h"

#import "AddAppointmentViewController.h"

@class AppDelegate;

@interface AddClientViewController : UIViewController {
    AppDelegate *appDelegate;
	
    NSMutableIndexSet *expandedSections;
    
	int intSuccess;
	NSString *strMessage;
    
    AddClientView *objViewAddClient;
}
@property(nonatomic) BOOL bolIsEditMode;
@property(nonatomic,retain) NSDictionary *dictClient;
@property(nonatomic,retain) NSMutableArray *arrAppointment;

@property(nonatomic) int intAppointmentDeleteIndex;

@property(nonatomic) int intSuccess;
@property(nonatomic,retain) NSString *strMessage;

@property(nonatomic,retain) IBOutlet UITableView *tblClient;

-(void)setInitialParameter;
-(void)resetData;
-(void)reloadData;

-(void)fetchClientDetail;

-(void)addAppointment;
-(void)updateAppointment:(NSDictionary *)pDictAppointment;

-(void)deleteAppointment;

-(IBAction)btnTappedBack:(id)sender;
-(IBAction)btnTappedHome:(id)sender;

@end
