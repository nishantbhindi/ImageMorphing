//
//  ClientTrackerViewController.h
//  Donna Bella
//
//  Created by WebInfoways on 13/02/14.
//  Copyright (c) 2014 Nishant. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "User.h"
#import "ClientListCell.h"

#import "AddClientViewController.h"

@class AppDelegate;

@interface ClientTrackerViewController : UIViewController {
    AppDelegate *appDelegate;
	
	int intSuccess;
	NSString *strMessage;
    
    BOOL bolIsSearched;
}
@property(nonatomic) int intSuccess;
@property(nonatomic,retain) NSString *strMessage;
@property(nonatomic) BOOL bolIsSearched;

@property(nonatomic,retain) NSMutableArray *arrClientList;
@property(nonatomic,retain) NSMutableArray *arrClientListSearched;
@property(nonatomic,retain) IBOutlet UITableView *tblClientList;

@property(nonatomic,retain) IBOutlet UITextField *txtSearch;

-(void)setInitialParameter;
-(void)resetData;

-(void)fetchClientList;
-(void)openClientProfile:(NSDictionary *)pDictClient;

- (IBAction)btnTappedAddClient:(id)sender;
-(void)addClient;

-(BOOL)checkEnteredData;
-(IBAction)btnTappedSearch:(id)sender;
-(void)resignResponder;
-(void)searchClient:(NSString*)searchText;

-(IBAction)btnTappedBack:(id)sender;

@end
