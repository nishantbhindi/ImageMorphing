//
//  AppDelegate.m
//  PhotoShare
//
//  Created by WebInfoways on 26/02/14.
//  Copyright (c) 2014 Test. All rights reserved.
//

#import "AppDelegate.h"

#import "MainViewController.h"

@implementation AppDelegate

- (void)dealloc
{   
    [_viewController release];
    [_navController release];
    
    [_window release];
    
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    //self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    
    // Override point for customization after application launch.
    [self initializeAppData];           //initialize app data
    [self checkDeviceCompatibility];    //device compatibility
    
    //self.window.rootViewController = self.viewController;
    self.window.rootViewController = self.navController;
    [self.window makeKeyAndVisible];
    
    return YES;
}
#pragma mark - Initialize App Data
-(void)initializeAppData{
}
#pragma mark - Check Device Compatibility
-(void)checkDeviceCompatibility{
    /*NSLog(@"Device: %@", [[UIDevice currentDevice] model]);
     NSLog(@"Retina Support: %d", [FunctionManager isRetinaSupport]);
     NSLog(@"App Name: %@", g_APP_NAME);*/
    
    _viewController = [[[MainViewController alloc] initWithNibName:@"MainViewController" bundle:nil] autorelease];
    
    /*
    if(g_IS_IPHONE_5_SCREEN)
    {
        _viewController = [[[MainViewController alloc] initWithNibName:@"MainViewController" bundle:nil] autorelease];
        
//        if(g_IS_IPHONE)
//            NSLog(@"Hey, this is an iPhone 5 screen!");
//        else if(g_IS_IPOD)
//            NSLog(@"Hey, this is an iPod 5 screen!");
//        else
//            NSLog(@"Hey, this is a simulator screen with iPhone 5 screen height!");
    }
    else if(g_IS_IPHONE_4_SCREEN)
    {
        _viewController = [[[MainViewController alloc] initWithNibName:@"MainViewController4" bundle:nil] autorelease];
        
//        if(g_IS_IPHONE)
//            NSLog(@"Hey, this is a lower iPhone screen than 5!");
//        else if(g_IS_IPOD)
//            NSLog(@"Hey, this is a lower iPod screen than 5!");
//        else
//            NSLog(@"Hey, this is a lower simulator screen than 5!");
    }
    else if(g_IS_IPAD){
        _viewController = [[[MainViewController alloc] initWithNibName:@"MainViewControlleriPad" bundle:nil] autorelease];
        //NSLog(@"Hey, this is an iPad screen!");
    }
    else{
        _viewController = [[[MainViewController alloc] initWithNibName:@"MainViewController4" bundle:nil] autorelease];
        //NSLog(@"Hey, this is an ipad simulator screen!");
    }
     */
    
    ////Add Landing Page////
	UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:_viewController];
	[nc setNavigationBarHidden:TRUE];
	self.navController = nc;
	[nc release];
    ////Add Landing Page End////
    
    ////OS Version Checked////
    /*
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"6.0") && SYSTEM_VERSION_LESS_THAN(@"7.0")) {
            NSLog(@"iOS 6.0.1");
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"5.1.1") && SYSTEM_VERSION_LESS_THAN(@"6.0")) {
        NSLog(@"iOS 5.1.1");
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"5.0") && SYSTEM_VERSION_LESS_THAN(@"5.1.1")) {
        NSLog(@"iOS 5.1.1");
    }*/
    ////OS Version Checked////
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
