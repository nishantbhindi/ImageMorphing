//Camera
#define msgNoCameraAvailable    @"Camera is not available in this device."

//Image Save to PhotoAlbum
#define msgImgSavedToAlbum      @"Photo has been saved to album successfully."

//Calling
#define msgCallNotSupport       @"Calling is not supported in this device."

//Not Proper URL
#define msgURLInvalidToOpen     @"This URL format is not valid."

//---------------PROJECT WISE---------------//

//Share
#define g_AppName                   @"<App Name>"
#define g_AppUrl                    @"<App Url>"

//
#define msgShareTitle               @"<App Name>"
#define msgShareContent             @"Hey, \nI have customised my photo from the app '<App Name>'. \nIt's Amazing. \n\nThank you."
