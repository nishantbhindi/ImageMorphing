#import <Foundation/Foundation.h>
#import <AssetsLibrary/ALAsset.h>

@class AppDelegate;

@interface FunctionManager : NSObject

// Device Functions
+(BOOL)isRetinaSupport;
+(BOOL)isIOS5;
+(BOOL)isSimulator;

// UIAlertView Functions
+(void)showMessage:(NSString *)pstrTitle withMessage:(NSString *)pstrMsg withDelegage:(id)pIDDelegate;
+(void)showMessageWithConfirm:(NSString *)pstrTitle withMessage:(NSString *)pstrMsg withTag:(NSInteger)pintTag withDelegage:(id)pIDDelegate;
+(void)showMessageWithButtons:(NSString *)pstrTitle withMessage:(NSString *)pstrMsg withOtherButtons:(NSString *)pstrBtns withTag:(NSInteger)pintTag withDelegage:(id)pIDDelegate;

// UIActionSheet Functions
+(void)showActionSheet:(NSString *)pstrTitle withCancelTitle:(NSString *)pstrTitleCancel withDestructiveTitle:(NSString *)pstrTitleDestructive  withOtherButtonTitles:(NSString *)pstrOtherButtonTitles withDelegage:(id)pIDDelegate withViewController:(UIViewController*)pViewController withTag:(NSInteger)pintTag;

// NSUserDefault Functions
+(void)addToNSUserDefaults:(id)pobjValue forKey:(NSString *)pstrKey;
+(void)addArrayToNSUserDefaults:(id)pObject forKey:(NSString*)pForKey;
+(id)fetchFromNSUserDefaults:(NSString *)pstrKey;
+(void)removeFromNSUserDefaults:(NSString *)pstrKey;

// Camera Availability Functions
+(BOOL)isCameraDeviceAvailable;
+(BOOL)isFrontCameraDeviceAvailable;
+(BOOL)isRearCameraDeviceAvailable;
+(UIImagePickerControllerCameraDevice)getAvailableCameraFront;
+(UIImagePickerControllerCameraDevice)getAvailableCameraRear;

// Calling Functions
+(void)callNumber:(NSString *)pstrContactNo;

// Email Functions
+(void)sendEmail:(NSString *)pstrSubject mailBody:(NSString *)pstrMailBody isBodyHTML:(BOOL)pbolIsBodyHTML toRecipientList:(NSArray *)toRecipientsEmails ccRecipientList:(NSArray *)ccRecipientsEmails bccRecipientList:(NSArray *)bccRecipientsEmails withImage:(UIImage*)pImage imageType:(NSString*)pstrImageType viewController:(UIViewController*)pViewController delegate:(id)pIDDelegate;

// SMS Functions
+(void)sendSMS:(NSString *)pstrSMSBody toRecipientList:(NSArray *)toRecipients withImage:(UIImage*)pImage imageType:(NSString*)pstrImageType viewController:(UIViewController*)pViewController delegate:(id)pIDDelegate;
+(void)performSMS:(id)pObject withViewController:(UIViewController*)pViewController;

// UIWebView Functions
+(void)stopWebViewBounce:(UIWebView *)pobjWebView;
+(void)openUrlinApp:(UIWebView *)pobjWebView withStringUrl:(NSString *)pstrUrl;
+(void)webviewFailToLoad:(UIWebView *)pobjWebView withError:(NSError *)error;

// Open Url in Safari
+(void)openUrlinSafari:(UIWebView *)pobjWebView withStringUrl:(NSString *)pstrUrl;

// Image Functions
+(UIImage *)imageScaleAndCropToMaxSize:(UIImage *)pImage withSize:(CGSize)pNewSize;
+(UIImage *)imageScaleAndCropWithFixWidth:(UIImage *)pImage withWidth:(CGFloat)pfltWidth;
+(UIImage *)imageWithImage:(UIImage *)pImage scaledToSize:(CGSize)psizNewSize;
+(void)setImageCorner:(UIImageView *)pImgView radius:(float)pfltRadios;
+(void)setImageBorder:(UIImageView *)pImgView width:(float)pfltWidth color:(UIColor *)pColor;

// View Up/Down
+(void)scrollViewUp:(float)pUpvalue withDuration:(float)pDuration withView:(UIView *)pView;
+(void)scrollViewDown:(float)pDownvalue withDuration:(float)pDuration withView:(UIView *)pView;

// Remove All SubViews
+(void)removeAllSubViews:(id)pObj;

// Go Back
+(void)gotoBack:(UIViewController*)pViewController;
+(void)gotoRoot:(UIViewController*)pViewController;
+(void)gotoBackWithIndex:(UIViewController*)pViewController withIndexNo:(int)pintIndexNo;

// Push-Pop
+(void)pushWithAnimation:(UIViewController*)pViewController withPushController:(UIViewController*)pPushViewController withAnimationNo:(int)pintAnimationNo;
+(void)popWithAnimation:(UIViewController*)pViewController withAnimationNo:(int)pintAnimationNo;

// Add Gesture
+(void)addGesture:(UIViewController*)pViewController;

// Remove Inner Shadhow of Popover
+ (void)removeInnerShadowOfPopover;

@end
