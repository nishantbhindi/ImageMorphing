#import "FunctionManager.h"

@implementation FunctionManager

#pragma mark -
#pragma mark Device Functions
+(BOOL)isRetinaSupport{
    if([[UIScreen mainScreen] respondsToSelector:@selector(scale)])
        return [[UIScreen mainScreen] scale] == 2.0 ? YES : NO;
    
    return NO;
}
+(BOOL)isIOS5
{
    NSString *strOS5 = @"5.0";
    NSString *strCurrSysVer = [[UIDevice currentDevice] systemVersion];
    
    //strCurrSysVer = @"5.0.1";
    if ([strCurrSysVer compare:strOS5 options:NSNumericSearch] == NSOrderedAscending) //lower than 4
    {
        return NO;
    }
    else if ([strCurrSysVer compare:strOS5 options:NSNumericSearch] == NSOrderedDescending) //5.0.1 and above
    {
        return YES;
    }
    else //IOS 5
    {
        return YES;
    }
    
    return NO;
}
+(BOOL)isSimulator
{
	NSString *strDeviceType = [UIDevice currentDevice].model;
	BOOL myBool = !([strDeviceType rangeOfString:@"Simulator"].location == NSNotFound);
	return myBool;
}

#pragma mark - UIAlertView Functions
+(void)showMessage:(NSString *)pstrTitle withMessage:(NSString *)pstrMsg withDelegage:(id)pIDDelegate{
    /*UIAlertView *objAlertMsg = [[UIAlertView alloc] initWithTitle:pstrTitle
                                                           message:pstrMsg
                                                          delegate:pIDDelegate
                                                 cancelButtonTitle:@"OK"
                                                 otherButtonTitles:nil];*/
    
    UIAlertView *objAlertMsg = [[UIAlertView alloc] initWithTitle:@""
                                                          message:pstrMsg
                                                         delegate:pIDDelegate
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
    
    [objAlertMsg show];
    [objAlertMsg release];
}
+(void)showMessageWithConfirm:(NSString *)pstrTitle withMessage:(NSString *)pstrMsg withTag:(NSInteger)pintTag withDelegage:(id)pIDDelegate{
    UIAlertView *objAlertMsg = [[UIAlertView alloc] initWithTitle:pstrTitle
                                                           message:pstrMsg
                                                          delegate:pIDDelegate
                                                 cancelButtonTitle:nil
                                                 otherButtonTitles:@"Yes",@"No",nil];
    objAlertMsg.tag = pintTag;
    [objAlertMsg show];
    [objAlertMsg release];
}
+(void)showMessageWithButtons:(NSString *)pstrTitle withMessage:(NSString *)pstrMsg withOtherButtons:(NSString *)pstrBtns withTag:(NSInteger)pintTag withDelegage:(id)pIDDelegate{
    UIAlertView *objAlertMsg = [[UIAlertView alloc] initWithTitle:pstrTitle
                                                           message:pstrMsg
                                                          delegate:pIDDelegate
                                                 cancelButtonTitle:@"Cancel"
                                                 otherButtonTitles:nil];
    
    NSArray *arrBtns = [pstrBtns componentsSeparatedByString:@","];
    for(int i=0;i<[arrBtns count];i++)
        [objAlertMsg addButtonWithTitle:[arrBtns objectAtIndex:i]];
    
    objAlertMsg.tag = pintTag;
    [objAlertMsg show];
    [objAlertMsg release];
}

#pragma mark - UIAlertView Functions
+(void)showActionSheet:(NSString *)pstrTitle withCancelTitle:(NSString *)pstrTitleCancel withDestructiveTitle:(NSString *)pstrTitleDestructive  withOtherButtonTitles:(NSString *)pstrOtherButtonTitles withDelegage:(id)pIDDelegate withViewController:(UIViewController*)pViewController withTag:(NSInteger)pintTag{
    
    UIActionSheet *objActionSheet = [[UIActionSheet alloc]
                            initWithTitle:pstrTitle
                            delegate:pIDDelegate
                            cancelButtonTitle:nil
                            destructiveButtonTitle:nil
                            otherButtonTitles:nil];
    objActionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    objActionSheet.tag = pintTag;
    
	NSArray *arrButtonTitles = [pstrOtherButtonTitles componentsSeparatedByString:@","];
    for(int i=0; i<[arrButtonTitles count]; i++)
        [objActionSheet addButtonWithTitle:[arrButtonTitles objectAtIndex:i]];
    
	
	[objActionSheet addButtonWithTitle:pstrTitleCancel];
	objActionSheet.cancelButtonIndex = objActionSheet.numberOfButtons-1;
    
	[objActionSheet showInView:pViewController.view];
	[objActionSheet release];
    
    /*
    UIActionSheet *objActionSheet = [[[UIActionSheet alloc] init] autorelease];
    objActionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    objActionSheet.delegate = pIDDelegate;
    objActionSheet.title = pstrTitle;
    objActionSheet.cancelButtonIndex = [objActionSheet addButtonWithTitle:pstrTitleCancel];
    objActionSheet.destructiveButtonIndex = [objActionSheet addButtonWithTitle:pstrTitleDestructive];
    
    NSArray *arrButtonTitles = [pstrOtherButtonTitles componentsSeparatedByString:@","];
    for(int i=0; i<[arrButtonTitles count]; i++)
        [objActionSheet addButtonWithTitle:[arrButtonTitles objectAtIndex:i]];

    [objActionSheet showInView:pViewController.view];
     */
}

#pragma mark - NSUserDefault Functions
+(void)addToNSUserDefaults:(id)pobjValue forKey:(NSString *)pstrKey{
    NSUserDefaults *objUserDefaults = [NSUserDefaults standardUserDefaults];
    [objUserDefaults setObject:pobjValue forKey:pstrKey];
    [objUserDefaults synchronize];
}
+(void)addArrayToNSUserDefaults:(id)pObject forKey:(NSString*)pForKey{
	NSUserDefaults *defaults =[NSUserDefaults standardUserDefaults];
	[defaults setObject:[NSKeyedArchiver archivedDataWithRootObject:pObject] forKey:pForKey];
	[defaults synchronize];
}
+(id)fetchFromNSUserDefaults:(NSString *)pstrKey{
    NSUserDefaults *objUserDefaults = [NSUserDefaults standardUserDefaults];
    return [objUserDefaults objectForKey:pstrKey];
}
+(void)removeFromNSUserDefaults:(NSString *)pstrKey{
    NSUserDefaults *objUserDefaults = [NSUserDefaults standardUserDefaults];
    [objUserDefaults removeObjectForKey:pstrKey];
    [objUserDefaults synchronize];
}

#pragma mark - Camera Availability Functions
+(BOOL)isCameraDeviceAvailable
{
	BOOL bolCameraAvailable=NO;
	if([UIImagePickerController	isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
	{
		if([UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceFront] || [UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear])
			bolCameraAvailable = YES;
	}
	return bolCameraAvailable;
}
+(BOOL)isFrontCameraDeviceAvailable
{
	BOOL bolCameraAvailable=NO;
	if([UIImagePickerController	isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
	{
		if([UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceFront])
			bolCameraAvailable = YES;
	}
	return bolCameraAvailable;
}
+(BOOL)isRearCameraDeviceAvailable
{
	BOOL bolCameraAvailable=NO;
	if([UIImagePickerController	isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
	{
		if([UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear])
			bolCameraAvailable = YES;
	}
	return bolCameraAvailable;
}
+(UIImagePickerControllerCameraDevice)getAvailableCameraFront
{
	UIImagePickerControllerCameraDevice availableDevice = NSNotFound;
	
	if([UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceFront])
		availableDevice = UIImagePickerControllerCameraDeviceFront;
	
	return availableDevice;
}
+(UIImagePickerControllerCameraDevice)getAvailableCameraRear
{
	UIImagePickerControllerCameraDevice availableDevice = NSNotFound;
	
	if([UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear])
		availableDevice = UIImagePickerControllerCameraDeviceRear;
	
	return availableDevice;
}

#pragma mark - Calling Functions
+(void)callNumber:(NSString *)pstrContactNo
{
	NSString *strDeviceModel = [UIDevice currentDevice].model;
	if(![strDeviceModel isEqualToString:@"iPhone"])
	{
		/*NSString *strMessage = [NSString stringWithFormat:@"%@ 'tel:%@' %@",msgCallTitle,pstrContactNo,msgCallMessage];
        [self showMessage:nil withMessage:strMessage withDelegage:nil];*/
        [self showMessage:nil withMessage:msgCallNotSupport withDelegage:nil];
	}
	else
	{
		//pstrContactNo = [NSString stringWithFormat:@"tel://%@",pstrContactNo];
        pstrContactNo = [NSString stringWithFormat:@"tel:%@",pstrContactNo];
		NSString *strDialedContact = [pstrContactNo stringByReplacingOccurrencesOfString:@" " withString:@""];
		[[UIApplication sharedApplication] openURL:[NSURL URLWithString:strDialedContact]];
	}
}

#pragma mark - Email Functions
+(void)sendEmail:(NSString *)pstrSubject mailBody:(NSString *)pstrMailBody isBodyHTML:(BOOL)pbolIsBodyHTML toRecipientList:(NSArray *)toRecipientsEmails ccRecipientList:(NSArray *)ccRecipientsEmails bccRecipientList:(NSArray *)bccRecipientsEmails withImage:(UIImage*)pImage imageType:(NSString*)pstrImageType viewController:(UIViewController*)pViewController delegate:(id)pIDDelegate
{
	//----Add delegate in respective controller for dismiss----//
	
	BOOL bolCanSendMail = TRUE;
	
	Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
	if (mailClass != nil)
	{
		// We must always check whether the current device is configured for sending emails
		if ([mailClass canSendMail])
		{
			MFMailComposeViewController *objMailPicker = [[MFMailComposeViewController alloc] init];
			objMailPicker.mailComposeDelegate = pIDDelegate;
			[objMailPicker.navigationBar setTintColor:[UIColor blackColor]];
			
			[objMailPicker setSubject:pstrSubject];
			[objMailPicker setMessageBody:pstrMailBody isHTML:pbolIsBodyHTML];
			
			if([toRecipientsEmails count]>0)
				[objMailPicker setToRecipients:toRecipientsEmails];
			if([ccRecipientsEmails count]>0)
				[objMailPicker setCcRecipients:ccRecipientsEmails];
			if([bccRecipientsEmails count]>0)
				[objMailPicker setBccRecipients:bccRecipientsEmails];
			
			//Attach an image to the email
			if(pImage){
				if([pstrImageType isEqualToString:@"png"]){
					NSData *imageData = UIImagePNGRepresentation(pImage);
					[objMailPicker addAttachmentData:imageData mimeType:@"image/png" fileName:@"MyImage"];
				}
				else if([pstrImageType isEqualToString:@"jpg"]){
					NSData *imageData = UIImageJPEGRepresentation(pImage, 1.0);
					[objMailPicker addAttachmentData:imageData mimeType:@"image/jpg" fileName:@"MyImage"];
				}
			}
			
			
			//[self.navController presentModalViewController:objMailPicker animated:YES];			//if passing argument (UINavigationController *)
			//[self.tabBarController presentModalViewController:objMailPicker animated:YES];		//if passing argument (UITabBarController *)
			//[pViewController presentModalViewController:objMailPicker animated:YES];
            [pViewController presentViewController:objMailPicker animated:YES completion:nil];
			[objMailPicker release];
		}
		else
		{
			bolCanSendMail = FALSE;
		}
	}
	else
	{
		bolCanSendMail = FALSE;
	}
	
	
	if(!bolCanSendMail)
	{
		NSString *strToEmail = @"";
		if([toRecipientsEmails count]>0)
			strToEmail = [toRecipientsEmails objectAtIndex:0];
		
		NSString *strMailString = [NSString stringWithFormat:@"mailto:?to=%@&subject=%@&body=%@",
								   [strToEmail stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding],
								   [pstrSubject stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding],
								   [pstrMailBody  stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]];
		
		[[UIApplication sharedApplication] openURL:[NSURL URLWithString:strMailString]];
	}
}

#pragma mark - SMS Functions
+(void)sendSMS:(NSString *)pstrSMSBody toRecipientList:(NSArray *)toRecipients withImage:(UIImage*)pImage imageType:(NSString*)pstrImageType viewController:(UIViewController*)pViewController delegate:(id)pIDDelegate
{
	//----Add delegate in respective controller for dismiss----//
	
	MFMessageComposeViewController *objMessageController = [[[MFMessageComposeViewController alloc] init] autorelease];
    if([MFMessageComposeViewController canSendText])
    {
        objMessageController.body = pstrSMSBody;
        objMessageController.messageComposeDelegate = pIDDelegate;
		
		if([toRecipients count]>0)
			objMessageController.recipients = toRecipients;
		
		//[pViewController presentModalViewController:objMessageController animated:YES];
        [pViewController presentViewController:objMessageController animated:YES completion:nil];
		//[self performSelector:@selector(performSMS:withViewController:) withObject:objMessageController withObject:pViewController afterDelay:0.1];
    }
}
+(void)performSMS:(id)pObject withViewController:(UIViewController*)pViewController
{
	MFMessageComposeViewController *objMessageController = (MFMessageComposeViewController *)pObject;
	//[pViewController presentModalViewController:objMessageController animated:YES];
    [pViewController presentViewController:objMessageController animated:YES completion:nil];
}

#pragma mark - UIWebView Functions
+(void)stopWebViewBounce:(UIWebView *)pobjWebView
{
	[pobjWebView setOpaque:NO];
	pobjWebView.backgroundColor = [UIColor clearColor];
	
	for (id subview in pobjWebView.subviews)
        if ([[subview class] isSubclassOfClass: [UIScrollView class]])
            ((UIScrollView *)subview).bounces = NO;
}
+(void)openUrlinApp:(UIWebView *)pobjWebView withStringUrl:(NSString *)pstrUrl
{
    [pobjWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:pstrUrl]]];
}
+(void)webviewFailToLoad:(UIWebView *)pobjWebView withError:(NSError *)error
{
	if ([error code] == -999) {
	}
	else if([error code] == -1009 || [[error localizedDescription] isEqualToString:@"no Internet connection"]){
		[pobjWebView loadHTMLString:@"<body><br><font size=5 color=red>No Internet Connection!<br>Internet access is required to use this application. If this problem persists, please check your network settings.</font></body>" baseURL:nil];
	}
	else if([error code] == -1001 || [[error localizedDescription] isEqualToString:@"timed out"]){
		[pobjWebView loadHTMLString:@"<body><br><font size=5 color=red>Request Timed Out.</font></body>" baseURL:nil];
	}else if([error code] == -1004 || [[error localizedDescription] isEqualToString:@"can’t connect to host"]){
		[pobjWebView loadHTMLString:@"<body><br><font size=5 color=red>Can’t connect to host.</font></body>" baseURL:nil];
	}
	else if (error != NULL) {
		[pobjWebView loadHTMLString:@"<body><br><font size=5 color=red>Error loading page, Please try again later.</font></body>" baseURL:nil];
    }
	else{
	}
}
#pragma mark Open Url in Safari
+(void)openUrlinSafari:(UIWebView *)pobjWebView withStringUrl:(NSString *)pstrUrl
{
    if (![[UIApplication sharedApplication] openURL:[NSURL URLWithString:pstrUrl]])
    {
        // there was an error trying to open the URL.
        [self showMessage:nil withMessage:msgURLInvalidToOpen withDelegage:nil];
    }
}

#pragma mark - Image Functions
+(UIImage *)imageScaleAndCropToMaxSize:(UIImage *)pImage withSize:(CGSize)pNewSize
{
	CGFloat largestSize = (pNewSize.width > pNewSize.height) ? pNewSize.width : pNewSize.height;
	CGSize imageSize = [pImage size];
	
	// Scale the image while mainting the aspect and making sure the
	// the scaled image is not smaller then the given new size. In
	// other words we calculate the aspect ratio using the largest
	// dimension from the new size and the small dimension from the
	// actual size.
	CGFloat ratio;
	if (imageSize.width > imageSize.height)
		ratio = largestSize / imageSize.height;
	else
		ratio = largestSize / imageSize.width;
	
	CGRect rect = CGRectMake(0.0, 0.0, ratio * imageSize.width, ratio * imageSize.height);
	UIGraphicsBeginImageContext(rect.size);
	[pImage drawInRect:rect];
	UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
	
	// Crop the image to the requested new size maintaining
	// the inner most parts of the image.
	CGFloat offsetX = 0;
	CGFloat offsetY = 0;
	imageSize = [scaledImage size];
	if (imageSize.width < imageSize.height)
		offsetY = (imageSize.height / 2) - (imageSize.width / 2);
	else
		offsetX = (imageSize.width / 2) - (imageSize.height / 2);
	
	CGRect cropRect = CGRectMake(offsetX, offsetY, imageSize.width - (offsetX * 2), imageSize.height - (offsetY * 2));
	
	CGImageRef croppedImageRef = CGImageCreateWithImageInRect([scaledImage CGImage], cropRect);
	UIImage *newImage = [UIImage imageWithCGImage:croppedImageRef];
	CGImageRelease(croppedImageRef);
	
	return newImage;
}
+(UIImage *)imageScaleAndCropWithFixWidth:(UIImage *)pImage withWidth:(CGFloat)pfltWidth
{
	CGFloat largestSize = pfltWidth;
	CGSize imageSize = [pImage size];
	
	// Scale the image while mainting the aspect and making sure the
	// the scaled image is not smaller then the given new size. In
	// other words we calculate the aspect ratio using the largest
	// dimension from the new size and the small dimension from the
	// actual size.
	CGFloat ratio;
    
    if (imageSize.width>largestSize)
        ratio = largestSize / imageSize.width;
	else
        ratio=1;
    
	CGRect rect = CGRectMake(0.0, 0.0, ratio * imageSize.width, ratio * imageSize.height);
	UIGraphicsBeginImageContext(rect.size);
	[pImage drawInRect:rect];
	UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
	
	// Crop the image to the requested new size maintaining
	// the inner most parts of the image.
	CGFloat offsetX = 0;
	CGFloat offsetY = 0;
	imageSize = [scaledImage size];
	
	CGRect cropRect = CGRectMake(offsetX, offsetY, imageSize.width - (offsetX * 2), imageSize.height - (offsetY * 2));
	
	CGImageRef croppedImageRef = CGImageCreateWithImageInRect([scaledImage CGImage], cropRect);
	UIImage *newImage = [UIImage imageWithCGImage:croppedImageRef];
	CGImageRelease(croppedImageRef);
	
	return newImage;
}
+(UIImage *)imageWithImage:(UIImage *)pImage scaledToSize:(CGSize)psizNewSize
{
	// Create a graphics image context
    UIGraphicsBeginImageContext(psizNewSize);
	// Tell the old image to draw in this new context, with the desired
    // new size
    [pImage drawInRect:CGRectMake(0, 0, psizNewSize.width, psizNewSize.height)];
	// Get the new image from the context
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
	// End the context
    UIGraphicsEndImageContext();
	// Return the new image.
    return newImage;
}
+(void)setImageCorner:(UIImageView *)pImgView radius:(float)pfltRadios
{
	pImgView.layer.masksToBounds = YES;
	pImgView.layer.cornerRadius = pfltRadios;
}
+(void)setImageBorder:(UIImageView *)pImgView width:(float)pfltWidth color:(UIColor *)pColor
{
    [pImgView.layer setBorderColor: [pColor CGColor]];
    [pImgView.layer setBorderWidth: pfltWidth];
}

#pragma mark - Show Hide label on record count.
+(void)checkRecordAvailable:(NSMutableArray *)pArrTemp withTable:(UITableView *)pTblTemp withLabel:(UILabel *)pLabel
{
	if(pArrTemp.count > 0)
		pLabel.hidden = YES;
	else
		pLabel.hidden = NO;
	
	[pTblTemp reloadData];
}

#pragma mark - View Up/Down according to text input
+(void)scrollViewUp:(float)pUpvalue withDuration:(float)pDuration withView:(UIView *)pView
{
	[UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:pDuration];
	CGRect rect = pView.frame;
    rect.origin.y -= pUpvalue;
    pView.frame = rect;
    [UIView commitAnimations];
}
+(void)scrollViewDown:(float)pDownvalue withDuration:(float)pDuration withView:(UIView *)pView
{
	[UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:pDuration];
	CGRect rect = pView.frame;
    rect.origin.y += pDownvalue;
    pView.frame = rect;
    [UIView commitAnimations];
}

#pragma mark - Remove All SubViews
+(void)removeAllSubViews:(id)pObj
{
	NSArray *Array = [pObj subviews];
	for(int index = 0; index < [Array count]; index++)
	{
		[[Array objectAtIndex:index] removeFromSuperview];
	}
}

#pragma mark - Go Back Button Tap events
+(void)gotoBack:(UIViewController*)pViewController
{
	[pViewController.navigationController popViewControllerAnimated:YES];
}
+(void)gotoRoot:(UIViewController*)pViewController
{
	[pViewController.navigationController popToRootViewControllerAnimated:YES];
}
+(void)gotoBackWithIndex:(UIViewController*)pViewController withIndexNo:(int)pintIndexNo
{
	[pViewController.navigationController popToViewController:[[pViewController.navigationController viewControllers] objectAtIndex:[[pViewController.navigationController viewControllers] count] - pintIndexNo] animated:TRUE];
}

#pragma mark - Push-Pop
+(void)pushWithAnimation:(UIViewController*)pViewController withPushController:(UIViewController*)pPushViewController withAnimationNo:(int)pintAnimationNo{
    switch (pintAnimationNo) {
        case 1:
        {
            ////ANIMATION////
            CATransition* transition = [CATransition animation];
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
            transition.duration = 0.3f;
            transition.type =  @"cube";
            transition.subtype = @"fromRight";
            [pViewController.navigationController.view.layer removeAllAnimations];
            [pViewController.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            
            [pViewController.navigationController pushViewController:pPushViewController animated:NO];
            ////ANIMATION END////
        }
            break;
        case 2:
        {
            CATransition* transition = [CATransition animation];
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
            transition.duration = 0.3f;
            transition.type =  @"rotate";
            transition.subtype = @"180cw";
            [pViewController.navigationController.view.layer removeAllAnimations];
            [pViewController.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            
            [pViewController.navigationController pushViewController:pPushViewController animated:NO];
        }
            break;
        case 3:
        {
            CATransition* transition = [CATransition animation];
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
            transition.duration = 0.3f;
            transition.type =  @"rippleEffect"; //suckEffect
            transition.subtype = @"fromRight";
            /*CAFilter *filter = [CAFilter filterWithName:@"suckEffect"];
             [filter setValue:[NSValue valueWithCGPoint:CGPointMake(160, 240)] forKey:@"inputPosition"];
             transition.filter = filter;*/
            [pViewController.navigationController.view.layer removeAllAnimations];
            [pViewController.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            
            [pViewController.navigationController pushViewController:pPushViewController animated:NO];
        }
            break;
        case 4:
        {
            CATransition* transition = [CATransition animation];
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
            transition.duration = 0.3f;
            transition.type =  @"cameraIris";
            transition.subtype = @"fromRight";
            [pViewController.navigationController.view.layer removeAllAnimations];
            [pViewController.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            
            [pViewController.navigationController pushViewController:pPushViewController animated:NO];
        }
            break;
        default:
        {
            ////ANIMATION////
            CATransition* transition = [CATransition animation];
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
            transition.duration = 0.3f;
            transition.type =  @"cube";
            transition.subtype = @"fromRight";
            [pViewController.navigationController.view.layer removeAllAnimations];
            [pViewController.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            
            [pViewController.navigationController pushViewController:pPushViewController animated:NO];
            ////ANIMATION END////
        }
            break;
    }
}
+(void)popWithAnimation:(UIViewController*)pViewController withAnimationNo:(int)pintAnimationNo{
    switch (pintAnimationNo) {
        case 1:
        {
            ////ANIMATION////
            CATransition* transition = [CATransition animation];
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
            transition.duration = 0.3f;
            transition.type =  @"cube";
            transition.subtype = @"fromLeft";
            [pViewController.navigationController.view.layer removeAllAnimations];
            [pViewController.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            
            [pViewController.navigationController popViewControllerAnimated:NO];
            ////ANIMATION END////
        }
            break;
        case 2:
        {
            CATransition* transition = [CATransition animation];
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
            transition.duration = 0.3f;
            transition.type =  @"rotate";
            transition.subtype = @"180ccw";
            [pViewController.navigationController.view.layer removeAllAnimations];
            [pViewController.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            
            [pViewController.navigationController popViewControllerAnimated:NO];
        }
            break;
        case 3:
        {
            CATransition* transition = [CATransition animation];
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
            transition.duration = 0.3f;
            transition.type =  @"rippleEffect"; //suckEffect
            transition.subtype = @"fromLeft";
            /*CAFilter *filter = [CAFilter filterWithName:@"suckEffect"];
             [filter setValue:[NSValue valueWithCGPoint:CGPointMake(160, 240)] forKey:@"inputPosition"];
             transition.filter = filter;*/
            [pViewController.navigationController.view.layer removeAllAnimations];
            [pViewController.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            
            [pViewController.navigationController popViewControllerAnimated:NO];
        }
            break;
        case 4:
        {
            CATransition* transition = [CATransition animation];
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
            transition.duration = 0.3f;
            transition.type =  @"cameraIris";
            transition.subtype = @"fromLeft";
            [pViewController.navigationController.view.layer removeAllAnimations];
            [pViewController.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            
            [pViewController.navigationController popViewControllerAnimated:NO];
        }
            break;
        default:
        {
            ////ANIMATION////
            CATransition* transition = [CATransition animation];
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
            transition.duration = 0.3f;
            transition.type =  @"cube";
            transition.subtype = @"fromLeft";
            [pViewController.navigationController.view.layer removeAllAnimations];
            [pViewController.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            
            [pViewController.navigationController popViewControllerAnimated:NO];
            ////ANIMATION END////
        }
            break;
    }
}

#pragma mark - Add Gesture
+(void)addGesture:(UIViewController*)pViewController{
    UISwipeGestureRecognizer *rightSwipeGestureRecognizer = [[[UISwipeGestureRecognizer alloc] initWithTarget:pViewController action:@selector(showMenu:)] autorelease];
    rightSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirectionRight;
    [pViewController.view addGestureRecognizer:rightSwipeGestureRecognizer];
    
    UISwipeGestureRecognizer* leftSwipeGestureRecognizer = [[[UISwipeGestureRecognizer alloc] initWithTarget:pViewController action:@selector(hideMenu:)] autorelease];
    leftSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirectionLeft;
    [pViewController.view addGestureRecognizer:leftSwipeGestureRecognizer];
    
    //Note: implement "showMenu" and "hideMenu" in respective view controller
}

#pragma mark - Remove Inner Shadhow of Popover
+ (void)removeInnerShadowOfPopover{
    UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
    //NSLog(@"%@", window.subviews);
    for (UIView *windowSubView in window.subviews) {
        if ([NSStringFromClass([windowSubView class]) isEqualToString:@"UIDimmingView"]) {
            for (UIView *dimmingViewSubviews in windowSubView.subviews) {
                for (UIView *popoverSubview in dimmingViewSubviews.subviews) {
                    if([NSStringFromClass([popoverSubview class]) isEqualToString:@"UIView"]) {
                        for (UIView *subviewA in popoverSubview.subviews) {
                            if ([NSStringFromClass([subviewA class]) isEqualToString:@"UILayoutContainerView"]) {
                                subviewA.layer.cornerRadius = 0;
                            }
                            for (UIView *subviewB in subviewA.subviews) {
                                if ([NSStringFromClass([subviewB class]) isEqualToString:@"UIImageView"] ) {
                                    [subviewB removeFromSuperview];
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@end
