//
//  MainViewController.h
//  PhotoShare
//
//  Created by WebInfoways on 26/02/14.
//  Copyright (c) 2014 Test. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShareViewController.h"

@class AppDelegate;

@interface MainViewController : UIViewController <UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIPopoverControllerDelegate,UIGestureRecognizerDelegate> {
    AppDelegate *appDelegate;
    
    CGFloat xDis;
    CGFloat yDis;
    
    CGFloat _lastScale;
	CGFloat _lastRotation;
    CGFloat _firstX;
	CGFloat _firstY;
    
    int intCurrTakenPhoto;      //1=Camera, 2=Photo Album
}
@property(nonatomic,retain) IBOutlet UIView *viewTop;
@property(nonatomic,retain) IBOutlet UIView *viewBottom;
@property(nonatomic,retain) IBOutlet UIView *viewMiddle;

@property(nonatomic,retain) UIImage *imgSelectedPhoto;
@property(nonatomic,retain) IBOutlet UIImageView *imgMainPhoto;
@property(nonatomic,retain) IBOutlet UIImageView *imgAdjustPhoto;

@property(nonatomic,retain) IBOutlet UIView *viewHelp;

-(void)setInitialParameter;
-(void)setGesture;
-(void)resetData;

-(void)setHelp;
-(void)displayGestureHelp;

-(IBAction)btnTappedCamera:(id)sender;
-(IBAction)btnTappedPhotoAlbum:(id)sender;

-(IBAction)btnTappedDone:(id)sender;
-(UIImage *)takeScreenshot:(UIView *)pView;
-(IBAction)btnTappedReset:(id)sender;

@end
