//
//  MainViewController.m
//  PhotoShare
//
//  Created by WebInfoways on 26/02/14.
//  Copyright (c) 2014 Test. All rights reserved.
//

#import "MainViewController.h"

/*
#define kIMAGE_POSITION_X	((g_IS_IPHONE_5_SCREEN) ? 0.0 : 0.0)
#define kIMAGE_POSITION_Y	((g_IS_IPHONE_5_SCREEN) ? 0.0 : 0.0)
#define kIMAGE_WIDTH        ((g_IS_IPHONE_5_SCREEN) ? 320.0 : 320.0)
//#define kIMAGE_HEIGHT       ((g_IS_IPHONE_5_SCREEN) ? 548.0 : 460.0)
#define kIMAGE_HEIGHT       ((g_IS_IPHONE_5_SCREEN) ? 468.0 : 380.0)
*/

#define kIMAGE_POSITION_X	((g_IS_IPHONE_5_SCREEN) ? 85.0 : 85.0)
#define kIMAGE_POSITION_Y	((g_IS_IPHONE_5_SCREEN) ? 134.0 : 90.0)
#define kIMAGE_WIDTH        ((g_IS_IPHONE_5_SCREEN) ? 150.0 : 150.0)
#define kIMAGE_HEIGHT       ((g_IS_IPHONE_5_SCREEN) ? 200.0 : 200.0)

#define g_IMAGE_WIDTH_MAIN      320.0
#define g_IMAGE_WIDTH_LAYER     150.0

@interface MainViewController ()

@end

@implementation MainViewController

@synthesize viewTop,viewBottom,viewMiddle;

@synthesize imgSelectedPhoto,imgMainPhoto,imgAdjustPhoto;
@synthesize viewHelp;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
	[self setInitialParameter];
}
- (void)viewWillAppear:(BOOL)animated{
}
- (void)viewDidDisappear:(BOOL)animated{
}

#pragma mark - Set Initial Parameter
-(void)setInitialParameter{
    [self setGesture];
    [self setHelp];
    [self resetData];
}

#pragma mark - Take Photo
-(IBAction)btnTappedCamera:(id)sender{
    intCurrTakenPhoto = 1;
    
    if ([FunctionManager isCameraDeviceAvailable]) {
        UIImagePickerController *picker = [[[UIImagePickerController alloc] init] autorelease];
        picker.delegate = self;
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        //[self presentModalViewController:picker animated:YES];
        [self presentViewController:picker animated:YES completion:nil];
    }
    else
        [FunctionManager showMessage:@"" withMessage:msgNoCameraAvailable withDelegage:nil];
}
-(IBAction)btnTappedPhotoAlbum:(id)sender{
    intCurrTakenPhoto = 2;
    
    UIImagePickerController *picker = [[[UIImagePickerController alloc] init] autorelease];
    picker.delegate = self;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    //[self presentModalViewController:picker animated:YES];
    [self presentViewController:picker animated:YES completion:nil];
}
#pragma mark Take Photo delegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
	//[picker dismissModalViewControllerAnimated:YES];
    [picker dismissViewControllerAnimated:YES completion:nil];
	[self setPhotoImage:[info objectForKey:@"UIImagePickerControllerOriginalImage"]];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
	//[picker dismissModalViewControllerAnimated:YES];
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)setPhotoImage:(UIImage *)pImg
{
    if(intCurrTakenPhoto==1){   //Camera
        self.imgSelectedPhoto=[FunctionManager imageScaleAndCropWithFixWidth:pImg withWidth:g_IMAGE_WIDTH_MAIN];
        [self.imgMainPhoto setImage:self.imgSelectedPhoto];
        
        [self.view bringSubviewToFront:self.viewTop];
        [self.view bringSubviewToFront:self.viewBottom];
    }
    else{   //Photo Album
        self.imgSelectedPhoto=[FunctionManager imageScaleAndCropWithFixWidth:pImg withWidth:g_IMAGE_WIDTH_LAYER];
        [self.imgAdjustPhoto setImage:self.imgSelectedPhoto];
        
        [self displayGestureHelp];
    }
}

#pragma mark - Gesture
-(void)setGesture{
    UIPinchGestureRecognizer *pinchRecognizer = [[[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(scale:)] autorelease];
    [pinchRecognizer setDelegate:self];
    //[self.view addGestureRecognizer:pinchRecognizer];
    [self.viewMiddle addGestureRecognizer:pinchRecognizer];
    
    UIRotationGestureRecognizer *rotationRecognizer = [[[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotate:)] autorelease];
    [rotationRecognizer setDelegate:self];
    //[self.view addGestureRecognizer:rotationRecognizer];
    [self.viewMiddle addGestureRecognizer:rotationRecognizer];
    
    UIPanGestureRecognizer *panRecognizer = [[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(move:)] autorelease];
    [panRecognizer setMinimumNumberOfTouches:1];
    [panRecognizer setMaximumNumberOfTouches:1];
    [panRecognizer setDelegate:self];
    //[self.view addGestureRecognizer:panRecognizer];
    [self.viewMiddle addGestureRecognizer:panRecognizer];
}
-(void)scale:(UIPinchGestureRecognizer *)gestureRecognizer{
    if ([gestureRecognizer numberOfTouches] >1) {
        
        //getting width and height between gestureCenter and one of my finger
        //float x = [gestureRecognizer locationInView:self].x - [gestureRecognizer locationOfTouch:1 inView:self].x;
        float x = [gestureRecognizer locationInView:self.imgAdjustPhoto].x - [gestureRecognizer locationOfTouch:1 inView:self.imgAdjustPhoto].x;
        if (x<0) {
            x *= -1;
        }
        //float y = [gestureRecognizer locationInView:self].y - [gestureRecognizer locationOfTouch:1 inView:self].y;
        float y = [gestureRecognizer locationInView:self.imgAdjustPhoto].y - [gestureRecognizer locationOfTouch:1 inView:self.imgAdjustPhoto].y;
        if (y<0) {
            y *= -1;
        }
        
        //set Border
        if (gestureRecognizer.state == UIGestureRecognizerStateBegan) {
            xDis = self.imgAdjustPhoto.bounds.size.width - x*2;
            yDis = self.imgAdjustPhoto.bounds.size.height - y*2;
        }
        
        //double size cause x and y is just the way from the middle to my finger
        float width = x*2+xDis;
        if (width < 1) {
            width = 1;
        }
        float height = y*2+yDis;
        if (height < 1) {
            height = 1;
        }
        self.imgAdjustPhoto.bounds = CGRectMake(self.imgAdjustPhoto.bounds.origin.x , self.imgAdjustPhoto.bounds.origin.y , width, height);
        [gestureRecognizer setScale:1];
        //[[self.imgAdjustPhoto layer] setBorderWidth:2.f];
    }
}
-(void)rotate:(id)sender {
    
    if([(UIRotationGestureRecognizer*)sender state] == UIGestureRecognizerStateEnded) {
        _lastRotation = 0.0;
        return;
    }
    
    CGFloat rotation = 0.0 - (_lastRotation - [(UIRotationGestureRecognizer*)sender rotation]);
    
    CGAffineTransform currentTransform = self.imgAdjustPhoto.transform;
    CGAffineTransform newTransform = CGAffineTransformRotate(currentTransform,rotation);
    
    [self.imgAdjustPhoto setTransform:newTransform];
    
    _lastRotation = [(UIRotationGestureRecognizer*)sender rotation];
    //[self showOverlayWithFrame:self.imgAdjustPhoto.frame];
}
-(void)move:(id)sender {
    
    CGPoint translatedPoint = [(UIPanGestureRecognizer*)sender translationInView:self.imgAdjustPhoto];
    
    if([(UIPanGestureRecognizer*)sender state] == UIGestureRecognizerStateBegan) {
        _firstX = [self.imgAdjustPhoto center].x;
        _firstY = [self.imgAdjustPhoto center].y;
    }
    
    translatedPoint = CGPointMake(_firstX+translatedPoint.x, _firstY+translatedPoint.y);
    
    [self.imgAdjustPhoto setCenter:translatedPoint];
    //[self showOverlayWithFrame:self.imgAdjustPhoto.frame];
}
#pragma mark UIGestureRegognizerDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return ![gestureRecognizer isKindOfClass:[UIPanGestureRecognizer class]] && ![gestureRecognizer isKindOfClass:[UITapGestureRecognizer class]];
}

#pragma mark - Button Tapped Done
-(IBAction)btnTappedDone:(id)sender{
    UIImage *imgPhotoToShare = [self takeScreenshot:self.viewMiddle];
    
    ShareViewController *objShareViewController;
    if(g_IS_IPHONE_5_SCREEN)
        objShareViewController = [[[ShareViewController alloc] initWithNibName:@"ShareViewController" bundle:nil] autorelease];
    else
        objShareViewController = [[[ShareViewController alloc] initWithNibName:@"ShareViewController4" bundle:nil] autorelease];
    
    objShareViewController.imgPhotoPreview = imgPhotoToShare;
    [self.navigationController pushViewController:objShareViewController animated:YES];
}
#pragma mark Take Screen
-(UIImage *)takeScreenshot:(UIView *)pView
{
	/*UIGraphicsBeginImageContext(pView.bounds.size);
     [[UIColor clearColor] setFill];
     [[UIBezierPath bezierPathWithRect:pView.bounds] fill];
     CGContextRef ctx = UIGraphicsGetCurrentContext();
     [pView.layer renderInContext:ctx];
     UIImage *anImage = UIGraphicsGetImageFromCurrentImageContext();
     UIGraphicsEndImageContext();
     return anImage;*/
    
    /*UIGraphicsBeginImageContext(pView.bounds.size);
     CGContextRef ctx = UIGraphicsGetCurrentContext();
     [[UIColor blackColor] set];
     CGContextFillRect(ctx, pView.bounds.size);
     [pView.layer renderInContext:ctx];
     UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
     UIGraphicsEndImageContext();
     return newImage;*/
    
    CGRect rect = [pView bounds];
    UIGraphicsBeginImageContextWithOptions(rect.size,YES,0.0f);
    CGContextRef context = UIGraphicsGetCurrentContext();
    [pView.layer renderInContext:context];
    UIImage *capturedImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return capturedImage;
}

#pragma mark - Button Tapped Reset
-(IBAction)btnTappedReset:(id)sender{
    [UIView animateWithDuration:0.2 animations:^() {
        self.imgAdjustPhoto.transform = CGAffineTransformIdentity;
        [self.imgAdjustPhoto setFrame:CGRectMake(kIMAGE_POSITION_X, kIMAGE_POSITION_Y, kIMAGE_WIDTH, kIMAGE_HEIGHT)];
    }];
}
-(void)resetData{
}

#pragma mark - Help
-(void)setHelp{
    self.viewHelp.layer.borderColor = [UIColor colorWithRed:99.0/255.0 green:95.0/255.0 blue:103.0/255.0 alpha:1.0].CGColor;
    self.viewHelp.layer.borderWidth = 3.0f;
    [self.view addSubview:self.viewHelp];
    [self.viewHelp setHidden:TRUE];
    
    //[self displayGestureHelp];
}
-(void)displayGestureHelp{
    self.viewHelp.hidden = NO;
    [[KGModal sharedInstance] showWithContentView:self.viewHelp andAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Orientations
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [self.viewTop release];
    [self.viewBottom release];
    [self.viewMiddle release];
    
    self.imgAdjustPhoto = nil;
    [self.imgAdjustPhoto release];
    
    self.imgMainPhoto = nil;
    [self.imgMainPhoto release];
    
    [self.viewHelp release];
    
    [super dealloc];
}

@end
