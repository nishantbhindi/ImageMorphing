//
//  ShareViewController.h
//  PhotoShare
//
//  Created by WebInfoways on 27/02/14.
//  Copyright (c) 2014 Test. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppDelegate;

@interface ShareViewController : UIViewController {
    AppDelegate *appDelegate;
}
@property(nonatomic,retain) UIImage *imgPhotoPreview;
@property(nonatomic,retain) IBOutlet UIImageView *imgPhotoToShare;


-(void)setInitialParameter;

-(IBAction)btnTappedShare:(id)sender;

-(IBAction)btnTappedBack:(id)sender;

@end
