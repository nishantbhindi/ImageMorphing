//
//  ShareViewController.m
//  PhotoShare
//
//  Created by WebInfoways on 27/02/14.
//  Copyright (c) 2014 Test. All rights reserved.
//

#import "ShareViewController.h"

@interface ShareViewController ()

@end

@implementation ShareViewController

@synthesize imgPhotoPreview,imgPhotoToShare;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
	[self setInitialParameter];
}
- (void)viewWillAppear:(BOOL)animated{
    [self.imgPhotoToShare setImage:self.imgPhotoPreview];
}
- (void)viewDidDisappear:(BOOL)animated{
}

#pragma mark - Set Initial Parameter
-(void)setInitialParameter{
}

#pragma mark - Share
-(IBAction)btnTappedShare:(id)sender{
}

#pragma mark - Back
-(IBAction)btnTappedBack:(id)sender{
    [FunctionManager gotoBack:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Orientations
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    self.imgPhotoToShare = nil;
    [self.imgPhotoToShare release];
    
    [super dealloc];
}

@end
