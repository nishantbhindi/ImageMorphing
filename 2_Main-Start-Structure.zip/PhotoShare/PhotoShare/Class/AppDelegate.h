//
//  AppDelegate.h
//  PhotoShare
//
//  Created by WebInfoways on 26/02/14.
//  Copyright (c) 2014 Test. All rights reserved.
//

#import <UIKit/UIKit.h>

// Global Function
#import "FunctionManager.h"

@class MainViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) IBOutlet UIWindow *window;

@property (nonatomic, retain) UINavigationController *navController;
@property (strong, nonatomic) MainViewController *viewController;

-(void)initializeAppData;
-(void)checkDeviceCompatibility;

@end
